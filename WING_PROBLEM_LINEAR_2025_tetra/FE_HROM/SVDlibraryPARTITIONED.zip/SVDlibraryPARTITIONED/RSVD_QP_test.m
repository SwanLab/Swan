function [ETIME  Sincre ERROR_PART Uincre Vincre A RankR] =...
    RSVD_QP_test(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE,CALCULATE_ERROR_PART,...
    DATALOC)

ERROR_PART = [] ;
ETIME = [] ;
rankR = [] ; 
[A,alpha,beta,epsilon,p,q] =GenerateMatrixGlo(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE,DATALOC) ;

DATALOC = DefaultField(DATALOC,'RESHAPE',[])
if ~isempty(DATALOC.RESHAPE) | DATALOC.RESHAPE ==0
    p = DATALOC.RESHAPE(1) ;
    q = DATALOC.RESHAPE(2) ;
    A = reshape(A,p,q) ;
    alpha = [] ; beta = [] ;
    for i=1:size(A,1)
        alpha(i) = size(A{i,1},1) ;
        for j = 1:size(A,2)
            beta(j) = size(A{i,j},2) ;
        end
    end
    
    epsilon = reshape(epsilon, p,q) ;
    
end


DATA = DefaultField(DATA,'TWOLEVELMETHOD',[]) ;
DATALOC = DefaultField(DATALOC,'RUN_INTERSECT_METHOD',0) ;
DATALOC = DefaultField(DATALOC,'TWO_THRESHOLDS_SVD',0) ;

DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'ACTIVE',0) ;
%dbstop('33')
if  (DATA.TWOLEVELMETHOD.ACTIVE == 0 ...
        | ( DATA.TWOLEVELMETHOD.ACTIVE ==1  & DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES ==1)) ...
        &    DATALOC.TWO_THRESHOLDS_SVD == 0
    
    disp('NEw QP incremental method')
    disp('-------------------------------')
    %   dbstop('17')
    if DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES == 1
        
      DATA.TWOLEVELMETHOD.ACTIVE = 0;  
        for i = 1:size(A,1)
            for j = 1:size(A,2)
                A{i,j}= cellWS2mat(A{i,j});
                beta{j} = size(A{i,j},2) ;
            end
            alpha{i} = size(A{i,j},1) ;
        end
        
        alpha = cell2mat(alpha) ;
        beta = cell2mat(beta) ;
    end
    
    %  DATA.dr = dr ;
    %  DATA.rho = rho ;
    TIMEpart = tic ;
    DATALOC = DefaultField(DATALOC,'TEST_ONE_ROW',0) ;
    if size(A,1)==1 & DATALOC.TEST_ONE_ROW == 1
        dbstop('60')
        [Q,L,gamma,nrowL,Rmax,ETIME,RankMatrix] = RORTH1row(A,epsilon,DATA) ;
        
        %   [Q,L,gamma,nrowL,Rmax,ETIME] = RORTH1row_old(A,epsilon,DATA) ;
    else
        
        DATALOC = DefaultField(DATALOC,'SYMMETRIC_PRUEBA',0) ;
        if DATALOC.SYMMETRIC_PRUEBA == 0
            [Uincre,Sincre,Vincre,ETIME,RankR] = RSVDqpGEN(A,epsilon,DATA) ;
        else
            [Uincre,Sincre,Vincre,ETIME] = RSVDqpSYM(A,epsilon,DATA) ;
            
        end
        
    end
    LLL = 'new QP';
    
elseif    DATALOC.TWO_THRESHOLDS_SVD == 0
    disp('MULTILEVEL QP incremental method')
    disp('-------------------------------')
    TIMEpart = tic ;
    [Uincre,Sincre,Vincre,ETIME] = RSVDqpGEN(A,epsilon,DATA) ;
    LLL = 'new QP, multilevel';
    % elseif  DATALOC.RUN_INTERSECT_METHOD == 1
    %     weeoe()
    %       [Uincre,Sincre,Vincre,ETIME] = RSVD_rowINTERSEC(A,epsilon,DATA) ;
    
elseif DATALOC.TWO_THRESHOLDS_SVD ==1
    
    disp('TWO_THRESHOLDS_SVD  method')
    disp('-------------------------------')
    TIMEpart = tic ;
    [Uincre,Sincre,Vincre,ETIME,rankR] = RSVDtwoTHRES(A,epsilon,DATA) ;
    LLL = 'two threshold method ';
    
end




disp(['RANK = ',num2str(length(Sincre))])
TIMEpart = toc(TIMEpart) ;
disp(['Total time  = ',num2str(TIMEpart)])
disp('---------------------')
disp('---------------------')
figure(1)
hold on
ylabel('log10(S)')
h = plot(log10(Sincre),'k') ;
legend(h,['INCRE',LLL,', p = ',num2str(p), ', q=',num2str(q),' RANK = ',num2str(length(Sincre))])
legend('off')
legend('show')

a = 0;

if ~isempty(rankR)
Sincre = Sincre(1:rankR); 
Uincre = Uincre(:,1:rankR) ;
Vincre = Vincre(:,1:rankR) ;

end