clc
clear all
% pruebas

load('tmp_1.mat');
epsilon =[
    0.01                     1e-06
    0.01                     1e-06] ;
Q{1} =Qi ;
p = size(A,1) ;

load('tmp_2.mat');
Q{2} =Qi ;

QtA = cell(p,1) ;

for i = 1:p
    disp(['i =',num2str(i)])
    QtA{i} = Q{i}'*cell2mat(A(i,:)) ;
    % rank(QtA{i})
    
end

QtAbefore = cell2mat(QtA) ;

rank(QtAbefore)


%%%% NEW METHOD
% --------------------------------------------------
DATA = [] ;
beta = [] ;
QtA = cell(size(A)) ;
Q = cell(p,1) ;
Pit = cell(size(A)) ;
Rmax = 0 ;

for i=1:size(A,1)
    alpha(i) = size(A{i,1},1);
    for j=1:size(A,2)
        beta(j) = size(A{i,j},2);
    end
end

B = cell(size(A')) ;
for i = 1:p
    if i==1
        % The first row is computed in the      same way as   the standard case
        [Qi,Bi,gamma(i,:),~,~,epsilonSVD,tloc,Rmax_loc,tsave] = RORTH1row(A(i,:),beta,epsilon(i,:),DATA)   ;
    else
        % For the second row, we have to take into account the information
        % contained in the preceding row block. How to do that ?
        %  New function RORTH1rowCOUPLED
        
        [Qi,Bi,gamma(i,:),~,~,epsilonSVD,tloc,Rmax_loc,tsave] = RORTH1rowCOUPLED(A(i,:),beta,epsilon(i,:),DATA,Pit(i-1,:)) ;  ;
        
        Rmax = max(Rmax,Rmax_loc) ;
        %  We determine   col(A{i,j}*Pit{i-1,j}*Pit{i-1,j}^T)
        
        %         for j = 1:size(A,2)
        %             dA_p = A{i,j} - A{i,j}*Pit{i-1,j}*Pit{i-1,j}' ;
        %             % Column space of dA_p (basis matrix)
        %             Rest = 1.05*size(Pit{i-1,j},2) ;
        %             dR = Rest ;
        %             e0 =[] ;
        %             b = norm(A{i,j},'fro') ;
        %             bnorm(i) = b ;
        %     mu = (max(size(dB))*eps(b))  ;
        %             mu = [] ;
        %             [dQ,Hi,Gi,eSVD,RankMatrix] = RSVDt(dB,DATA.Omega(1:Ni,1:Rest),e0,dR,mu,DATA);
        %         end
        
    end
    
    
    % Now we calculate a basis matrix for the row space of Q^T A(i,:)

    METHOD_OLD =0;
    
    if    METHOD_OLD == 1
        for j = 1:size(A,2)
            QtA{i,j} = Qi'*A{i,j} ;
            [U,S,Ploc] = SVD(QtA{i,j},0);
            % What to do now with Ploc ? We store it in an array Pit
            Pit{i,j} = Ploc ;
        end
        
    else
        
        dbstop('91')
        QtAloc = Qi'*cell2mat(A(i,:));
        [U,S,Ploc] = SVD(QtAloc,0);
        
       % QtAloc = bsxfun(Ploc,)
          QtAloc = bsxfun(@times,Ploc',S)' ;
          B(:,i) = mat2cell(QtAloc,beta,size(QtAloc,2));
        Qi = Qi*U ;
        Pit(i,:) = mat2cell(Ploc,beta,size(Ploc,2))' ;
    end
    
    
        Q{i} = sparse(Qi) ;
end

QtAsfter= cell2mat(QtA) ;

rank(QtAsfter)


DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP = 0;
disp('----------------')
disp('COMPUTATION OF P  (basis for the row space of A)')
disp('----------------')
DATA.EPSILON_ABSOLUTE = 1 ;
tloc = tic ;
DATA.Rini = Rmax ;
DATA.Omega = [] ;

for i=1:size(B,1)
    alpha_b(i) = size(B{i,1},1);
    for j=1:size(B,2)
        beta_b(j) = size(B{i,j},2);
    end
end
[P Ap gamma_c alpha_c beta_c dummy Rmax] = RORTHmatrix(B,alpha_b,beta_b,gamma',DATA) ;


Q = blkdiag(Q{:}) ;


Ap = cell2mat(Ap) ;

c = norm(Ap,'fro') ;
e0 = (max(size(Ap))*eps(c))  ;

Rest =  Rmax ;
dR =  Rest ;
Omega = randn(size(Ap,2),Rest) ;
DATA.COMPUTE_V_SVD = 1;
DATA.Omega = [] ;
[U,S,V,eSVD,RankMatrix] = RSVDt(Ap,Omega,e0,dR,e0,DATA) ;
% end

DATA.COMPUTE_V_LAST_SVD = 1;
DATA.TWOLEVELMETHOD.ACTIVE = 0;

if ~isempty(Q) ;  U = Q*U ; end
ETIME.QUbar = toc(tloc) ;
disp('Done ')
if  DATA.COMPUTE_V_LAST_SVD == 1
    disp('---------------------------------------')
    disp('Computing righbt singular vectors V = P*Vbar')
    tloc = tic ;
    if ~isempty(P) ; V = P*V ; end
    ETIME.PVbar = toc(tloc) ;
    disp('Done ')
else
    P = [] ;
end


a = 0;

%  epsilon = 0.01*ones(size(A)) ;
[ERROR_PART,RANK] = DiffApproxSVD( U(:,1:end-a),S(1:end-a),V(:,1:end-a),[],A) ;


figure(1)
hold on
ylabel('log10(S)')
h = plot(log10(S),'k') ;
%legend(h,['INCRE',LLL,', p = ',num2str(p), ', q=',num2str(q),' RANK = ',num2str(length(Sincre))])
legend('off')
legend('show')


% Size A
