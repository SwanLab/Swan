function [ERROR,R] = DiffApproxSVD(U,S,V,c,Lmat,DATALOC)

%dbstop('4')
if nargin == 0
    load('tmp3.mat')
    load('tmp1.mat','dA','Ul','Sl','Vl')
    Lmat = dA ;
     U = Ul(:,1:10) ; 
     S = Sl(1:10) ; 
     V = Vl(:,1:10) ; 
     DATALOC.ERROR_PART_ABSOLUTE = 1; 
    
end

DATALOC = DefaultField(DATALOC,'ERROR_PART_ABSOLUTE',0) ; 

Capprox = bsxfun(@times,U',S)' ;
Capprox  = Capprox*V' ;
R =length(S);
disp(['RANK = ',num2str(length(S))])
% ERROR = norm(Lmat-Capprox,'fro')/c

iini = 1 ;

for i = 1:size(Lmat,1)
    jini=1;
    for j = 1:size(Lmat,2)
        Li = Lmat{i,j} ;
        ifin = size(Li,1) + iini-1 ;
        jfin = size(Li,2) + jini-1 ;
        Ci = Capprox(iini:ifin,jini:jfin) ;
        if DATALOC.ERROR_PART_ABSOLUTE==0
        ERROR(i,j) = norm(Li-Ci,'fro')/norm(Li,'fro');
        else
             ERROR(i,j) = norm(Li-Ci,'fro');
        end
        jini = jfin+1 ;
    end
    iini = ifin + 1;
end

end