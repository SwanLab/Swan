clc
clear all

addpath('AUXFUN')

load('tmp_error.mat')
a = 0.00 ; 
epsilon = a*ones(1,5) ;
epsilon(4) = 0.00; 

% Randomized strategy
figure(1)
hold on

% Lp = cell(size(L));
% betap = beta; 
% for i=1:length(L)
%     Lp{i} = L{end-i+1} ; 
%     betap(i) = beta(end-i+1) ; 
% end
% L = Lp ; 
% beta = betap ; 
Lmat = cell2mat(L) ;
c = norm(Lmat,'fro') ;

[U,Srandom,V,R,DATAOUT] = RNSVDcol(L,beta,epsilon,Nmax,r,dr,rho) ;




[ERRORrand,Rrand] = DiffApproxSVD(U,Srandom,V,c,L) ; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%5
[U,Sincre,V,INDICES] =RSVDincre(L,beta,epsilon,dr,rho) ;
 
[ERRORincre,Rincre] = DiffApproxSVD(U,Sincre,V,c,L) 


 [U,S,V] = SVD(cell2mat(L),0) ;
 
 [ERRORsvd,Rsvd] = DiffApproxSVD(U(:,1:Rincre),S(1:Rincre),V(:,1:Rincre),c,L) ; 