clc
clear all

TIME_1 = RunTestsFinal('DATA90')  ;


% TIME_2 = RunTestsFinal('DATA38')  ;
% 
% 
% TIME_3 = RunTestsFinal('DATA39')  ;