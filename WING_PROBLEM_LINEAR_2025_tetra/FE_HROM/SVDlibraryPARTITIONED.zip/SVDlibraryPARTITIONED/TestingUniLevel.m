clc
clear all

format long g

addpath('AUXFUN')

DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES  = 0;
% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------

SIZE_A =0.1e3 ;     % Size matrix (Mbytes)
p0 =2;   % Number of partitions along rows
q0 =3 ;  % Number of partitions along columns
p0_REF =2; 
q0_REF = 3; 
DATALOC.RESHAPE =[] ;  [2 3]; [] ;  [2 2];  [2 2] ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ERROR TOLERANCES
% -----------------------------------------
DATA.EPSILON_GLO = 0.00; %1e-6 ; % 5e-7; % Global tolerance
epsilon = 0.01*ones(p0,q0) ; % Tolerance
%epsilon(:,end) =0 ; %1e-6;
%epsilon = [       0.01         0.12         0.12      8.95968448377281e-12
%       0.01       0.01      0.01      1.00447407332106e-12]  ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs for the new version
% --------------------------
DATA.TWOLEVELMETHOD.ACTIVE = 0;  % To activate the multilevel method
DATA.TWOLEVELMETHOD.TypePartition = 'UNIFORM' ;  % Type of subparittion
DATA.TWOLEVELMETHOD.TryToUseFastMemory = 1;  %
DATA.TWOLEVELMETHOD.LimitGbytes = 4;  %
DATA.MaxSizeMatrixGb = 0.3; % Maximum size of a single submatrix
DATA.USE_SLOW_MEMORY.ACTIVE = 0 ;    % Use slow memory (default when twolevel is active)
DATA.USE_SLOW_MEMORY.GENERATE_AGAIN =1;  % Generate again matrix data


DATA.rho =1.05;  % Uncertainty factor (to estimate upper bound for rank of each submatrix)
DATA.dr = 1 ; % Incremental rank (relative)

%% DEFAULT OPTIONS
% ------------------
DATALOC.RUN_NESTED = 1;
DATA.LAST_SVD_RANDOM = 1;  % Last SVD is performed using RSVD
DATA.USE_ORTHwithTOL = 1 ;  % Default option (orthogonal decomp. of errors)
DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP =  1;
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;

DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;
N = ceil(sqrt(SIZE_A/8*1e6)) ; % Number of columns
M = N ;  % Number of rows
DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
COMPUTE_TRANSPOSE =0;
CALCULATE_ERROR_PART=1;

% END INPUTS -----------------------------------------------------

% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ;
%for  iproj = 1:length(p0_glo)


NAMEWS = ['DATAWS/ETIME_GLO_size',num2str(SIZE_A),'_lim_',num2str(DATA.MaxSizeMatrixGb ),'_SAVE_',...
    num2str(DATA.USE_SLOW_MEMORY.ACTIVE),mfilename,'.mat'] ;

[ETIME  Sincre ERROR_part Uincre Vincre A] =...
    RSVD_QP_test(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE,CALCULATE_ERROR_PART,...
    DATALOC) ;
%end



%  epsilon = 0.01*ones(size(A)) ;
ERROR_PART = [] ;
a = 0 ; 
%dbstop('67')




if CALCULATE_ERROR_PART == 1;
    
    A = cell2mat(A) ; 
    beta = MakePartition(size(A,2),q0_REF) ;
     alpha = MakePartition(size(A,1),p0_REF) ;
    A = mat2cell(A,alpha,beta) ;
    
    [ERROR_PART,RANK] = DiffApproxSVD( Uincre(:,1:end-a),Sincre(1:end-a),Vincre(:,1:end-a),[],A) ;
    
end


save(NAMEWS,'ETIME','Sincre','ERROR_part')
