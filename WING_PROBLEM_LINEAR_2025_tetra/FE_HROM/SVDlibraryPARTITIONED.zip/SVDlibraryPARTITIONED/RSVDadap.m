function [U,S,V,i] = RSVDadap(C,Q,epsilon,dR) ;

[M,N] = size(C); c = norm(C,'fro') ; % Frobenius norm of C
mu = (max([M,N])*eps(c))  ;% Machine precision
if epsilon > 0
    e0 = epsilon*c ;
else
    e0 = mu ;
end
dC = C-Q*(Q'*C) ;
nC = norm(dC,'fro') ;  
i = 0 ; 
while nC>=e0  & size(Q,2)<N
    i = i + 1 ;
    Omega = randn(N,dR) ;
    Qi = orth(dC*Omega);
    Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
    dC = dC - Qi*(Qi'*dC) ;
    Q = [Q Qi] ; nCold = nC ;
    nC = norm(dC,'fro') ;
    disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
end

D = Q'*C ;
[U,S,V] = SVD(D,0);
U = Q*U ;

SingVsq =  (S.*S) ;
SingVsq = sort(SingVsq);  % s_r, s_{r-1} ... s_1
normEf2 = sqrt(cumsum(SingVsq)) ; % s_r , s_r + s_{r-1} ... s_r +s_{r-1}+ s_{r-2} ... + s_1
tol2 = (epsilon^2*c^2 - nC^2);
if tol2<=mu
    R = length(S) ;
else
    T = (sum(normEf2<sqrt(tol2))) ;
    R = length(S)-T ;
end
U = U(:,1:R);
S = S(1:R) ;
V = V(:,1:R) ;
