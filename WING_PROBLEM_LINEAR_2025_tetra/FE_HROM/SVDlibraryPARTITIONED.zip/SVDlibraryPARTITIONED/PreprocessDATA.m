function [NAMEF DATA p q   epsilon] = PreprocessMatrix(A,DATA,epsilon)


% Check whether any of the entries of A is a string 
NAMEF = [] ;
DATA.USE_SLOW_MEMORY.ACTIVE = 0 ; 
if iscell(A)
    CHECK = cellfun(@ischar,A) ; 
    if  any(CHECK)
       [ aaa bbb]= find(CHECK==1) ;
        NAMEF = A{aaa(1),bbb(1)} ;
        DATA.USE_SLOW_MEMORY.ACTIVE = 1 ; 
    end
end

if isnumeric(A) || (iscell(A) && isempty(NAMEF) && size(A,1)==1 & size(A,2)==1 )
    if  size(A,1)==1 & size(A,2)==1
        A = A{1,1} ;
    end
    DATA.PATH_STORE_AUX  = [] ;
    p = 1; q = 1; 
    DATA.TRANSPOSE = 0 ; 
else
    [p,q] = size(A) ; 
    if ~isempty(NAMEF)
        NAMEF = fileparts(NAMEF) ;
        DATA.PATH_STORE_A = NAMEF ;
        DATA.PATH_STORE_AUX = [DATA.PATH_STORE_A,'AUXtmpj/'] ;  % Path in which temporary files are stored
    else
        DATA.PATH_STORE_AUX  = [] ;
    
    end
    dbstop('34')
    if DATA.TRANSPOSE == 1
        p_old = p ; q_old = q ; 
        p = q_old ; q = p_old ; 
        A  = A' ;
        epsilon = epsilon' ; 
    end
end
% Creating folder for storing temporary files
if ~isempty( DATA.PATH_STORE_AUX ) && ~exist(DATA.PATH_STORE_AUX)
    mkdir(DATA.PATH_STORE_AUX)
end