function [Bmat]= cellWS2mat(B)



Bmat = cell(size(B)) ;
for i=1:size(B,1)
    for j=1:size(B,2)
        SSS = load(B{i,j}) ;
        fff = fieldnames(SSS) ;  
        Bmat{i,j}=   SSS.(fff{1}) ; 
    end
end

Bmat = cell2mat(Bmat) ; 
 
