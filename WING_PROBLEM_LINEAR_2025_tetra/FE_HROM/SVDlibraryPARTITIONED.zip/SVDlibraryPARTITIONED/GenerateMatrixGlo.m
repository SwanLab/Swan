function [A,alpha,beta,epsilon,p,q] =GenerateMatrixGlo(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,...
    COMPUTE_TRANSPOSE,DATALOC)

 if nargin == 0
    load('tmp.mat')
end

beta = MakePartition(N,q0) ;%
alpha = MakePartition(M,p0) ;

DATA = DefaultField(DATA,'TWOLEVELMETHOD',[]) ;
DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'ACTIVE',0) ;
DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'TypePartition','UNIFORM') ;
DATA = DefaultField(DATA,'MaxSizeMatrixGb',0.2) ;
DATA = DefaultField(DATA,'MAXIMUM_STORAGE_SLOW_MEMORY',0) ;


if   DATA.TWOLEVELMETHOD.ACTIVE ==1    
    DATA.MAXIMUM_STORAGE_SLOW_MEMORY  = 0; 
end


[alphaSUB betaSUB pSUB qSUB]= SubPartitioning(DATA,alpha,beta)  ;



disp('Approximated size')
DATA = DefaultField(DATA,'USE_SLOW_MEMORY',[]) ;
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'ACTIVE',0) ;
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'GENERATE_AGAIN',1) ;


if iscell(alphaSUB)
    alphaSUB = cell2mat(alphaSUB) ;
    betaSUB = cell2mat(betaSUB) ;
end

 

%%% Group subpartitions 
[A, alpha,beta] =   GroupSubPart(alphaSUB,betaSUB,DATA,pSUB,qSUB,p0,q0,DATALOC) ; 



if COMPUTE_TRANSPOSE ==1
    Anew = cell(size(A')) ;
    for i=1:size(Anew,1)
        for j=1:size(Anew,2)
            Anew{i,j} = A{j,i}' ;
            A{j,i} = [] ;
        end
    end
    A = Anew ;
end
if COMPUTE_TRANSPOSE == 1
    qOLD = q0; pOLD = p0 ;
    p0 = qOLD ; q0=pOLD ;
    epsilon = epsilon' ;
    nrepROWSold = nrepROWS ; nrepCOLSold = nrepCOLS ;
    nrepROWS = nrepCOLSold ;
    nrepCOLS = nrepROWSold ;
end

if nrepROWS  ==1 & nrepCOLS ==1
    
    p = p0 ;
    q = q0 ;
else
    A = cell2mat(A);
    
    A = repmat(A,nrepROWS,nrepCOLS) ;
    q = q0*nrepCOLS ;
    p = p0*nrepROWS ,
    beta = MakePartition(size(A,2),q) ;
    alpha = MakePartition(size(A,1),p) ;
    A =mat2cell(A,alpha,beta) ;
    epsilon = repmat(epsilon,nrepROWS,nrepCOLS) ;
end

if ~iscell(alpha)
disp([num2str(sum(alpha)*sum(beta)*8e-6),' Mbytes'])
else
    
    disp([num2str(N*M*8e-6),' Mbytes'])
    
end
% ----------------------------------------------------------------