function [Q B gamma,alpha_b,beta_b,Q_TIME,Rmax] = RORTHmatrixMULT(A,alpha,beta,epsilon,DATA)

%dbstop('4')
if nargin == 0
    load('tmp.mat')
end

%DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
DATA = DefaultField(DATA,'Rini',0) ;




p = length(alpha) ; q = size(beta,2) ;
Q = cell(1,p) ;
B = cell(size(A')) ;
gamma = zeros(size(A)) ;
beta_b = cell(size(alpha)) ;
Q_TIME.rows.TOTAL = zeros(p,1);
Q_TIME.rows.SUB = zeros(p,q) ;
Q_TIME.rows.SAVE = zeros(p,1) ;
Rmax = 0 ;
for i=1:p
    disp('******************************************************************+')
    disp('------------------------------------------')
    disp(['UPPER LEVEL ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('******************************************************************+')
    TTT =tic ;
    %  dbstop('33')
    DATA.i = i ;
    DATA.p = p ;
    DATA.alpha_i = alpha{i} ; 
    [Qi,Bi,gamma(i,:),nROWS,nCOLS,epsilonSVD,tloc,Rmax_loc,tsave] = RORTH1rowMULT(A(i,:),beta,epsilon(i,:),DATA)   ;
    Q_TIME.rows.SUB(i,:) = tloc ;
    Q_TIME.rows.SAVE(i) = tsave ;
    DATA.Rini = Rmax_loc ;
    Rmax = max(Rmax,Rmax_loc) ;
    
    beta_b{i} = nCOLS{1} ;
    Q_TIME.rows.TOTAL(p)= toc(TTT);
    Q{i} = sparse(Qi) ;
    B(:,i) = Bi;
    disp(['Time = ',num2str(Q_TIME.rows.TOTAL(p))])
end
alpha_b = nROWS ;
TTT =tic ;
Q = blkdiag(Q{:}) ;
Q_TIME.convert_diag= toc(TTT);

end