function Xfloc = SinCosExpFun3D_2param(mu,x,y,z)

P = size(mu,1) ;
Xfloc1 = zeros(length(x),P) ;
Xfloc2 = zeros(length(x),P) ;
Xfloc3 = zeros(length(x),P) ;
Xfloc4 = zeros(length(x),P) ;
Xfloc5 = zeros(length(x),P) ;
Xfloc6 = zeros(length(x),P) ;


for iMU = 1:size(mu,1)
    %  dbstop('80')
    mu1 = mu(iMU,1) ;
    mu2 = mu(iMU,2) ;
    
    B_x = (1-x) ; B_y = (1-y) ; B_z = (1-z) ;
    C_x = cos(3*pi*mu1*(x+1)) ; D_x = sin(3*pi*mu1*(x+1)) ;
    C_y = cos(3*pi*mu1*(y+1)) ; D_y = sin(3*pi*mu1*(y+1)) ;
    E_x = exp(-(1+x)*mu1) ;  E_y = exp(-(1+y)*mu1) ;
    C_z = cos(3*pi*mu1*(z+1)) ; D_z = sin(3*pi*mu1*(z+1)) ;
    E_z = exp(-(1+z)*mu2) ;   
    
    
    Xfloc1(:,iMU) =  (B_x.*C_x).*E_x ;
    Xfloc2(:,iMU) =  (B_y.*C_y).*E_y ;
    Xfloc3(:,iMU) =  (B_x.*C_x).*E_y ;
    Xfloc4(:,iMU) =  (B_y.*C_y).*E_x ;
    Xfloc5(:,iMU) =  (B_x.*C_x).*E_z  ;
    Xfloc6(:,iMU) =  (B_z.*C_z).*E_y ;
end

Xfloc = [Xfloc1 Xfloc2 Xfloc3 Xfloc4 Xfloc5 Xfloc6] ;



end
