function [B,beta] = GenerateFunExampleNDIM3d(M,N,beta,q,DATA)
% Generate snapshot matrix B using function defined in
% SinCosExpFun3D_2param.m
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end

xLIM = [- 1 1; -1 1; -1 1]; % Spatial domain
Dmu = [1,pi
    1,pi] ; % Parameter domain ;
nfun = 6 ; % Number of functions
% Spatial discretization
[x M] = InitalDiscretization(M,xLIM) ;
[xx yy zz] = meshgrid(x{1},x{2},x{3}) ;
xx = xx(:);
yy = yy(:);
zz = zz(:) ;
% Discretization of parameter domain
P = round(sqrt(N/nfun)) ;
N = P^2*nfun ;
for i = 1:size(Dmu,1)
    mu{i} = linspace(Dmu(i,1),Dmu(i,2),P) ;
end
[mu1 mu2] = meshgrid(mu{1},mu{2}) ;
mu = [mu1(:), mu2(:)]             ;
% --------------------------------
% Partition domain for parameter space 
betaLOC = MakePartition(size(mu,1),length(beta)) ;
mu = mat2cell(mu,betaLOC,size(mu,2)) ; % Partitioned method 
B = cell(1,length(mu))  ;
% B matrix 
beta = zeros(size(beta));
for i = 1:length(mu)
    disp(['i=',num2str(i),' of ',num2str(length(mu))])
    Bi =    SinCosExpFun3D_2param(mu{i},xx,yy,zz) ;
    if DATA.RetrieveBmemory ==0
        B{i} =Bi ; 
    else
        nameWS = ['DATAWS/B_',num2str(i),'.mat'] ; 
        save(nameWS,'Bi') ;
        B{i} = nameWS ;
    end
    beta(i) = size(Bi,2) ;
end
 





 
