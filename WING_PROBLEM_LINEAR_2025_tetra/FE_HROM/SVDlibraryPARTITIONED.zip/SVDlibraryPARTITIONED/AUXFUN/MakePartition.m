function beta = MakePartition(N,q)
% INPUT: N (number of columns/row); ,q : Number of blocks
% output: beta: Partition of 1:N into q   sets )


NB = floor(N/q) ;
beta = NB*ones(1,q) ;
MMM = mod(N,q) ;
beta(end) = MMM+NB ; %%%


 
