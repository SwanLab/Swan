function [B alpha beta]= GenerateMatrixBlock(alpha,beta,DATA,DATALOC);
% Generate a random row block matrix B (such that B{i} = B(:,beta{i})) of rank <=R
% The rank of each block ranges between 0.5*R and R
% If DATA.LOAD = 1, B is retrieved from memory
if nargin == 0
    load('tmp.mat')
end

q = length(beta); % Number of blocks%%%
p = length(alpha) ;
N = sum(beta);
M = sum(alpha) ;
R = N ;

NAMEWS = ['DATAWS/B_M',num2str(M),'_N',num2str(R),'_q',num2str(q),'_p',num2str(p),'_T',num2str(DATA.TYPE),'.mat'] ;

if exist(NAMEWS)== 2 & DATA.LOAD == 1
    disp('Saving B matrix....')
    load(NAMEWS,'B')
    disp('Done')
else
    
    
    if DATA.TYPE ==1
       [B] = GenerateFunExampleRANDOM(M,N,alpha,beta,q,DATA);
        
    elseif DATA.TYPE ==2
        % Sin/Cos/Exp function
        disp('------------------------')
        disp('Generating B matrix (vector function R6)')
        disp('------------------------')
        %   dbstop('51')
        [B alpha  beta] = GenerateFunExampleNDIM3dBlock(M,N,alpha,beta,q,DATA,DATALOC);
    end
    
    
    if DATA.SAVE == 1
        disp('Saving B matrix....')
        save(NAMEWS,'B')
        disp('Done')
    end
end