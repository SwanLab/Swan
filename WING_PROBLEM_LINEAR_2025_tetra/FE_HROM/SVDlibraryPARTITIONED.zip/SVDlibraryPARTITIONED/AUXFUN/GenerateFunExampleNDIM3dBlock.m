function [B alpha beta] = GenerateFunExampleNDIM3dBlock(M,N,alpha,beta,q,DATA,DATALOC)
% Generate snapshot matrix B using function defined in
% SinCosExpFun3D_2param.m
%dbstop('5')
if nargin == 0
    load('tmp.mat')
    
end

DATA = DefaultField(DATA,'RetrieveBmemory',0);%%%
DATA = DefaultField(DATA,'StoreSnapshotsRowWise',0);
DATA = DefaultField(DATA,'DoNotGenerateAgainSnapshots',0);



xLIM = [- 1 1; -1 1; -1 1]; % Spatial domain
%dbstop('18')
Dmu = [1,pi
    1,pi] ; % Parameter domain ;
DATA =  DefaultField(DATA,'Dmu',0);
Dmu = DATA.Dmu ;
nfun = 6 ; % Number of functions
% Spatial discretization
[x M] = InitalDiscretization(M,xLIM) ;
[xx yy zz] = meshgrid(x{1},x{2},x{3}) ;
xx = xx(:);
yy = yy(:);
zz = zz(:) ;
xMAT = [xx yy zz] ;
% Discretization of parameter domain
P = round(sqrt(N/nfun)) ;
N = P^2*nfun ;
for i = 1:size(Dmu,1)
    mu{i} = linspace(Dmu(i,1),Dmu(i,2),P) ;
end
[mu1 mu2] = meshgrid(mu{1},mu{2}) ;
mu = [mu1(:), mu2(:)]             ;
% --------------------------------
% Partition domain for parameter space
betaLOC = MakePartition(size(mu,1),length(beta)) ;
mu = mat2cell(mu,betaLOC,size(mu,2)) ; % Partitioned method
% Partition domain for space
alphaLOC = MakePartition(size(xMAT,1),length(alpha)) ;
xMAT = mat2cell(xMAT,alphaLOC,size(xMAT,2)) ; % Partitioned method


%if DATA.StoreSnapshotsRowWise==1
%    B = cell(length(xMAT),1)  ;
%else
B = cell(length(xMAT),length(mu))  ;
%end
% B matrix
beta = zeros(size(beta));
alpha = zeros(size(alpha));
%if DATA.DoNotGenerateAgainSnapshots ==1
%    for i = 1:length(xMAT)
%       B{i} = ['DATAWS/B_',num2str(i),'.mat'] ;
%   end
%else
MEM=  DATA.USE_SLOW_MEMORY ;
DATA = DefaultField(DATA,'PATH_STORE_A','DATAWS/DATA_Amatrix/');

%dbstop('64')
if MEM.ACTIVE == 1 & MEM.GENERATE_AGAIN==1
    if exist(DATA.PATH_STORE_A)==0
        mkdir(DATA.PATH_STORE_A)
    else
        rmdir(DATA.PATH_STORE_A,'s')
         mkdir(DATA.PATH_STORE_A)
    end
end
%dbstop('70')
nameWS_glo = [DATA.PATH_STORE_A,'DATAGLO','.mat'] ;
ACCUM_MEMORY = 0 ; 


for i = 1:length(xMAT)
    disp('--------------------------------------')
    disp(['i=',num2str(i),' of ',num2str(length(xMAT))])
    disp('--------------------------------------')
    xx = xMAT{i}(:,1);
    yy = xMAT{i}(:,2);
    zz = xMAT{i}(:,3) ;
    %   B{i} = ['DATAWS/B_',num2str(i),'.mat'] ;
    Brow = cell(1,length(mu))  ;
    for j = 1:length(mu)
        disp(['j=',num2str(j),' of ',num2str(length(mu))])
        
        nameWS =[ DATA.PATH_STORE_A,'A_',num2str(i),'_',num2str(j),'.mat'] ;
        if MEM.ACTIVE  == 0 | (MEM.ACTIVE ==1 & MEM.GENERATE_AGAIN==1)
            Aij =    SinCosExpFun3D_2param(mu{j},xx,yy,zz) ;
            beta(j) = size(Aij,2) ;
            alpha(i) = size(Aij,1) ;
            ACCUM_MEMORY = ACCUM_MEMORY + 8e-9*prod(size(Aij)) ; 
            if MEM.ACTIVE  == 0 | ACCUM_MEMORY <= DATA.MAXIMUM_STORAGE_SLOW_MEMORY 
                B{i,j} =Aij ;
            else
                disp('Saving ....')
                save(nameWS,'Aij') ;
                disp('....Done')
                B{i,j} = nameWS ;
            end
            
        else
            B{i,j} = nameWS ;
            
        end
        
        
        %  end
        % else
        %    nameWS = ['DATAWS/B_',num2str(i),'_',num2str(j),'.mat'] ;
        %    save(nameWS,'Bi') ;
        %    B{i,j} = nameWS ;
        %  end
        
    end
    %     if DATA.StoreSnapshotsRowWise==1
    %         disp('Storing in memory ....')
    %         save(B{i},'Brow')
    %         disp('... Done')
    %     end
    
    
end

%end

if MEM.ACTIVE  == 1 & MEM.GENERATE_AGAIN==1
    
    save(nameWS_glo,'alpha','beta') ;
    
elseif MEM.ACTIVE  == 1 & MEM.GENERATE_AGAIN==0
    
    load(nameWS_glo,'alpha','beta') ;
end





end







