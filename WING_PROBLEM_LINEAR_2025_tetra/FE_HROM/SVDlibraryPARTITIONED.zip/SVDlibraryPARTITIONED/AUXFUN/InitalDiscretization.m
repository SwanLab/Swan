function [ x M ] = InitalDiscretization(M,xLIM)

ndim = 3 ;
M = round(M^(1/3)) ; 
x= {} ;
Mglo = 1;
MPOINTS = [];
for idim = 1:ndim    
    x{idim} = linspace(xLIM(idim,1),xLIM(idim,2),M);%%%
end

M = M^3 ; 
