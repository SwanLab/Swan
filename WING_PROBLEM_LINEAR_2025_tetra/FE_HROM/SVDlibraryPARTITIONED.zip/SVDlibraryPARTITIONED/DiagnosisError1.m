clc
clear all

load('tmpERROR1.mat') ; 

disp('Actual rank')
[U,S,V] = SVD(cell2mat(B),0) ; 
disp(['r =',num2str(length(S))]);

 

[Q,L,gamma,nrowL,ncolL,epsilonSVD] = RORTHrow(B,beta,epsilon,DATA) ; 