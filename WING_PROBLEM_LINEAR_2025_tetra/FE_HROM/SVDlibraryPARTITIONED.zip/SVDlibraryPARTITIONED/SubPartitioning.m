function [alphaSUB betaSUB pSUB qSUB]= SubPartitioning(DATA,alpha,beta)
%dbstop('3')
if nargin ==0
    load('tmp1.mat')
end

alphaSUB = alpha ;%%%
betaSUB =beta ;
pSUB = []; 
qSUB = [] ; 
maxsize = DATA.MaxSizeMatrixGb ;
if DATA.TWOLEVELMETHOD.ACTIVE == 1
    
    SIZEA = sum(beta)*sum(alpha)*8e-9 ; %
    SIZEB = zeros(length(alpha),length(beta)) ;
    
    if SIZEA>maxsize
        for i = 1:length(alpha)
            for j = 1:length(beta)
                SIZEB(i,j) =  (beta(j))* (alpha(i))*8e-9 ; %
            end
        end
        
        if any(SIZEB > maxsize)
            switch   DATA.TWOLEVELMETHOD.TypePartition
                case 'UNIFORM'
                    N = sum(beta) ; M = sum(alpha) ;
                    p = length(alpha); q = length(beta);

                    
                    n = ceil(sqrt(maxsize/8*1e9)/sqrt(M/N)) 
                    m =  ceil( maxsize/8*1e9/n) 
                    
                    % Subpartitioning of row blocks
                    % -----------------------------
                    alphaSUB = {} ;
                    pSUB = [] ; 
                    for i=1:p
                        p_loc = ceil(alpha(i)/m) ;
                        alphaSUB{i} = MakePartition(alpha(i),p_loc) ; 
                        pSUB(i) = p_loc ; 
                    end
                 
                    betaSUB = {} ; qSUB = [] ; 
                    for i=1:q
                        q_loc = ceil(beta(i)/n) ;
                        betaSUB{i} = MakePartition(beta(i),q_loc) ; 
                          qSUB(i) = q_loc ; 
                    end
                     
                    
                otherwise                    
                    error('Option not implemented')
            end
        end
        
    end
    
    
    
    %     if SIZEA>maxsize
    %         for i = 1:length(alpha)
    %             for j = 1:length(beta)
    %                 SIZEB(i,j) =  (beta(j))* (alpha(i))*8e-9 ; %
    %             end
    %         end
    %
    %         if any(SIZEB)
    %             switch   DATA.TWOLEVELMETHOD.TypePartition
    %                 case 'UNIFORM'
    %                      f =ceil(SIZEA/maxsize) ;
    %                      N = sum(beta) ; M = sum(alpha) ;
    %                      p_new = ceil(sqrt(f))*M/N;
    %                      p = length(alpha);
    %                      q = length(beta) ;
    %                      if mod(p_new,p)~=0
    %                          p_new = ceil(p_new/p)*p ;
    %                      end
    %                      q_new = ceil(f/p_new) ;
    %                      if mod(q_new,q)~=0
    %                          q_new = ceil(q_new/q)*q ;
    %                      end
    %
    %                      alphaSUB = MakePartition(N,p_new) ;
    %                      betaSUB = MakePartition(M,q_new) ;
    %                 otherwise
    %
    %                     error('Option not implemented')
    %             end
    %         end
    %
    %         % Now we have to arranged alphaSUB and betaSUB so that it
    %         % approximately fits into the original alpha and beta
    %         error('Amend this')
    %
    %
    %     end
    %
    %
    %
    %     %                 switch   DATA.TWOLEVELMETHOD.TypePartition
    %     %                     case 'UNIFORM'
    %     %                         maxsize = DATA.MaxSizeMatrixGb ;
    %     %                         f =ceil(SIZEB/maxsize) ;
    %     %                         p_new = ceil(sqrt(f));
    %     %                         q_new = ceil(f/p_new) ;
    %     %                         alphaLOC = MakePartition(alpha(i),p_new) ;
    %     %                         betaLOC = MakePartition(beta(j),q_new) ;
    %     %                         alphaNEW{i,j} = alphaLOC  ;
    %     %                         betaNEW{i,j} = betaLOC ;
    %     %
    %     %                     otherwise
    %     %                         error('Option not implemented')
    %     %                 end
    %     %
    %     %             else
    %     %                 alphaNEW{i} = alpha(i) ;
    %     %                 betaNEW{i} = beta(j) ;
    %     %             end
    %     %         end
    %     %     end
    %     %
    %     %     %%%%
    %     %
    %
    %     %%%%%
  end