function  [U,S,V,i] = RSVD_tol(C,Omega,epsilon,dr)

%dbstop('4')
if nargin == 0
    load('tmp.mat')
    epsilon = 0.001 ;
end

R  = size(Omega,2) ;
Y  = C*Omega ;
Q  = orth(Y) ;
i = 0 ;
if size(Q,2) < R
    D = Q'*C ;
    [U,S,V] = SVD(D,epsilon);
    U = Q*U ;
else
    dR = min(ceil(dr*R),size(C,2)-R) ;    
    [U,S,V,i] = RSVDadap(C,Q,epsilon,dR) ;    
end

