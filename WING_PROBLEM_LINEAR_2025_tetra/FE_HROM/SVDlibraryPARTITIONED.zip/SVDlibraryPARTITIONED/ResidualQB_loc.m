function [dB  b db alphaLOC betaLOC]= ResidualQB_loc(B,Q,DATA)

[Qt_B b alphaLOC betaLOC] = Product_Qt_B(B,Q) ;
%% Difference betwee n B and Q*(Q^T B), and norm of each submatrix dB_{ij}
%-------------------------------------------------------------------------
iacum = 1;
dB= cell(size(B)) ;
dbMAT = zeros(size(B)) ;
disp(['Computing dB = B- Q*Q^T B'])
for i=1:size(B,1)
    for j=1:size(B,2)
      
        dB_name = [DATA.PATH_STORE_AUX,'dB_',num2str(i),'_',num2str(j),'.mat'] ;
        
        SSS = load(B{i,j}) ; % Loading (again) B_ij
        fff = fieldnames(SSS) ;
        INDICES = iacum:iacum+alphaLOC(i)-1 ;
        dBij = SSS.(fff{1})  - Q(INDICES,:)*Qt_B{j};
        disp(['Saving dB_',num2str(i),'_',num2str(j)])
        save(dB_name,'dBij')
        disp('...Done')
        dB{i,j} = dB_name ;
        dbMAT(i,j) = norm(dBij,'fro') ;
    end
    iacum = iacum + alphaLOC(i);
end
db = norm(dbMAT,'fro') ; % Norm of matrix "B"