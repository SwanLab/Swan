function varargout = SVD(B,epsilon)
%  SVD(B,epsilon) computes a truncated SVD of B (with relative tolerance epsilon)
%  It employs the built-in matlab function "svd", but it only returns the 
% singular values greater than
% the specified tolerance "epsilon".
%
% S = SVD(B,epsilon) gives a  vector with the singular values 
%
% [U,S] = SVD(B,epsilon) furnishes the matrix of left singular vectors and
% the associated singular values 
%
% [U,S,V] = SVD(B,epsilon)  returns the full factorization.
%
% Observation: notice that  norm(U*diag(S)*V'-B,'fro') <= norm(B,'fro')*epsilon 
% If epsilon = 0, then the truncation criterion is the epsilon machine
% parameter
%
% -----------------------------------
% Written by Joaquín  A. Hernández, December 2016. 
% UPC/CIMNE, Barcelona, Spain 
% jhortega@cimne.upc.edu
if nargin == 0
    M = 2000 ; N  = 2000 ; nrep = 5 ;
    B = rand(ceil(M/nrep),N) ;
    B = repmat(B,nrep,1) ;
end

CALCU =1 ;
CALCV = 1 ;
U = [] ;
V= [] ;

%DATA = DefaultField(DATA,'tol',0) ; 

dimMATRIX = max(size(B));
if nargout ==1
    CALCU = 0 ; CALCV = 0 ;
elseif nargout ==2
    CALCV = 0 ;
end
M = size(B,1); N = size(B,2);
if M>=N
    if CALCU==1 & CALCV==1
        [U, S,V] = svd(B,'econ') ;  % U --> M xN, V --> N x N
    elseif CALCU==1 & CALCV==0
        [U, S] = svd(B,'econ') ;  % U --> M xN, V --> N x N
    else
        S = svd(B,'econ') ;
    end
else    
    if CALCU==1 & CALCV==1
        [V, S,U] = svd(B','econ') ; % U --> M x M, V --> Nx M
    elseif  CALCU==1 & CALCV==0
        [~, S,U] = svd(B','econ') ; % U --> M x M, V --> Nx M
    else
        S = svd(B','econ') ;
    end
end
if size(S,2)>1
    S = diag(S) ; % S = [S1 S2 ... SR]'
end
tol = dimMATRIX*eps(max(S));
R = sum(S > tol);  % Definition of numerical rank
DATAOUT.normB = sqrt(sum(S(1:R).*S(1:R))) ;
%end

if  epsilon ==0
    K = R ;
else
    % Determining level of truncation
    %  dbstop('41')
    SingVsq =  (S.*S) ;
    DENOM = sum(SingVsq) ;    NOMINAD = DENOM-cumsum(SingVsq) ;
    normB = sqrt(DENOM) ; ERROR = sqrt(NOMINAD) ;
    K = (sum(ERROR>=epsilon*normB))+1 ;
end
K = min(R,K);

S = S(1:K);
if  ~isempty(U) & isempty(V)
    U = U(:,1:K)  ;
    varargout={U,S};
elseif ~isempty(U) & ~isempty(V)
    U = U(:,1:K)  ;
    V =  V(:,1:K) ;
    varargout={U,S,V};
    if nargout == 4
        varargout={U,S,V,DATAOUT};
    end
    
else
    varargout = {S} ;
end




