clc
clear all

addpath('AUXFUN')
if exist('rrqr')~=2
    addpath('rrqr')
end

% INPUTS -------------------------------------------
M = 1000 ;  % Number of rows
SIZE_B = 5e3 ;     % Size matrix (Mbytes)
R = 500  ; % Rank matrix, for DATA.TYPE = 1
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ; DATA.RetrieveBmemory = 0                                                                                                                      ;
N = ceil(SIZE_B/8*1e6/M) ; % Number of columns
N = 1000 ; 
Nmax = 999 ; % Number of columns that can be processed at onc
q =  20 ; % Number of partitions
epsilon = 0*ones(1,q) ; % Tolerance
rho = 2; 
RUN_PART = 0; RUN_DIR = 1 ;  RUN_NESTED = 1; RUN_RNESTED= 0; 
% END INPUTS --------------------------------------

% Generate matrix
beta = MakePartition(N,q) ;
B = GenerateMatrix(M,R,beta,DATA);
% ---

if RUN_PART == 1
    disp('Partitioned method')
    disp('---------------------')
    TIMEpart = tic ;
    [U,S,V,DATAOUT] = SVDcol(B,beta,epsilon,DATA) ;
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME part. = ',num2str(TIMEpart)])
    disp('---------------------')
end

if RUN_NESTED == 1
    disp('Nested method')
    disp('---------------------')
    TIMEpart = tic ;
    [Unest,Snest,Vnest,DATAOUT] = NSVDcol(B,beta,epsilon,Nmax,DATA) ;
    disp(['RANK = ',num2str(length(Snest))])
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME nested. = ',num2str(TIMEpart)])
    disp('---------------------')
    
end



if RUN_RNESTED == 1
    disp('Randomized Nested method')
    disp('---------------------')
    TIMEpart = tic ;
    R = 0 ; 
    [Unest,Snest,Vnest,DATAOUT] = RNSVDcol(B,beta,epsilon,Nmax,R,rho) ;
    disp(['RANK = ',num2str(length(Snest))])
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME nested. = ',num2str(TIMEpart)])
    disp('---------------------')
    
end



if RUN_DIR == 1
    disp('Direct method')
    disp('---------------------')
    TIMEdir = tic ;
    [Udir,Sdir,Vdir] = SVD(cell2mat(B),0);
    TIMEdir = toc(TIMEdir) ;
    disp(['TIME direct. = ',num2str(TIMEdir)])
    disp('---------------------')
end

% 
% COMPROBAR = 1;  
% 
% 
% if COMPROBAR == 1
%     
%     norm(abs(Udir(:,1))-abs(Unest(:,1)),'fro')
%     
% end