function  [A, alpha,beta] =   GroupSubPart(alphaSUB,betaSUB,DATA,pSUB,qSUB,p0,q0,DATALOC)

if ~isempty(pSUB)
    [Aext alphaSUB betaSUB] = GenerateMatrixBlock(alphaSUB,betaSUB,DATA,DATALOC);%%%
    
    
    
    alpha = cell(1,p0) ;
    beta = cell(1,q0) ;
    iACUM = 1 ;
    for i = 1:p0
        alpha{i} =  alphaSUB(iACUM:iACUM+pSUB(i)-1) ;
        iACUM = iACUM + pSUB(i); 
    end
    iACUM = 1;
    for i = 1:q0
       beta{i} =  betaSUB(iACUM:iACUM+qSUB(i)-1) ;
       iACUM = iACUM + qSUB(i); 
    end
    
    A = cell(p0,q0) ;
    iACUM = 1; 
    for i = 1:p0      
        jACUM = 1 ; 
        for j = 1:q0            
            A{i,j} = Aext(iACUM:iACUM+pSUB(i)-1,jACUM:jACUM+qSUB(j)-1);
            jACUM = jACUM + qSUB(j) ;
        end        
         iACUM = iACUM + pSUB(i); 
    end
    
    
else
    [A alpha beta] = GenerateMatrixBlock(alphaSUB,betaSUB,DATA,DATALOC);
    
end