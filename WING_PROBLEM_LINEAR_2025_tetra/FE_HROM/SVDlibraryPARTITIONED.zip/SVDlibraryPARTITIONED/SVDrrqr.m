function [U,S,V] = SVDrrqr(B)

% Rank revealing QR factorization
[Q,Rm,p,R] = rrqry(B);
Q = Q(:,1:R) ;  % Orthogonal basis matrix
[~,pINV] = sort(p) ;
Rm = Rm(1:R,pINV) ;
% SVD of R
[U,S,V] = svd(Rm,'econ') ;
U = Q*U ;
S = diag(S) ; % S = [S1 S2 ... SR]'