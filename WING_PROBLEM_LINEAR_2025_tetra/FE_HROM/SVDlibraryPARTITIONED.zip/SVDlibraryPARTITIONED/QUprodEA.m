function Unew = QUprodEA(Q,U,alpha,alpha_c)

if nargin == 0
    load('tmp3.mat')
end



%[alpha beta]= cellfun(@size,Q);

M = sum(alpha);
Unew = zeros(M,size(U,2)) ;
iacum = 1;
iacumNEW = 1;
for i =1:length(Q)
    
    
    nrows = alpha(i);
    indLLLnew = iacumNEW:(nrows+iacumNEW-1);
    ncols = alpha_c(i) ;
    
    if ~isempty(Q{i})
        indLLL = iacum:(ncols+iacum-1);
        Unew(indLLLnew,:) = Q{i}*U(indLLL,:) ;
        
         iacum = iacum+ncols ;
    end
   
    iacumNEW = iacumNEW+nrows ;
end