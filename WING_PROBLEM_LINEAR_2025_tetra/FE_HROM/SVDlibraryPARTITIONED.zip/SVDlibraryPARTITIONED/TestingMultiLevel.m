clc
clear all

format long g

addpath('AUXFUN')


% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
SIZE_A =8e3 ;     % Size matrix (Mbytes)
p0 =1;   % Number of partitions along rows
q0 = 10 ;  % Number of partitions along columns
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ERROR TOLERANCES
% -----------------------------------------
DATA.EPSILON_GLO = 1e-6; % Global tolerance
epsilon = 0.0*ones(p0,q0) ; % Tolerance
epsilon(end,end) = 0 ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs for the new version
% --------------------------
DATA.TWOLEVELMETHOD.ACTIVE = 1;  % To activate the multilevel method
DATA.TWOLEVELMETHOD.TypePartition = 'UNIFORM' ;  % Type of subparittion
DATA.TWOLEVELMETHOD.TryToUseFastMemory = 1;  % 
DATA.TWOLEVELMETHOD.LimitGbytes = 4;  % 
DATA.MaxSizeMatrixGb = 0.3; % Maximum size of a single submatrix
DATA.USE_SLOW_MEMORY.ACTIVE = 1 ;    % Use slow memory (default when twolevel is active)
DATA.USE_SLOW_MEMORY.GENERATE_AGAIN =0;  % Generate again matrix data


DATA.rho =1.05;  % Uncertainty factor (to estimate upper bound for rank of each submatrix)
DATA.dr = 1 ; % Incremental rank (relative)

%% DEFAULT OPTIONS
% ------------------
DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES  = 0; 
 DATALOC.RUN_NESTED = 1; 
DATA.LAST_SVD_RANDOM = 1;  % Last SVD is performed using RSVD
DATA.USE_ORTHwithTOL = 1 ;  % Default option (orthogonal decomp. of errors)
DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP =  1; 
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;  

DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;
N = ceil(sqrt(SIZE_A/8*1e6)) ; % Number of columns
M = N ;  % Number of rows
DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
COMPUTE_TRANSPOSE =0;
CALCULATE_ERROR_PART= 0 ; 

% END INPUTS -----------------------------------------------------
 
% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ; 
%for  iproj = 1:length(p0_glo)


NAMEWS = ['DATAWS/ETIME_GLO_size',num2str(SIZE_A),'_lim_',num2str(DATA.MaxSizeMatrixGb ),'_SAVE_',...
    num2str(DATA.USE_SLOW_MEMORY.ACTIVE),mfilename,'.mat'] ; 

[ETIME  Sincre] =...
    RSVD_QP_test(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE,CALCULATE_ERROR_PART,...
    DATALOC) ; 
%end 
 
save(NAMEWS,'ETIME')
