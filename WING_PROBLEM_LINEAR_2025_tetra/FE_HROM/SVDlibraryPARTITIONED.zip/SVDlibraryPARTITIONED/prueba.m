clc
clear all

A = rand(100,30) ; 
A = [A 0.5*A A*rand(size(A,2),100)] ; 
A = [A; A; A] ; 

rank(A)

 

Qr =rand(size(A,1),100) ; 
Qr =orth(Qr) ;

[U,S,V] = RSVDt(A,0) ;

Qr = orth(Qr - U*(U'*Qr)) ; 


a = norm(A,'fro') ; 
mu = max(size(A))*eps(a) ; 
Ar = Qr*Qr'*A ; 
[Ur,Sr,Vr] = RSVDt(Ar,0,mu) ; 




Al = A-Ar ; 

[Ul,Sl,Vl] = RSVDt(Al,0,mu) ; 

 