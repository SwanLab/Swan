clc
clear all
%%
addpath('AUXFUN')

% INPUTS -------------------------------------------
M = 3e3 ;  % Number of rows
R = 250  ; %  Upper Bound for rank
dR = ceil(0.2*R) ; %  For incrementally computing the rank (in case R <rank(C)). WE set Delta R = dR*R
%N = ceil(SIZE_B/8*1e6/M) ; % Number of columns
N = 3e3 ;
epsilon = 0.000 ; % Tolerance
alpha = M ;
beta = N ; q = [] ; DATA = [] ;
C = GenerateFunExampleNDIM3dBlock(M,N,alpha,beta,[],DATA);
C   = cell2mat(C) ;
M = size(C,1) ; N = size(C,2) ;
% END INPUTS
Omega = randn(N,R) ;
c = norm(C,'fro') ;
tic
[U,S,V,i] = RSVD(C,Omega,epsilon,dR) ;
Capprox = bsxfun(@times,U',S)' ;
Capprox  = Capprox*V' ;
disp(['RANK = ',num2str(length(S))])
toc
norm(C-Capprox,'fro')/c
toc
% disp('Approximated ...')
% tic
% [U,S,V,i] = RSVD_tolNINI(C,Omega,epsilon,dR) ;
% Capprox = bsxfun(@times,U',S)' ;
% Capprox  = Capprox*V' ;
% norm(C-Capprox,'fro')/c
% disp(['RANK = ',num2str(length(S))])
% 
% 
% toc
dbstop('40')
figure(1)
hold on
h = plot(log10(S),'r-') ;
legend(h,[' Incremental, rank =  ',num2str(length(S)),' niter =',num2str(i)])


ylabel('log(S)')
legend('show')

%%%
tic
[Ue,Se,Ve] = SVD(C,epsilon) ;
toc
Capprox = bsxfun(@times,Ue',Se)' ;
Capprox  = Capprox*Ve' ;
norm(C-Capprox,'fro')/c

disp(['RANK = ',num2str(length(Se))])

figure(1)
hold on
h = plot(log10(Se),'b-') ;
legend(h,[' Standard, rank =  ',num2str(length(Se))])


legend('off')
legend('show')



