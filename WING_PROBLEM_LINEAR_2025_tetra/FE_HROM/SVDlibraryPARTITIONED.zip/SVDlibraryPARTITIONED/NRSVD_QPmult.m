function [U,S,V,ETIME] = NRSVD_QPmult(A,alpha,beta,epsilon,DATA)
%
%dbstop('4')

if nargin == 0
    %  dbstop('6')
    load('tmp.mat')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT INPUTS
% ---------------
DATA = DefaultField(DATA,'EPSILON_GLO',0) ;
DATA = DefaultField(DATA,'LAST_SVD_RANDOM',0) ;
DATA = DefaultField(DATA,'MaxSizeMatrixGb',0.5) ;
DATA = DefaultField(DATA,'ITERMAX',10) ;
DATA = DefaultField(DATA,'USE_SLOW_MEMORY',[]) ;
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'ACTIVE',0) ;
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'GENERATE_AGAIN',1) ;
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'STORE_ALSO_SECOND_STEP',0) ;

DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'TryToUseFastMemory',1) ;
DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'LimitGbytes',3) ;


ETIME = [] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dbstop('14')
iter = 1 ;
SIZEA = 1e50 ;
Q = [] ; P = [] ; alpha_c = [] ;

DATA.PATH_STORE_AUX = [DATA.PATH_STORE_A,'AUX/'] ;
if exist(DATA.PATH_STORE_AUX)
    rmdir(DATA.PATH_STORE_AUX,'s')
end
mkdir(DATA.PATH_STORE_AUX)

if length(alpha) >1 | length(beta) >1
    %   while iter <= DATA.ITERMAX & SIZEA>=DATA.MaxSizeMatrixGb
    disp('----------------')
    disp('COMPUTATION OF Q and B  (basis for column space of A)')
    disp('----------------')
    tloc = tic ;
    % dbstop('28')
    DATA.EPSILON_ABSOLUTE_multi = 0 ;
    DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP_multi = 1;
    [Q A gamma alpha_b beta_b ETIME.Qoper Rmax] = RORTHmatrixMULT(A,alpha,beta,epsilon,DATA) ;
    
    
    %  dbstop('39')  [ dB b db alphaLOC betaLOC]= ResidualBlocksQB(Bi,Q,DATA) ;
    ETIME.Q = toc(tloc) ;
    DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP_multi = 0;
    disp('----------------')
    disp('COMPUTATION OF P  (basis for the row space of A)')
    disp('----------------')
    DATA.EPSILON_ABSOLUTE_multi = 1 ;
    tloc = tic ;
    DATA.Rini = Rmax ;
 %   dbstop('60')
    [P A gamma_c alpha_c beta_c ETIME.Poper Rmax] = RORTHmatrixMULT(A,alpha_b,beta_b,gamma',DATA) ;
    ETIME.P = toc(tloc) ;
    % Size A
    alpha_c = cell2mat(alpha_c) ; 
    beta_c = cell2mat(beta_c) ; 
    
    %
    %         if iter>1
    %             tloc2 = tic ;
    %             Q = Q*Qiter ;
    %             P = P*Piter ;
    %             ETIME_LOOP(iter).QPiter = toc(tloc2) ;
    %         else
    %             Q = Qiter ; P = Piter;
    %             ETIME_LOOP(iter).QPiter = 0 ;
    %         end
    %         SIZEA = sum(alpha_c)*sum(beta_c)*8e-9 ;
    %         %   dbstop('50')
    %         if SIZEA >= DATA.MaxSizeMatrixGb
    %             [A,alpha,beta] = CollapseCellMatrix(A,alpha_c,beta_c,DATA) ;
    %             epsilon = zeros(length(alpha),length(beta))
    %             iter = iter + 1;
    %             DATA.Rini = max([alpha_c beta_c]) ;
    %         end
    %     end
    
    
end




%%%%
disp('----------------')
disp('SVD of A <-- Q^T A P')
disp('----------------')
eLOC = 0 ;
if sum(sum(epsilon))==0; eLOC = DATA.EPSILON_GLO ; end
tloc = tic ;

dbstop('86')
A = cell2mat(A) ;
c = norm(A,'fro') ;
mu = (max(size(A))*eps(c))  ;
if  eLOC == 0
    e0 = mu ;
else
    e0 = c*eLOC ;
end
%  Omega = [] ;
%  dbstop('53')
if ~isempty(alpha_c)
    Rmax = max([alpha_c beta_c]) ;
else
    Rmax = ceil(0.05*min(size(A))) ;
end
Rest =  Rmax ;
dR =  Rest ;
Omega = randn(size(A,2),Rest) ;
DATA.COMPUTE_V_SVD = 1;
DATA.Omega = [] ;
[U,S,V] = RSVDt(A,e0,mu,Omega,DATA) ;
% end



ETIME.C = toc(tloc) ;
disp('---------------------------------------')
disp('DONE ... ')
disp('--------------------------------------')
disp('Computing left singular vectors U = X*Ubar')
tloc = tic ;

if ~isempty(Q) ;  U = Q*U ; end
ETIME.QUbar = toc(tloc) ;
disp('Done ')
disp('---------------------------------------')
disp('Computing righbt singular vectors V = P*Vbar')
tloc = tic ;
if ~isempty(Q) ; V = P*V ; end
ETIME.PVbar = toc(tloc) ;
disp('Done ')

%%%
rmdir(DATA.PATH_STORE_AUX,'s')