function [Q B gamma,alpha_b,beta_b,Rmax,ETIME_row] = RORTHmatrixINT(A,alpha,beta,epsilon,DATA)

if nargin == 0
    load('tmp.mat')
end

DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
DATA = DefaultField(DATA,'Rini',0) ;

p = length(alpha) ; Q = cell(1,p) ;   B = cell(size(A')) ;
gamma = zeros(size(A)) ;
alpha_b = beta ;
beta_b = zeros(size(alpha)) ;
Rmax = 0 ;
ETIME_row ={} ;
%dbstop('17')
disp('----------------')
disp('LOOP OVER ROW BLOCKS')
disp('----------------')
for i=1:p
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    [Qi,Bi,gamma(i,:),~,~,epsilonSVD,Rmax_loc,ETIME_row{i}] = RORTH1rowINT(A(i,:),beta,epsilon(i,:),DATA)   ; 
    DATA.Rini = Rmax_loc ;
    Rmax = max(Rmax,Rmax_loc) ;
    beta_b(i) = size(Qi,2) ;
    Q{i} = Qi ;
    B(:,i) = Bi;
end

end