function [U,S,V] = RSVD(C,epsilon,Omega)
% Randomized SVD
% INPUTS: C: Matrix to be factorized (M x n),
%         0<= epsilon <= 1: Error threshold
%         Omega: Randomized test matrix  (M x R), where R is an estimation
%         of rank(C)
% OUTPUT: U,S,V, truncated SVD, C =U*S*V' + E such that norm(E,'F')/norm(C,'F')<=epsilon
% % 10-Oct-2016, Joaquín A. Hernández, UPC-CIMNE, jhortega@cimne.upc.edu
% --------------------------------------------------------------------------------
if nargin == 0
    M = 3000 ; n  = 3000 ; R = 100 ;  nrep = 10 ;
    C = 1e3*rand(ceil(M/nrep),n) ;
    C = repmat(C,nrep,1) ;
    Omega = rand(n,R) ;
    epsilon = 0 ;
    METHOD = 0;
end

tic ;
[M n]= size(C);
R = min(n,R) ;

profile on

if METHOD == 1
    K = 0 ; T = 0 ;  Q =[] ; dR =R ;   j = 1 ; jmax =50 ;% Initializations
    while K==T & K < n & j<=jmax
        disp(['j=',num2str(j),' K=',num2str(K),' T = ',num2str(T)])
        if j==1
            dC = C;
        else
            dC = C - Q*(Q'*C); % % Orthogonal complement
            dR = min(R,n-R) ;
            Omega = rand(n,dR) ;
        end
        Y = dC*Omega; % R random combinations of the columns of dC
    %      nY = max(sqrt(sum(Y.*Y,1))) ; 
        % dQ = orth(Y) ; % Orthogonal matrix for range of Y
        Q =  orth([Q Y]) ;
        K = size(Q,2) ; T = T + R ; j = j +1 ;
     
    end
    
    %Q =orth(Q) ;
    
    
else
    K = R ;  Q =[] ; dR =R ;   j = 1 ; 
    Y = C*Omega;  r = K ; 
    while K==dR  & r <= n
        disp(['j=',num2str(j),' Upper bound rank =',num2str(r)])
        if j>1
            dR = min(R,n-K);
            Omega = rand(n,dR);
            Y = C*Omega ;
            Y  = Y- Q*(Q'*Y) ;
        end
        % Orthogonal basis for Y ---------------------
        [q,S] = svd(Y,'econ');
        S = diag(S);
        if j==1
            tol = max(size(Y)) * S(1) * eps(class(Y));
        end
        r = sum(S > tol);
        q = q(:,1:r);
        % ---------------------------------------------
        Q =  ([Q q]) ;
        K = size(q,2) ;
        j = j +1 ;
        r = r+ K  ; 
    end
    Q =orth(Q) ;
end

D = Q'*C ;
[U, S,V] = svd(D,'econ') ;
U = Q*U ;

S = diag(S) ; % S = [S1 S2 ... SR]'
tol = max(size(C))*eps(max(S));
R = sum(S > tol);
%R = length(S);  %  numerical rank



if  epsilon ==0
    K = R ;
else
    % Determining level of truncation
    SingVsq =  (S.*S) ;
    DENOM = sum(SingVsq) ;    NOMINAD = DENOM-cumsum(SingVsq) ;
    ERRORsvd = sqrt(NOMINAD)/sqrt(DENOM);
    K = length(find(ERRORsvd>=epsilon)) ;
end
K = min(R,K);
U = U(:,1:K)  ;
S = S(1:K)    ;
V =  V(:,1:K) ;


toc ;

profile off


dbstop('91')
COMPROBAR = 1;
if COMPROBAR == 1
    tic
    [Ue,Se,Ve] = svd(C,'econ') ;
    toc
    
    Ue = Ue(:,1:K);
    norm(abs(Ue)-abs(U))
end







