function [U,S,V,ETIME] = RSVD_rowINTERSEC(A,epsilon,DATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RSVD_rowINTERSEC returns a truncated SVD-like factorization  [U,S,V] of the form
%   A =  U*S*V^T + E
% --------------------------
 
%  Written by Joaquín A. Hernández Ortega, Dec. 2016
%  jhortega@cimne.upc.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
    
end

if exist('DefaultField') == 0
    addpath('AUXFUN')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT INPUTS
% ----------------------------------------------------
DATA = DefaultField(DATA,'EPSILON_GLO',0) ; % See preabmble
DATA = DefaultField(DATA,'USE_SLOW_MEMORY',[]) ; % See preamble
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'ACTIVE',0) ; % See preamble
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'STORE_ALSO_SECOND_STEP',0) ;  %
DATA = DefaultField(DATA,'EPSILON_GLO_isRELATIVE',1) ; % For multi-level version
DATA = DefaultField(DATA,'COMPUTE_V_LAST_SVD',1) ; % It computes the matrix of right-singular vectors
DATA = DefaultField(DATA,'TWOLEVELMETHOD',[]) ; % Two-level method
DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'ACTIVE',0) ; % Two-level method
DATA = DefaultField(DATA,'Rini',0) ; % Initial estimation for the rank
DATA = DefaultField(DATA,'TRANSPOSE',0) ; % 


 
%dbstop('88')
ETIME.TOTAL = tic ;
%%%%%% Checking inputs
%dbstop('91')
if isnumeric(A) || (iscell(A) && ischar(A{1,1})==0 && size(A,1)==1 & size(A,2)==1 )
    if  size(A,1)==1 & size(A,2)==1
        A = A{1,1} ;
    end
    DATA.PATH_STORE_AUX  = [] ;
    p = 1; q = 1; alpha = [] ; beta = [] ;
    DATA.TRANSPOSE = 0 ; 
else
    [p,q] = size(A) ; alpha = [] ; beta = [] ;
    if ischar(A{1,1})
        NAMEF = fileparts(A{1,1}) ;
        DATA.PATH_STORE_A = NAMEF ;
        DATA.PATH_STORE_AUX = [DATA.PATH_STORE_A,'AUXtmpj/'] ;  % Path in which temporary files are stored
    else
        DATA.PATH_STORE_AUX  = [] ;
        alpha= zeros(1,p) ; beta = zeros(1,q) ;
        for i = 1:p
            for j = 1:q
                alpha(i) = size(A{i,j},1) ;
                beta(j) = size(A{i,j},2) ;
            end
        end
    end
    
    if DATA.TRANSPOSE == 1
        alpha_new = beta ; 
        beta = alpha ; alpha = alpha_new; 
        p = length(alpha) ; q = length(beta) ; 
        A  = A' ;
        epsilon = epsilon' ; 
    end
    
    
end
% Creating folder for storing temporary files
if ~isempty( DATA.PATH_STORE_AUX ) && ~exist(DATA.PATH_STORE_AUX)
    mkdir(DATA.PATH_STORE_AUX)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q = [] ; P = [] ; alpha_c = [] ; ETIME_Qoper =[] ; ETIME_Poper = [] ; 
if p >1 | q >1
    % while iter <= DATA.ITERMAX & SIZEA>=DATA.MaxSizeMatrixGb
    disp('----------------')
    disp('COMPUTATION OF Q and B  (basis for column space of A)')
    disp('----------------')
    tloc = tic ;
    [Q A gamma alpha_b beta_b  Rmax ETIME_Qoper] ...
        = RORTHmatrixINT(A,alpha,beta,epsilon,DATA) ;
    ETIME.Q = toc( tloc) ;
    disp('----------------')
    disp('COMPUTATION OF P  (basis for the row space of A)')
    disp('----------------')
    DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP = 0;
    DATA.EPSILON_ABSOLUTE = 1 ;
    tloc = tic ;
    DATA.Rini = Rmax ;
   % dbstop('148')
    TRANSPOSE = DATA.TRANSPOSE ; DATA.TRANSPOSE = 0 ; 
    [P A gamma_c alpha_c beta_c Rmax ETIME_Poper] ...
        =  RORTHmatrix(A,alpha_b,beta_b,gamma',DATA) ;
    DATA.TRANSPOSE  = TRANSPOSE; 
    ETIME.P = toc( tloc) ;
else
    if ~isnumeric(A) & ~isnumeric(A{1,1})
        SSS = load(A{1,1}) ;
        fff = fieldnames(SSS) ;
        A = SSS.(fff{1}) ;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('----------------')
disp('SVD of A <-- Q^T A P')
disp('----------------')
eLOC = 0 ;
eLOC = DATA.EPSILON_GLO ; 
if ~isnumeric(A)
    A = cell2mat(A) ;
end
tloc = tic ;
c = norm(A,'fro') ;
%dbstop('159')
mu = (max(size(A))*eps(c))  ;  % Machine epsilon parameter
if DATA.EPSILON_GLO_isRELATIVE == 1
    if  eLOC == 0
        e0 = mu ;
    else
        e0 = c*eLOC ;
    end
else
    e0 = DATA.EPSILON_GLO ;
end
% -----------------------------------------
if DATA.Rini == 0
    DATA.Rini = ceil(0.05*min(size(A))) ;
end
if ~isempty(alpha_c)
    Rmax = max([alpha_c beta_c]) ;
else
    Rmax = min(DATA.Rini,max(size(A))) ;
end
Rest =  Rmax ;
DATA.COMPUTE_V_SVD = DATA.COMPUTE_V_LAST_SVD;
[U,S,V,eSVD,RankMatrix] = RSVDt(A,e0,mu,Rest,DATA) ;
% end
disp('---------------------------------------')
disp('DONE ... ')
disp('--------------------------------------')
ETIME.QAP = toc(tloc);
disp('Computing left singular vectors U = X*Ubar')
tloc = tic ;
%dbstop('188')
if ~isempty(Q)
    if iscell(Q)
        U = QUprod(Q,U,alpha) ;
    else
        U = Q*U    ;
    end
end


disp('Done ')
ETIME.U = toc(tloc) ;
tloc = tic ;
if  DATA.COMPUTE_V_LAST_SVD == 1
    disp('---------------------------------------')
    disp('Computing right singular vectors V = P*Vbar')
    if ~isempty(P)
        if iscell(P)
            V = QUprod(P,V,beta) ;
        else
            V = P*V    ;
        end
    end
    disp('Done ')
else
    P = [] ;
end
ETIME.V = toc(tloc) ;

if  DATA.TWOLEVELMETHOD.ACTIVE == 0 & ~isempty(DATA.PATH_STORE_AUX)
    rmdir(DATA.PATH_STORE_AUX,'s')
end

ETIME.TOTAL = toc(ETIME.TOTAL) ;
%dbstop('263')
ETIME.Qoper= ETIME_Qoper ; 
ETIME.Poper= ETIME_Poper ; 

if DATA.TRANSPOSE == 1
    Unew = V ; 
    V = U ; 
    U = Unew ;     
end


