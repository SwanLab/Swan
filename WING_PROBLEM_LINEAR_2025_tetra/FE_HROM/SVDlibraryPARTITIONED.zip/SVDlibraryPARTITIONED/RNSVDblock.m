function [U,S,V,DATAOUT] = RNSVDblock(A,alpha,beta,epsilon,Nmax,dr,rho,DATA)
%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('LOOP OVER ROW BLOCK MATRICES')
disp('----------------')
p = length(alpha) ; q = length(beta) ;
X = cell(1,p) ; K = cell(1,p) ; M = sum(alpha) ; 
N = sum(beta); Nmax = min(Nmax,min(M,N)-1) ; 
if ~iscell(A)
    A = mat2cell(A,alpha,beta) ;
end
r_up= zeros(1,q) ; % Estimation rank top row 
colK = zeros(q,1); 
%dbstop('19')
for i=1:p
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
    if isnumeric(A{i,1})   
        [Xi,Zi,Ti,R] = RNSVDcol(A(i,:),beta,epsilon(i,:),Nmax,r_up,dr,rho)   ; 
    else
        error('Option not implemented yet')
    end
    r_up = R ; 
    TTT= toc(TTT);    
    K{i} = bsxfun(@times,Ti',Zi)' ;
    %  dbstop('13')
    X{i} = sparse(Xi) ;
    disp(['R = ',num2str(length(Zi)),' of ',num2str(sum(beta)),' columns'])
    disp(['Time = ',num2str(TTT)])
    colK(i) = length(Zi) ; 
end

%dbstop('42')
X = blkdiag(X{:}) ;
disp('---------------------------------------')
disp('SVD of matrix K ... ')
disp('---------------------------------------')
A = cell2mat(K) ; % To free memory
clear K ; 
ncolK = size(A,2) ;
q = ceil(ncolK/Nmax);
gamma = MakePartition(ncolK,q) ;
r = max(colK)*ones(size(gamma)) ; dr = 1;
[V,S,Ubar,DATAOUT] = RNSVDcol(A,gamma,zeros(size(gamma)),Nmax,r,dr,rho)   ; 
disp('---------------------------------------')
disp('DONE ... ') 
U = X*Ubar ; 
