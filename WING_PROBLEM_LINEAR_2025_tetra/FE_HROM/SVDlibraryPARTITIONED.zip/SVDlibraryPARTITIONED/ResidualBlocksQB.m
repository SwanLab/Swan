function    [dB  b db alphaLOC betaLOC]= ResidualBlocksQB(B,Q,DATA)

if nargin == 0
    load('tmp1.mat')
    %
    %     [Bnum]= cellWS2mat(B);
    %
    %     Qt_B_num = Q'*Bnum ;
    
end

if isnumeric(B)
    dB = B - Q*(Q'*B) ;
    b = norm(B,'fro') ;
    db = norm(dB,'fro') ;
    alphaLOC = size(B,1) ;
    betaLOC = size(B,2)  ;
else
    % Product Q^T B and norm of B
    % ---------------
    % Qt_B  = Q_1^T B_11 + Q_1^T B_12 + Q_2^T \B_21
    if DATA.USE_FAST_MEMORY_BLOCK == 0
        
        [dB  b db alphaLOC betaLOC]= ResidualQB_loc(B,Q,DATA);
    else
        [dB  b db alphaLOC betaLOC]= ResidualQB_locCELL(B,Q,DATA);
    end
end




