function [Q,L,gamma,Pi] = RORTHrowNEW(B,beta,epsilon,DATA,Omega)
% DATA: Partitioned matrix B = {B1 B2 ... Bq},
% error threshold epsilon (1 x q), rank estimation r
% RESULT: L = [L1 L2 ... Lq], and G = diag(G1,G2 ...Gq), where Li = Di*Hi,
% and Bi = Di*Hi*Di^T + ERROR(epsilon)
dbstop('7')
if nargin == 0
    load('tmp1.mat')
   % rho = 0.1;
end
dr = DATA.dr;
rho = DATA.rho ;
DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(B) ;
L = cell(1,q) ; G = cell(1,q) ;
if ~iscell(B) % Convert B into a cell array of submatrices
    M = size(B,1) ;
    B = mat2cell(B,M,beta) ;
end
R = zeros(1,q) ; Rlft = 0 ;
Nm = 0 ; % Maximum number of columns
for i=1:length(B)
    Nm = max(Nm,size(B{i},2)) ;
end
%Omega = randn(Nm,Nm) ; % Random matrix
Q = [] ;

%INDICES = randperm(q)
%dbstop('30')
[~, INDICES] = sort(epsilon) ;

epsilonSVD = zeros(size(INDICES)) ;
gamma =  zeros(size(INDICES)) ;

for j=1:q
    
    i = INDICES(j) ;
    
    disp('------------------------------------------')
    disp(['i = ',num2str(j), '  of ',num2str(q)])
    TTT =tic ;
    
    Ni = size(B{i},2) ;
    %  dbstop('31')
    Rest = ceil(rho*Rlft); dR = ceil(Rest*dr) ;
    if Rest ==0; Rest = ceil(0.1*Ni); dR = Rest ;   end
    Rest = min(Rest,Ni);
    %     if Rest ==Ni
    %         % No random.
    %         NORANDOM = 1  ;
    %     else
    %         NORANDOM =  0 ;
    %     end
    %   Omega = randn(Ni,Rest) ;
    if j==1
        dB = B{i} ;
    else
        dB = B{i} - Q*(Q'*B{i}) ; % Residual
    end
    b = norm(B{i},'fro') ;
    % dbstop('20')
    mu = (max(size(dB))*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        if DATA.EPSILON_ABSOLUTE ==0
            e0 = epsilon(i)*b ;
        else
            %  dbstop('71')
            e0 = epsilon(i) ;
        end
    else
        disp('QUITA la b abajo')
        e0 = mu*b ;
    end
    
    %    if NORANDOM == 0
    [dQ,Hi,Gi,eSVD] = RSVDnew(dB,Omega(1:Ni,1:Rest),e0,dR,mu);
    %     else
    %       %%  dbstop('70')
    %      %   DATA.tol = mu ;
    %         [dQ,Hi,Gi] = SVD(dB,epsilon(i));
    %         eSVD = 0 ;
    %     end
    
    if epsilon(i) > 0
        %  if DATA.EPSILON_ABSOLUTE == 0
        epsilonSVD(i) = eSVD/b ;
        gamma(i) =  epsilon(i)*b - eSVD ;
        % else
        % end
    else
        epsilonSVD(i) = eSVD ;
    end
    
    if j>1
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    Q = [Q dQ];
    
    % L{i} = Q'*B{i} ;
    
    Rlft = size(dQ,2) ;
    
    TTT= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])
    
    disp(['Time = ',num2str(TTT)])
end

ncolL  = zeros(size(B)) ;
nrowL  = zeros(size(B)) ;


DATA = DefaultField(DATA,'SVD_after_each__ROW',0) ; 


%   dbstop('132')
L=[] ;
for i = 1:length(B)
    L = [L Q'*B{i}];
    %  ncolL(i) = size(L{i},2) ;
    nrowL(i) = size(B{i},2) ;
end



[U,S,Pi] = SVD(L,0); % No truncation
Q = Q*U ;
L = bsxfun(@times,Pi',S) ;
%L = mat2cell(L',nrowL,size(L,1)) ;

%error('Introduce ORTHOGONALIZATION  HERE')
    
    
    


end



%
% [U,S,V] = SVD(L,0); % No truncation
% U = Q*U ;

% Writing G in sparse format
% G = diagonal(G{1},G{2},...G{q})
%dbstop('26')

