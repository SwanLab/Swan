clc
clear all

TESTS = {'DATA19','DATA20','DATA21'}
ETIME = {} ; 

for i = 1:length(TESTS)

ETIME{i} = RunTestsFinal(TESTS{i});

end