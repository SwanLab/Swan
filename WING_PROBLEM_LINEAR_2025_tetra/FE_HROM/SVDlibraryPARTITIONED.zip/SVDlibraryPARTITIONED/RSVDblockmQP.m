function [U,S,V] = RSVDblockmQP(A,alpha,beta,epsilon,DATA)
%

if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('COMPUTATION OF Q and B  (basis for column space of A)')
disp('----------------')
%dbstop('12')
%dbstop('12')
[Q B gamma alpha_b beta_b] = RORTHglo(A,alpha,beta,epsilon,DATA) ;

% warning('-------')
%  A = cell2mat(A) ;
%  diffff = norm(A- Q*(Q'*A),'fro')


disp('----------------')
disp('COMPUTATION OF P  (basis for the row space of A)')
disp('----------------')
%gamma(:,:) = 0 ;  disp('Quita estoooo')
% DATA.rho = 0.08 ;
%  DATA = DefaultField(DATA,'gamma_zero',0);
%  if DATA.gamma_zero ==1
%      gamma(:,:) = 0 ;
%  end

if DATA.SYMMETRIC_QP == 1 ;
    % Q and P  are determined in an independent fashion
    %  dbstop('32')
    DATA.ISTRANSPOSE = 1;
    [P, ~, ~, ~, ~] = RORTHglo(A',beta,alpha,epsilon',DATA) ;
    C= [] ;
else
   % dbstop('37')
    DATA.EPSILON_ABSOLUTE = 1 ;
    DATA.epsilon_total = gamma' ;
     DATA = DefaultField(DATA,'SetGammaToZero',0) ; 
    if DATA.SetGammaToZero ==1
        gamma = zeros(size(gamma)) ; 
    end
    [P C gamma_c alpha_c beta_c] = RORTHglo(B,beta_b,alpha_b,gamma',DATA) ;
    
end

% B = cell2mat(B) ;
%diffff = norm(B- P*(P'*B),'fro')

%%%%

if ~isempty(C)
%    dbstop('54')
    disp('COMPUTATION OF SVD(Q^T A P)')
    DATA = DefaultField(DATA,'SVD_partitioned_LAST',0);
    if  DATA.SVD_partitioned_LAST == 1 ;
        error('This option doesn t work')
        gamma = zeros(size(C)) ;
        DATA.ISTRANSPOSE = 0;
 %       DATA.CALCULATE_C_AS_symmetric = 1 ; 
     [Qbar Cbar gamma_c] = RORTHglo(C,alpha_b,alpha_c,gamma,DATA) ;
       
         [Ubar,S,Vbar] = SVD(cell2mat(Cbar),0);
        
        Ubar = Ubar*Qbar ; % Pbar*Vbar ;
        
    else
    %    dbstop('69')
        DATA = DefaultField(DATA,'EPSILON_GLO',0) ; 
        eGLO = DATA.EPSILON_GLO; 
        
        if sum(epsilon)==0
            eLOC = eGLO ; 
        else
            eLOC = 0 ; 
        end
        
        [Ubar,S,Vbar] = SVD(cell2mat(C),eLOC);
    end
else
    % Symmetric version
    % -----------------
    % B = Q^T*A
    % Now we have to make B = B*P
    % We can convert B to a matrix; however, this may cause some memory
    % issues for large problems. Thus, we rather perform a blockwise
    % multiplications
    
    %  dbstop('60')
    disp(['----------------------------------'])
    disp('COMPUTATION OF  (Q^T A P)')
    C = cell(size(B,1),1) ;
    % dbstop('64')
    alpha_LAST = zeros(size(C));
    beta_LAST = size(P,2) ;
    for i  =1:size(B,1)
        disp(['irow=',num2str(i)])
        C{i} = cell2mat(B(i,:))*P ;
        alpha_LAST(i) = size(C{i},1) ;
        %       B(i,:) = cell(size(B(i,:))) ; % Free memory
    end
    clear B A;
    
    disp('COMPUTATION OF  svd(Q^T C P)')
    
    DATA = DefaultField(DATA,'LastSVDIncremental',1) ;
    dbstop('108')
    if DATA.LastSVDIncremental == 0
        [Ubar,S,Vbar] = SVD(cell2mat(C),0);
    else
        
        epsilonC = zeros(size(C')) ;
        DATA.ISTRANSPOSE = 1;
        %   dbstop('85')
        DATA.Rini = alpha_LAST(1) ;
        DATA.ComputeLtranspose = 1 ;
        [Pbar,C,gamma,nrowL,ncolL,epsilonSVD] = RORTHrow(C',alpha_LAST',epsilonC,DATA);
        % Now C = (C*Pbar) ;
        
        [Ubar,S,Vbar] = SVD(cell2mat(C),0);
        
        Vbar = Pbar*Vbar ;
        
    end
    
end
disp('---------------------------------------')
disp('DONE ... ')
disp('Computing left singular vectors U = X*Ubar')
U = Q*Ubar ;
disp('Done ')
disp('---------------------------------------')
disp('DONE ... ')
disp('Computing righbt singular vectors V = P*Vbar')
V = P*Vbar ;
disp('Done ')