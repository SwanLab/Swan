function [U,S,V] = RSVDblockmRC_nowork1(A,alpha,beta,epsilon,dr,rho,DATA)
%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('LOOP OVER ROW BLOCK MATRICES')
disp('----------------')
p = length(alpha) ; q = length(beta) ;
Q = cell(1,p) ; K = cell(1,p) ; M = sum(alpha) ;
P = cell(1,q) ;
N = sum(beta);
if ~iscell(A)
    A = mat2cell(A,alpha,beta) ;
end
colK = zeros(q,1);
%dbstop('19')

disp('-----------------------')
disp('LOOP OVER  ROW BLOCKs')
disp('-----------------------')

for i=1:p
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
    Rini = 0 ;
    [Xi,Li,INDICES,epsilonSVD] = RSVDincreCN(A(i,:),beta,epsilon(i,:),dr,rho,Rini,DATA)   ;      
    TTT= toc(TTT);
    K{i} = Li' ;
    %  dbstop('13')
    X{i} = sparse(Xi) ;
 %   dbstop('32')
    disp(['R = ',num2str(size(Li,1)),' of ',num2str(sum(beta)),' columns']) 
    disp(['Time = ',num2str(TTT)])
    colK(i) = size(Li,1);
end
X = blkdiag(X{:}) ;
disp('-----------------------')
disp('end LOOP OVER ROW BLOCKS')
disp('-----------------------')


disp('-----------------------')
disp('LOOP OVER COLUMN BLOCKS')
disp('-----------------------')

dbstop('53')
for i=1:q
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['COLUMN block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
    Rini = 0 ;
    DATA.ROWWISE = 0 ; 
    [Pi,Li,INDICES,epsilonSVD] = RSVDincreCN(A(:,i),alpha,epsilon(:,i),dr,rho,Rini,DATA)   ;      
    TTT= toc(TTT);
   % K{i} = Li' ;
    %  dbstop('13')
    P{i} = sparse(Pi) ;
 %   dbstop('32')
    disp(['R = ',num2str(size(Li,1)),' of ',num2str(sum(alpha)),' rows']) 
    disp(['Time = ',num2str(TTT)])
   % colK(i) = size(Li,1);
end
 P = blkdiag(P{:}) ;
disp('-----------------------')
disp('end LOOP OVER COLUMN BLOCKS')
disp('-----------------------')

dbstop('78')
disp('Product K{i} = P^T*(A*Q)_i')

for i = 1:length(K)
    disp(['i=',num2str(i),' of ',num2str(length(K))])
    K{i} = P'*K{i} ;
end

disp('...end ')

 

disp('---------------------------------------')
disp('SVD of matrix K ... ')
disp('---------------------------------------')
Rini = size(K{1},2);
epsilon = zeros(size(K)) ;
[Vbar,S,Ubar] = RSVDincre(K,[],epsilon,dr,rho,Rini)   ;
%dbstop('49')
%A = cell2mat(K) ; % To free memory
% %clear K ;
% Rest = max(colK) ;
% Omega = randn(size(A,2),Rest) ; dR =  Rest ;
% [V,S,Ubar,DATAOUT] = RSVD(A,Omega,0,dR)   ;
disp('---------------------------------------')
disp('DONE ... ')
disp('Computing left singular vectors U = X*Ubar')
U = X*Ubar ;
disp('Done ')
disp('Computing right singular vectors V = P*Vbar')
V = P*Vbar ;
disp('Done ')
