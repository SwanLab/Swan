clc
clear all

%%
CLASSIC_SVD = 1; % = 2, via eigenproblem
GENERATE_AGAIN = 1 ;

RANK_PRE = 50 ;
SIZE_A =0.2 ;     % Size matrix (Gbbytes)
p =1;   % Number of partitions along rows
q =  10 ;  % Number of partitions along columns
ratioNM  =100 ;
N = ceil(sqrt(SIZE_A/8*1e9)/sqrt(ratioNM))  ; % Number of columns
M = ceil( SIZE_A/8*1e9/N) ;  % Number of rows
DATASTORE = ['DATAWS/DATA_Amatrix/'] ;
NAMEWS_ALL = ['DATAWS/A_ws.mat']

beta = ceil(N/q) ;
beta = repmat(beta,1,q) ;
alpha = M ;
MAXSTORE = 4.1;

SEM = randn(alpha(1),RANK_PRE) ;


if   SIZE_A > MAXSTORE  ||  (SIZE_A < MAXSTORE  & GENERATE_AGAIN==1)
    disp('Generation')
    A = cell(p,q) ;
    for i = 1:length(alpha)
        disp(['i=',num2str(i)])
        for j = 1:length(beta) ;
            if  SIZE_A > MAXSTORE
                disp(['j=',num2str(j)])
                nameWS =[DATASTORE,'A_',num2str(i),'_',num2str(j),'.mat'] ;
                
                if GENERATE_AGAIN == 1
                    Aij = SEM*rand(size(SEM,2),beta(i)) ;
                    disp('Saving...')
                    save(nameWS,'Aij') ;
                    disp('End...')
                end
                
                A{i,j} = nameWS ;
                
                
            else
                disp(['j=',num2str(j)])
                A{i,j} = SEM*rand(size(SEM,2),beta(i)) ;
            end
        end
    end
    
    disp('End Generation')
    
    disp('SAving ...')
    save(NAMEWS_ALL,'A')
    disp('End')
    
else
    disp('Loading ...')
    load(NAMEWS_ALL,'A')
    disp('End ...')
end


if CLASSIC_SVD == 1
    disp('Classic SVD')
    A =cell2mat(A) ;
    tic
    [U,S]  =SVD(A,0) ;
    toc
    
    
      
     LEGG = 'CLASS. SVD'
    
elseif  CLASSIC_SVD == 2
    U = [] ; S= [] ; V =[] ;
    disp('Via eig(A^T*A)')
    A =cell2mat(A) ;
    tic
    [M,N] = size(A) ;
    if M>N
        [EIGVECT,EIGVAL] = eig(A'*A) ;
    else
        [EIGVECT,EIGVAL]  = eig(A*A') ;
    end
    
    [S iii] = sort(diag(EIGVAL),'descend') ;
    jjj = find(S >=0) ; 
    S = S(jjj) ; 
    iii = iii(jjj) ; 
    S=  sqrt(S) ;
    dimMATRIX = max(size(A));

    tol = dimMATRIX*eps(max(S));
    R = sum(S > tol);  % Definition of numerical rank
    S = S(1:R) ; 
    
    V = EIGVECT(:,iii(1:R)) ;
    
    U = A*bsxfun(@times,V',1./S)' ;
    
    
    
    toc
    
     LEGG = 'VIA COV.'
else
    
    epsilon = zeros(size(A)) ;
    [U,S,V,ETIME] =RSVDqp(A,epsilon) ;
    ETIME
    
    
    LEGG = 'PRSVD'
end

figure(1)
hold     on
xlabel('Modes')
ylabel('log10(S)')
h =  plot(log10(S),'r')
legend(h,LEGG)
