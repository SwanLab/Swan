function [U,S,V] = SVDtrun(A)

if nargin == 0
    load('tmp.mat')
end

m = size(A,1) ;
n = size(A,2) ;

if m>=n   
    W1 = orth(A);
    B = W1'*A;    
    [W2,S,V] = svd(B,'econ');
    U = W1*W2;   
    S = diag(S);
else
    
    W1 = orth(A');
    B = W1'*A';    
    [W2,S,U] = svd(B,'econ');
    V = W1*W2;   
    S = diag(S);
end
