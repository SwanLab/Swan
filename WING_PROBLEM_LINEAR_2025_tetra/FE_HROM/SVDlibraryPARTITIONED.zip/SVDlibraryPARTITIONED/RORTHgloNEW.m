function [Q B gamma,alpha_b,beta_b] = RORTHgloNEW(A,alpha,beta,epsilon,DATA)

if nargin == 0
    load('tmp.mat')
end

DATA = DefaultField(DATA,'EPSILON_ABSOLUTE1',0) ; 

p = length(alpha) ; q = size(beta,2) ;
Q = cell(1,p) ;  M = sum(alpha) ;
N = sum(beta);
B = cell(size(A')) ; 
%colK = zeros(p,1);
Mmax = (max([alpha  beta])); 
%Omega = randn(Mmax,Mmax) ; 
Omega = randn(Mmax,Mmax) ; 

gamma = zeros(size(A)) ; 
alpha_b = beta ; 
beta_b = zeros(1,p) ; 
%dbstop('14')
for i=1:p
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
  %  Rini = 0 ;
    [Qi,Bi,gamma(i,:),Pi] = RORTHrowNEW(A(i,:),beta,epsilon(i,:),DATA,Omega)   ;
 
    beta_b(i) = size(Qi,2) ; 
    TTT= toc(TTT);    
    %  dbstop('13')
    Q{i} = sparse(Qi) ;
   % B(:,i) = Bi' ; 
   % disp(['R = ',num2str(size(Bi,1)),' of ',num2str(sum(beta)),' columns']) 
    disp(['Time = ',num2str(TTT)])
  %  colK(i) = size(Li,1) ;
end



Q = blkdiag(Q{:}) ;


end