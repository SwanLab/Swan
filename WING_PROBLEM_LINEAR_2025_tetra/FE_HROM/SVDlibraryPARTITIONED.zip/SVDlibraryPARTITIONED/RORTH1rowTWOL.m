function [Q,L,gamma,nrowL,ETIME] = RORTH1rowTWOL(B,epsilon,DATA,irow)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Given a row block matrix B, RORTH1rowTWOL returns a matrix Q  that approximately
% spans the  column space of A (with accuracy specified by epsilon).
% --------------------------
% OBSERVARTION: This is the two-level version of RORTH1row
%
% INPUTS  (mandatory)
%------------------------------------------------------------------------------
%  B:      1 x q cell array containing a conforming partition of B, i.e.:
%
%     B = {B_11, B_12 ... B_1q}
%
%     In turn, each entry B_ij may be a numeric array, or the name of a MAT-file containing
%     the numeric array.
%
%   epsilon : Row matrix of threshold errors.  size(epsilon) = size(B), and
%     norm(E{i},'fro')/norm(B{i},'fro') <= epsilon(i). If
%     DATA.EPSILON_ABSOLUTE =0 , then
%     norm(E{i},'fro') <= epsilon(i)
%
%     where E{i} = B{i} -  Q*Q'*B{i}
%
%
%   OPTIONAL INPUTS  (with default values )
%   ----------------
%   1)  DATA.EPSILON_ABSOLUTE   = 0  (see definition epsilon)
%   2)  DATA.Rini = 0
%   3)  DATA.rho_est =0.05
%
%    DATA.Rini = Initial estimation for the rank of submatrix B{1}. The
%    default value is min(DATA.rho_est*ceil(max(size(B{1})))).
%
%
% -----------------------------------------------------------------------------
%
%  OUTPUTS
%  ------
%  Q  -->   Orthogonal matrix that   approximately spans the
%  column space of     B  (see description input data epsilon)%
%
%   L -->   Cell array of dimensions size(L) = size(B'),  where L{i} =
%   B{i}'*Q
%
%   GAMMA --> size(B) matrix containing the difference between the error made in approximating
%   each submatrix, and the specified tolerance:
%   GAMMA(i) = sqrt(epsilon(i)^2*norm(B{i}'fro')^2 - norm(E{i}),'fro')
%
%   nrowL: Number of rows of each submtrix  of L
%
%
%  ETIME --> Structure array containing the times required for computing Q
%
%
%  Written by Joaquín A. Hernández Ortega, January. 2016
%  UPC/CIMNE. jhortega@cimne.upc.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dbstop('59')
if nargin == 0
    load('tmp12.mat')
    
end

ETIME.loop = tic ;

R = zeros(size(B)) ;
q = length(B) ;  % Number of submatrices
% Submatrices with lower tolerances are addressed first
[~, INDICES] = sort(epsilon) ;
epsilonSVD = zeros(size(INDICES)) ; % Array with approximation errors
gamma =  zeros(size(INDICES)) ;
bnorm = gamma ;
Q = [] ;  % Initialization orthogonal matrix
L = cell(q,1) ; % Cell array containing B{i}'*Q

disp('----------------')
disp('LOOP OVER COLUMN SUBMATRICES  (UPPER LEVEL)')
disp('----------------')
for j=1:q
    i = INDICES(j) ; % We begin with the submatrix with lower tolerance
    disp('------------------------------------------')
    disp(['UPPER LEVEL column: i = ',num2str(j), '  of ',num2str(q), '  (row block =',num2str(irow),' of ',num2str(DATA.p),')' ])
    disp('------------------------------------------')
    
    %%% Size of block Bi
 %dbstop('87')
    if   iscell(B{j})  
        SIZE_Bi = 0 ;
        for iii=1:size(B{j},1)
            for jjj=1:size(B{j},2)
                BBB = dir(B{j}{iii,jjj}) ;
                SIZE_Bi = SIZE_Bi+ BBB.bytes*1e-9 ;
            end
        end
  
        
    elseif isnumeric(B{j}) 
        SIZE_Bi = prod(size(B{j}))*8e-9  ; 
    else
        error('Option not implemented')        
    end
    
    if SIZE_Bi < DATA.TWOLEVELMETHOD.LimitGbytes 
        DATA.USE_FAST_MEMORY_BLOCK = 1 ;  % The whole submatrix is stored in memory
    else
        DATA.USE_FAST_MEMORY_BLOCK = 0 ;
    end
    
    %     if ischar(B{i})
    %         % We have to load from memory the corresponding numeric array
    %         disp(['Loading ...'])
    %         SSS = load(B{i}) ; fff = fieldnames(SSS) ;
    %         if DATA.TRANSPOSE == 0
    %             Bi = SSS.(fff{1}) ; SSS = [] ;
    %         else
    %             Bi = SSS.(fff{1})' ; SSS = [] ;
    %         end
    %         disp(['...Done'])
    %     else
    %         if DATA.TRANSPOSE == 0
    %             Bi = B{i} ;
    %         else
    %             Bi = B{i}' ;
    %         end
    %     end
    
    
    if j==1
        %% Frobenius norm of Bi  
        %-----------------------
        [b, DATA.bMAT,  alphaLOC, betaLOC,dB]= normFRO(B{i},DATA) ;
        db = b ;
    else
        [ dB b db alphaLOC betaLOC]= ResidualBlocksQB(B{i},Q,DATA) ;
    end
    
    bnorm(i) = b ;
    
    % size Matrix
    %%%%%%%%%%%%%
    N = sum(betaLOC);
    M = sum(alphaLOC);
    mu = (max(M,N)*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        if DATA.EPSILON_ABSOLUTE_multi ==0
            e0 = epsilon(i)*b ;
        else
            e0 = epsilon(i) ;
        end
    else
        % If e0, then we set the absolute tolerance to the machine
        % precision parameter
        e0 = mu ;
    end
    % If e0 is not zero, but happens to be smaller than the machine
    % precision parameter, we then set e0 = max(e0,mu)
    e0 = max(e0,mu) ;
    
    if ~isempty(dB)
      
        
        if db > e0 | j==1
            
            % If the norm of the residual is larger than the prescribed
            % tolerance, then we iteratively compute the new basis vectors
            % of Q by invoking function RSVDt
            DATA.COMPUTE_V_SVD = 0 ;
            epsilonLOC = zeros(length(alphaLOC),length(betaLOC)) ;
            DATA.EPSILON_GLO = e0;
            DATA.EPSILON_GLO_isRELATIVE = 0 ;
            DATA.COMPUTE_V_LAST_SVD = 0 ;            
            [dQ,Hi,~,ETIMEloc,eSVD,RankMatrix] = RSVDqp(dB,epsilonLOC,DATA) ;
            if isempty(dQ)
                eSVD = db ;
            end
        else
            dQ = [] ; Hi = [] ;
            eSVD = db ;
        end
        
        if epsilon(i) > 0
            epsilonSVD(i) = eSVD/b ;
            gamma(i) =  sqrt((epsilon(i)*b)^2 - eSVD^2) ;
        else
            epsilonSVD(i) = eSVD ;
        end
    else
        dQ = [] ;        Hi = [] ;                eSVD = [] ;        RankMatrix = Rest ;
    end
    
    if j>1 & ~isempty(dQ)
        % Re-orthogonalization
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    % Augmenting the basis matrix
    Q = [Q dQ];
    
    % Estimation for the next submatrix
    if   ~isempty(dQ)
        Rest = RankMatrix ;
    else
        Rest = 1 ;
    end
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(N),' columns (rank = ',num2str(RankMatrix),')'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])
  %  R(j) = RankMatrix;
  
  
      if DATA.TryToPrecomputeQtB == 1 & ( epsilon(i)==0)
        % Pre-computing L
        
        
        
        if isstr(B{i})
            if  DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP ==0
                L{i} =Bi'*Q ;
                nrowL(i) = size(L{i},1) ;
                ncolMAX = max(ncolMAX,size(L{i},2)) ;
            else
                dirREF = dir(B{i}) ; dirREF = dirREF.name ;
                L{i}  =  [DATA.PATH_STORE_AUX,dirREF(1:end-4),num2str(i),'.mat'] ;
                Li = Bi'*Q ;
                save(L{i},'Li') ;
                nrowL(i) = size(Li,1) ;
                ncolMAX = max(ncolMAX,size(Li,2)) ;
            end
        else
            if DATA.TRANSPOSE == 0
                L{i} =Bi'*Q ;
            else
                L{i} =Bi*Q ;
            end
            
            
            nrowL(i) = size(L{i},1) ;
            ncolMAX = max(ncolMAX,size(L{i},2)) ;
        end
        
    end
  
  
end


ETIME.loop = toc(ETIME.loop) ;


ETIME.prodBQ = tic  ;
L = cell(q,1) ;

ncolL  = cell(size(B)) ;
nrowL  = cell(size(B)) ;
disp(['-------------------------------------'])
disp(['Computing B^T Q'])
disp(['-------------------------------------'])

%dbstop('185')

%rmdir(DATA.PATH_STORE_AUX);

%dbstop('214')
dB = {} ;
for i = 1:length(B)
    disp('*********************************************')
    disp('*********************************************')
    disp(['COLUMN BLOCK i = ',num2str(i),' of ',num2str(q)])
    disp('*********************************************')
    disp('*********************************************')
    
    if iscell(B{i})
        [L{i}  nrowL{i} ncolL{i} ] = Product_Bt_Q(B{i},Q,DATA) ;
    elseif isnumeric(B{i})
        L{i} =B{i}'*Q ;
        ncolL{i} = size(L{i},2) ;
        nrowL{i} = size(L{i},1) ;
    end
    
end

 

ETIME.prodBQ = toc(ETIME.prodBQ )  ;

