clc
clear all

format long g

addpath('AUXFUN')


% INPUTS -------------------------------------------------------------
SIZE_B = 0.05e3 ;     % Size matrix (Mbytes)
R = 500  ; % Rank matrix, for DATA.TYPE = 1
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ; DATA.RetrieveBmemory = 0 ;
DATA.StoreSnapshotsRowWise = 0 ; DATA.DoNotGenerateAgainSnapshots =0 ;
N = ceil(sqrt(SIZE_B/8*1e6)) ; % Number of columns
M = N ;  % Number of rows
DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
Nmax = N ; % Number of columns that can be processed at onc
RUN_INCREQP =1;
RUN_DIR = 0;
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
p0 = 1;  % Number of partitions along rows
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
q0 = 10; % Number of partitions along columns
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
COMPUTE_TRANSPOSE =1;
epsilon = 0.01*ones(p0,q0) ; % Tolerance
epsilon(:,end) = 1e-6;
%DATA.SetGammaToZero =0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT INPUTS
DATA.FractionTolerance = 1; % 1 ; %sqrt(0.5);
DATA.CalculateGammaAfterQ = 1;
DATA.SYMMETRIC_QP = 0;  % Q and P  are determined in an independent fashion
DATA.TOL_2ndstepORTHO = 1;  % Under the assumption that the error is decomposed orth. blockwise.
rho =1;  % Uncertainty factor (to estimate upper bound for rank of each submatrix)
dr = 1 ; % Incremental rank (relative)
%DATA.UpperBoundTotalRank = 1000 ;
DATA.DefineInitialRANDOM = 1;
DATA.nouseRORTH = 1;
RUN_NESTED = 0; RUN_RNESTED=0; RUN_INCRE=0 ;
rho =1;  % Uncertainty factor (to estimate upper bound for rank of each submatrix)
dr = 1 ; % Incremental rank (relative)
% END INPUTS -----------------------------------------------------


% Generate matrix (by tiling several copies of the same matrix)

beta = MakePartition(N,q0) ;
alpha = MakePartition(M,p0) ;
disp('Approximated size')

A = GenerateMatrixBlock(alpha,beta,DATA);


if COMPUTE_TRANSPOSE ==1 
    Anew = cell(size(A')) ; 
    for i=1:size(Anew,1)
        for j=1:size(Anew,2)
            Anew{i,j} = A{j,i}' ; 
            A{j,i} = [] ; 
        end
    end
    A = Anew ;
    
end
A = cell2mat(A);

 


if COMPUTE_TRANSPOSE == 1
    qOLD = q0; pOLD = p0 ;
    p0 = qOLD ; q0=pOLD ;
    epsilon = epsilon' ;
    nrepROWSold = nrepROWS ; nrepCOLSold = nrepCOLS ;
    nrepROWS = nrepCOLSold ;
    nrepCOLS = nrepROWSold ;
end

A = repmat(A,nrepROWS,nrepCOLS) ;
q = q0*nrepCOLS ;
p = p0*nrepROWS ,
beta = MakePartition(size(A,2),q) ;
alpha = MakePartition(size(A,1),p) ;
A =mat2cell(A,alpha,beta) ;

epsilon = repmat(epsilon,nrepROWS,nrepCOLS) ;

disp([num2str(sum(alpha)*sum(beta)*8e-6),' Mbytes'])
% ----------------------------------------------------------------




% -------------------------------------------------------------------

hold on
figure(1)
ylabel('log10(Singular Values)')

if RUN_INCRE == 1 | RUN_INCREQP ==1
    disp('Randomized incremental method')
    disp('---------------------')
    TIMEpart = tic ;
    
    if  RUN_INCREQP==1
        DATA.dr = dr ;
        DATA.rho = rho ;
        [Uincre,Sincre,Vincre] = RSVDblockmQP(A,alpha,beta,epsilon,DATA) ;
        LLL = ' QP';
    elseif  RUN_INCRE==1
        
        [Uincre,Sincre,Vincre] = RSVDblockm(A,alpha,beta,epsilon,dr,rho,DATA) ;
        LLL = [] ;
        
    end
    
    
    disp(['RANK = ',num2str(length(Sincre))])
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME incre (random). = ',num2str(TIMEpart)])
    disp('---------------------')
    disp('---------------------')
    figure(1)
    hold on
    h = plot(log10(Sincre),'k') ;
    legend(h,['INCRE',LLL,', p = ',num2str(p), ', q=',num2str(q),' RANK = ',num2str(length(Sincre))])
    legend('off')
    legend('show')
    
    a = 0;
    %         A = cell2mat(A) ;
    %         p = 1;
    %
    %         beta = MakePartition(size(A,2),q) ;
    %         alpha = MakePartition(size(A,1),p) ;
    %         A = mat2cell(A,alpha,beta) ;
    
    %  epsilon = 0.01*ones(size(A)) ;
    [ERROR,RANK] = DiffApproxSVD( Uincre(:,1:end-a),Sincre(1:end-a),Vincre(:,1:end-a),[],A) ;
    
    
end


if RUN_NESTED == 1
    disp('Nested method')
    disp('---------------------')
    TIMEpart = tic ;
    [Unest,Snest,Vnest] = NSVDblock(A,alpha,beta,epsilon,Nmax,DATA) ;
    disp(['RANK = ',num2str(length(Snest))])
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME nested. = ',num2str(TIMEpart)])
    disp('---------------------')
    
    figure(1)
    hold on
    h = plot(log10(Snest),'r') ;
    legend(h,['NESTED, p = ',num2str(p), ', q=',num2str(q),' RANK = ',num2str(length(Snest))])
    legend('off')
    legend('show')
    a= 0 ;
    [ERROR,RANK] = DiffApproxSVD( Unest(:,1:end-a),Snest(1:end-a),Vnest(:,1:end-a),[],A) ;
    
    
end


% %
% if RUN_RNESTED == 1
%     disp('Randomized Nested method')
%     disp('---------------------')
%     TIMEpart = tic ;
%
%     [Unest,Srnest,Vnest,DATAOUT] = RNSVDblock(A,alpha,beta,epsilon,Nmax,dr,rho,DATA) ;
%     disp(['RANK = ',num2str(length(Srnest))])
%     TIMEpart = toc(TIMEpart) ;
%     disp(['TIME nested (random). = ',num2str(TIMEpart)])
%     disp('---------------------')
%
%     figure(1)
%     hold on
%     h = plot(log10(Srnest),'b') ;
%     legend(h,['RNESTED, p = ',num2str(p), ', q=',num2str(q)])
%     legend('off')
%     legend('show')
%
% end
%
%
%

%
%
%
%

if RUN_DIR == 1
    disp('Direct method')
    disp('---------------------')
    TIMEdir = tic ;
    [Sdir] = SVD(cell2mat(A),0);
    TIMEdir = toc(TIMEdir) ;
    disp(['TIME direct. = ',num2str(TIMEdir)])
    disp('---------------------')
    
    figure(1)
    hold on
    h = plot(log10(Sdir),'y') ;
    legend(h,['DIR, p = ',num2str(p), ', q=',num2str(q)])
    legend('off')
    legend('show')
    
end
% %
% % COMPROBAR = 1;
% %
% %
% % if COMPROBAR == 1
% %
% %     norm(abs(Vdir(:,10))-abs(Vnest(:,10)),'fro')
% %
% % end