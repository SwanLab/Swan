clc
clear all

addpath('AUXFUN')

n =140 ;  [20 40 60 80 100 ] ;
RECOMPUTE = 1 ;
NAMEWS = ['DATAWS/tmp_runLq.mat'] ;
DATA.Product_Q_U_nosparse = 1 ;
DATA.PartialStore_BtQ = 1 ;


if RECOMPUTE == 1
    Mall= []; Nall = [];
    ETIME_ALL ={} ;
    SIZE_ALL = [] ;
    for i = 1:length(n)
        
        A =rand(n(i),n(i)) ; A= [A 4*A 5*A 8*A 0.1*A A  A A 0.6*A 0.5*A] ;
        A = [A cos(A) cos(A) sin(A) -sin(A)];
        A = [A 7*A 8*A 10*A] ;
        A = [A; 0.5*A ;7*A.^2; A ] ;
        A = [A; A+1] ;
        A = [A+3 ; cos(A)] ;
        A = [A+1 ; 0.6*A] ;
        A = [A 0.7*A (0.01*A+1)] ;
        
          A = A' ;
        SIZEA = size(A,1)*size(A,2)*8e-9 ;
        SIZE_ALL(i) = SIZEA;
        Mall(i) = size(A,1) ;
        Nall(i) = size(A,2) ;
        
        epsilon = 0 ;
        DATA.MaxSizeMatrixGb =0.01;
        
        
        
        if SIZEA > DATA.MaxSizeMatrixGb
            % Partition A into submatrices of size below the specified threshold
            [M N ] = size(A) ;
            f =SIZEA/DATA.MaxSizeMatrixGb;
            p = 1;%sqrt(f*N/M) ;
            q = 100; % sqrt(f*M/N);
            %             [nmin iii] = min([p,q]);
            %             nmin = ceil(nmin) ;
            %             if iii==1
            %                 p = nmin ;
            %                 q = ceil(f/nmin);
            %             else
            %                 q=nmin ;
            %                 p = ceil(f/nmin) ;
            %             end
            
            
            %   p = ceil(sqrt(f)*M/sqrt(N^2 + M^2));
            %  q = ceil(f/p) ;
            alpha = MakePartition(M,p) ;
            beta = MakePartition(N,q) ;
            A = mat2cell(A,alpha,beta) ;
            DATA.EPSILON_GLO = epsilon ;
            epsilon = zeros(p,q) ;
            
        end
        
        
        
        [U,S,V,ETIME]= RSVDqp(A,epsilon,DATA) ;
        
        disp(ETIME)
        
        ETIME_ALL{i} = ETIME ;
        
    end
    
    save(NAMEWS,'ETIME_ALL','Mall','Nall','SIZE_ALL')
    
else
    load(NAMEWS,'ETIME_ALL','Mall','Nall','SIZE_ALL')
end


TIME_proj.Q = zeros(length(n),1) ;
TIME_proj.P = zeros(length(n),1) ;
TIME_proj.U = zeros(length(n),1) ;
TIME_proj.V = zeros(length(n),1) ;
TIME_proj.QAP = zeros(length(n),1) ;
TIME_proj.TOTAL = zeros(length(n),1) ;

fff = fieldnames(ETIME_ALL{1});


for iproj = 1:length(ETIME_ALL)
    ETIME = ETIME_ALL{iproj} ;
    for j = 1:length(fff)
        tloc =ETIME.(fff{j}) ; %/ETIME.TOTAL ;
        TIME_proj.(fff{j})(iproj) = tloc ;
    end
    
end



figure(1)
hold on
RR = Mall./Nall ;
title(['RAtio between number of columns and number of rows = ',num2str(RR(1))])
xlabel('Size (Gb)')
ylabel('Computing time (s)')
COLORS = {'r','b','g','m','y','b-','k--'}
h = [] ;

for j = 1:length(fff)
    h(j) =  plot(SIZE_ALL,TIME_proj.(fff{j}),COLORS{j}) ;
end

legend(h,fff)

