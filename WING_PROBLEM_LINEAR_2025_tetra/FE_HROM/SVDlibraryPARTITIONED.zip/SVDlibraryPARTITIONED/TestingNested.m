clc
clear all

format long g

addpath('AUXFUN')


% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
SIZE_B = 3e3 ;     % Size matrix (Mbytes)
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;
N = ceil(sqrt(SIZE_B/8*1e6)) ; % Number of columns
M = N ;  % Number of rows
DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
p0 = [5];  % Number of partitions along rows
q0 = [5]; % Number of partitions along columns
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
COMPUTE_TRANSPOSE =0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ERROR TOLERANCES
% -----------------------------------------
epsilon = 0.0*ones(p0,q0) ; % Tolerance
epsilon(:,[1 end]) = 0; % Tolerance
DATA.EPSILON_GLO = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs for the new version
% --------------------------
rho =1;  % Uncertainty factor (to estimate upper bound for rank of each submatrix)
dr = 1 ; % Incremental rank (relative)

% END INPUTS -----------------------------------------------------


% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[A,alpha,beta,epsilon,p,q] =GenerateMatrixGlo(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE) ;




disp('Definite QP incremental method')
disp('-------------------------------')
DATA.dr = dr ;
DATA.rho = rho ;
TIMEpart = tic ; 
[Uincre,Sincre,Vincre,ETIME] = RSVD_QP(A,alpha,beta,epsilon,DATA) ;
LLL = 'new QP';



disp(['RANK = ',num2str(length(Sincre))])
TIMEpart = toc(TIMEpart) ;
disp(['Total time  = ',num2str(TIMEpart)])
disp('---------------------')
disp('---------------------')
figure(1)
hold on
h = plot(log10(Sincre),'k') ;
legend(h,['INCRE',LLL,', p = ',num2str(p), ', q=',num2str(q),' RANK = ',num2str(length(Sincre))])
legend('off')
legend('show')

a = 0;

%  epsilon = 0.01*ones(size(A)) ;
[ERROR,RANK] = DiffApproxSVD( Uincre(:,1:end-a),Sincre(1:end-a),Vincre(:,1:end-a),[],A) ;

