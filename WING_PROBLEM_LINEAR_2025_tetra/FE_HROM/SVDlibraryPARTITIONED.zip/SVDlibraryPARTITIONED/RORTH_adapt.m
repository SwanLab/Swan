function Q = RORTH_adapt(C,Omega,mu)
%
% RORTH_adapt iteratively construct an orthogonal basis matrix for the
% range of matrix C.
%
% INPUTS:
% ------
% C --> M x N matrix
%  Optional inputs
% ---------------
% Omega --> N x R random matrix (R is an estimation for an upper bound of rank(C))
% mu --> Tolerance (machine epsilon parameter)
%
% if nargin == 1, then R = ceil(0.05*min(size(C))),
%    and mu =  min(size(C))*eps(norm(C,'fro'))
%
% OUTPUT:
% ------
% Q --> Orthogonal basis matrix such that norm(C-Q*Q'*C,'fro') <= mu
%
% This function is partially based on the randomized range finder algorithm
% proposed by Martisoon et al (2015) "A randomized blocked algorithm for efficiently computing
% rank-revealing factorizations of matrices".  The main novelty of our
% approach is the use of random matrices of varying size (the size of each random matrix is
%  estimated based on linear rank predictions).
% Written by Joaquín  A. Hernández, December 2016.
% UPC/CIMNE, Barcelona, Spain
% jhortega@cimne.upc.edu
%

%dbstop('33')

if nargin == 0
    load('tmp.mat')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%
[M,N] = size(C);

if nargin ==1  || isempty(Omega)
    R = ceil(0.05*min(size(C))); % Rank estimation (initial value)
    Omega = randn(N,R) ;  % Random matrix
    nC = norm(C,'fro') ; % Norm of the initial residual
    mu =   (max(size(C))*eps(nC))  ;  ; % MAchine precision parameter
else
    R  = size(Omega,2) ;  % Estimated rank
    nC = [] ;
end
disp(['Testing rank =  ',num2str(R),' ...'])
Q = ORTH(C*Omega,mu) ; % Initial basis matrix
i = 1; 
if ~isempty(Q)
    % If size(Q,2) < R, then Q is the desired basis matrix, and no more
    % operations are required. Otherwise, if
    if size(Q,2) == R  
        % We have to incrementally augment Q       
        dRmin = ceil((N-R)/50) ;  %  Minimum size for rank increment
        dR = ceil((N-R)/50 ) ; % Size of the first rank increment
        C = C - Q*(Q'*C) ; % Residual
        nC = norm(C,'fro') ; % Norm of the residual  
        disp(['iter = ',num2str(0),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
        R = R + dR ; 
        while nC>=mu      
            disp(['Testing rank =  ',num2str(R),' ...'])
            nC_old = nC ;
            R_old = size(Q,2) ;
            Omega = randn(N,dR) ; %  Draw a N x dR random matrix
            Qi = ORTH(C*Omega,mu); % Orthogonal basis matrix for residual 
            if ~isempty(Q)
                Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
            end
            C = C - Qi*(Qi'*C) ; % New residual
            Q = [Q Qi] ;  % Basis matrix is augmented with Qi
            nC = norm(C,'fro') ; %
            disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
            R_new = size(Q,2);
            % Estimated rank (linear)
            Rest = R_old+ (R_new-R_old)/(nC-nC_old)*(mu - nC_old) ;
            % Estimated increment
            dR = ceil(Rest-R_new) ;
            dR = max(dR,dRmin);
            R = R_new+ dR ;
            if R >=N
                 %%%% The estimated rank is larger than the number of
                 %%%% columns. It makes no sense to employ randomization to
                 %%%% reveal the rank of C
                 Q ='FULL' ; 
                 break
            end
            i = i + 1 ;
        end
        
    %   disp(['Upper bound for rank = ',size(Q,)])  
    else
        disp(['Upper bound for rank = ',num2str(size(Q,2))])  
    end
    
end
