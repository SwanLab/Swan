function [b bMAT alphaLOC betaLOC,dB]= normFRO(B,DATA)

if nargin == 0
    load('tmp4.mat')
end

bMAT = [] ; alphaLOC = [] ; betaLOC = [] ;
dB = B ;
if iscell(B) | isstr(B)
    
    if ischar(B)
        disp(['Loading ...'])
        SSS = load(B) ;
        fff = fieldnames(SSS) ;
        B = SSS.(fff{1}) ; SSS = [] ;
        disp(['...Done'])
        b = norm(B,'fro');
    else
        bMAT = zeros(size(B)) ;
        disp(['Loading  Bi ...'])
        for i=1:size(B,1)
            disp('---------------------------------------------')
            disp(['Loading block i=',num2str(i),' of ',num2str(size(B,1))])
            disp('---------------------------------------------')
            for j=1:size(B,2)
                disp(['j=',num2str(j),' of ',num2str(size(B,2))])
                SSS = load(B{i,j}) ;
                fff = fieldnames(SSS) ;
                %   Bij = SSS.(fff{1}) ; SSS = [] ;
                
                alphaLOC(i) = size(SSS.(fff{1}),1) ;
                betaLOC(j) = size(SSS.(fff{1}),2) ;
                %   DATA.nrow
                bMAT(i,j) =  norm(SSS.(fff{1}),'fro');
                if DATA.USE_FAST_MEMORY_BLOCK == 1
                    dB{i,j} = SSS.(fff{1}) ;
                end
                
            end
        end
        disp(['...Done'])
        b = norm(bMAT,'fro') ;
    end
else
    b = norm(B,'fro');
end