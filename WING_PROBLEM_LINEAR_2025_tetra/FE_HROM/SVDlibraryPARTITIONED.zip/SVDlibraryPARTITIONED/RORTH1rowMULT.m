function [Q,L,gamma,nrowL,ncolL,epsilonSVD,tloc,Rmax,tsave] = RORTH1rowMULT(B,beta,epsilon,DATA)

%dbstop('4')
if nargin == 0
    
    load('tmp2.mat')
    
end
dr = DATA.dr;
rho = DATA.rho ;
%DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
DATA = DefaultField(DATA,'Rini',0) ;


disp('----------------')
disp('----------------')
disp('LOOP OVER BLOCKS (UPPER LEVEL)')
disp('----------------')
disp('----------------')

q = length(B) ;
G = cell(1,q) ;
% if ~iscell(B) % Convert B into a cell array of submatrices
%     M = size(B,1) ;
%     B = mat2cell(B,M,beta) ;
% end
R = zeros(1,q) ;
Rlft = DATA.Rini ;

[~, INDICES] = sort(epsilon) ;

epsilonSVD = zeros(size(INDICES)) ;
gamma =  zeros(size(INDICES)) ;


bnorm = gamma ;
tloc = zeros(1,q) ;
Q = [] ;
tsave = 0 ;

 
for j=1:q
    
    i = INDICES(j) ;
    disp('------------------------------------------')
    disp(['UPPER LEVEL column: i = ',num2str(j), '  of ',num2str(q), '  (row block =',num2str(DATA.i),' of ',num2str(DATA.p),')' ])
    disp('------------------------------------------')
    TTT =tic ;

    
    %%% Size of block Bi 
    SIZE_Bi = sum(DATA.alpha_i)*sum(beta{i})*8e-9 ;
    if SIZE_Bi < DATA.TWOLEVELMETHOD.LimitGbytes & DATA.TWOLEVELMETHOD.TryToUseFastMemory == 1
        DATA.USE_FAST_MEMORY_BLOCK = 1 ;    
    else
        DATA.USE_FAST_MEMORY_BLOCK = 0 ; 
    end
    
    %%%
    
    
    
    if j==1
        
        %% Frobenius norm of Bi  (and dB if DATA.USE_FAST_MEMORY = 1)
        %-----------------------
        [b, DATA.bMAT,  alphaLOC, betaLOC,dB]= normFRO(B{i},DATA) ;
        db = b ;
    else
    %    dbstop('91')
        dB = {} ; 
        [ dB b db alphaLOC betaLOC]= ResidualBlocksQB(B{i},Q,DATA) ;
    end
    
    
    
    
    bnorm(i) = b ;
    
    % size Matrix
    %%%%%%%%%%%%%
    N = sum(betaLOC);
    M = sum(alphaLOC);
    
    mu = (max(M,N)*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        if DATA.EPSILON_ABSOLUTE_multi ==0
            e0 = epsilon(i)*b ;
        else
            e0 = epsilon(i) ;
        end
    else
        e0 = mu ;
    end
    
    e0 = max(e0,mu) ;
    
    if ~isempty(dB)
        %      dbstop('95')
        %         if j>1
        %             % db = norm(dB,'fro');
        %             [db DATA.bMAT  ]= normFRO(Bi) ;
        %         else
        %             db = b ;
        %         end
        if db > e0 | j==1
            
            %     [dQ,Hi,Gi,eSVD] = RSVDt(dB,DATA.Omega(1:Ni,1:Rest),e0,dR,mu,DATA);
            epsilonLOC = zeros(length(alphaLOC),length(betaLOC)) ;
            DATA.EPSILON_GLO = e0;
            DATA.EPSILON_GLO_isRELATIVE = 0 ;
            DATA.COMPUTE_V_LAST_SVD = 0 ;
            %     dbstop('116')
            %  DATAPath = DATA.PATH_STORE_A  ;
            %  DATA.PATH_STORE_A = DATA.PATH_STORE_AUX  ;
            [dQ,Hi,Gi,ETIME,eSVD,RankMatrix] = NRSVD_QP(dB,alphaLOC,betaLOC,epsilonLOC,DATA) ;
            %   DATA.PATH_STORE_A  = DATAPath ;
            
            if isempty(dQ)
                eSVD = db ;
            end
        else
            dQ = [] ; Hi = [] ; Gi = [] ;
            eSVD = db ;
            RankMatrix = 0 ;
        end
        
        
        if epsilon(i) > 0
            epsilonSVD(i) = eSVD/b ;
            
            gamma(i) =  sqrt((epsilon(i)*b)^2 - eSVD^2) ;
        else
            epsilonSVD(i) = eSVD ;
        end
    else
        dQ = [] ;
        Hi = [] ;
        Gi = [] ;
        eSVD = [] ;
        RankMatrix = 0 ;
    end
    
    
    
    
    if j>1 & ~isempty(dQ)
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    
    
    
    
    Q = [Q dQ];
    
    %  R(j) = length(Hi) ;
    R(j) =   RankMatrix ;
    if   ~isempty(dQ)
        %     Rlft = size(dQ,2) ;
        Rlft = RankMatrix  ;
    end
    
    
    
    
    tloc(j)= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(sum(betaLOC)),' columns (RANK = ',num2str(RankMatrix),')'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])
    
    disp(['Time = ',num2str(tloc(j))])
end

%-------------------
% Product L= B^T*Q
%-------------------

L = cell(q,1) ;

ncolL  = cell(size(B)) ;
nrowL  = cell(size(B)) ;
disp(['-------------------------------------'])
disp(['Computing B^T Q'])
disp(['-------------------------------------'])

%dbstop('185')

%rmdir(DATA.PATH_STORE_AUX);

%dbstop('214')
dB = {} ; 
for i = 1:length(B)
    disp('*********************************************')
    disp('*********************************************')
    disp(['COLUMN BLOCK i = ',num2str(i),' of ',num2str(q)])
    disp('*********************************************')
    disp('*********************************************') 
    [L{i}  nrowL{i} ncolL{i} ] = Product_Bt_Q(B{i},Q,DATA) ;
    
end

% if DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP_multi ==0
%     dbstop('187')
%     nrowL = cell2mat(nrowL) ;
%     ncolL = cell2mat(ncolL) ;
% end


%dbstop('144')
Rmax = max(R)  ;

