function [B] = GenerateFunExampleRANDOM(M,N,alpha,beta,q,DATA);

error('Option not implemented yet')
disp('------------------------')
disp('Generating B matrix (random)')
disp('------------------------')
Bref = rand(M,R) ;  % All blocks will be a linear combination of this matrix
B = cell(1,q) ;
for i = 1:q
    disp(['block =',num2str(i),' of ',num2str(q)])
    Ni = beta(i) ;
    % Rank of the block
    Ri = randi([ceil(0.5*R),R],1) ;
    BiP = Bref*rand(R,Ri) ; % Matrix of rank Ri
    ratioNiRi = ceil(Ni/Ri) ;
    BiP = repmat(BiP,1,ratioNiRi) ;  % Matrix of rank Ri, featuring more columns than Ni
    % Block of rank Ri and Ni columns
    B{i} = BiP(:,1:Ni) ;
    
    
end