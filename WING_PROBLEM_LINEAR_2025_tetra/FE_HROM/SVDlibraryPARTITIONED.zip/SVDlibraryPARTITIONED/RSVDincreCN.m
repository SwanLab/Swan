function [Q,L,INDICES,epsilonSVD] = RSVDincreCN(B,beta,epsilon,dr,rho,Rini,DATA)
% DATA: Partitioned matrix B = {B1 B2 ... Bq},
% error threshold epsilon (1 x q), rank estimation r
% RESULT: L = [L1 L2 ... Lq], and G = diag(G1,G2 ...Gq), where Li = Di*Hi,
% and Bi = Di*Hi*Di^T + ERROR(epsilon)
%dbstop('7')
if nargin == 0
    load('tmp1.mat') 
    DATA.ROWWISE = 0 ; 
end

% DATA = DefaultField(DATA,'ROWWISE',1); 

% if   DATA.ROWWISE == 0 
%   for i = 1:length(B)
%       B{i} = B{i}' ; 
%   end
% end

disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(B) ;
L = cell(1,q) ; G = cell(1,q) ;
% if ~iscell(B) % Convert B into a cell array of submatrices
%     M = size(B,1) ;
%     B = mat2cell(B,M,beta) ;
% end
R = zeros(1,q) ; Rlft = Rini ;
% Nm = 0 ; % Maximum number of columns
% for i=1:length(B)
%     Nm = max(Nm,size(B{i},2)) ;
% end
%Omega = randn(Nm,Nm) ; % Random matrix
Q = [] ;

%INDICES = randperm(q)
%dbstop('30')
[~, INDICES] = sort(epsilon) ;

epsilonSVD = zeros(size(INDICES)) ; 
for j=1:q
    
    i = INDICES(j) ;
    
    disp('------------------------------------------')
    disp(['i = ',num2str(j), '  of ',num2str(q)])
    TTT =tic ;
    
    Ni = size(B{i},2) ;
    MNi = min(size(B{i})) ;
    %  dbstop('31')
    Rest = ceil(rho*Rlft); dR = ceil(Rest*dr) ;
    if Rest ==0; Rest = ceil(0.1*Ni); dR = Rest ;   end
    Omega = randn(Ni,Rest) ;
    if j==1
        dB = B{i} ;
    else
        dB = B{i} - Q*(Q'*B{i}) ; % Residual
    end
    b = norm(B{i},'fro') ;
    % dbstop('20')
    mu = (max(size(dB))*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        e0 = epsilon(i)*b ;
    else
        e0 = mu ;
    end
    [dQ,Hi,Gi,eSVD] = RSVDnew(dB,Omega,e0,dR,mu);
    
    if epsilon(i) > 0
        epsilonSVD(i) = eSVD/b ; 
    else
        epsilonSVD(i) = eSVD ; 
    end
    
    if j>1
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    Q = [Q dQ];
    
    % L{i} = Q'*B{i} ;
    
    Rlft = size(dQ,2) ;
    
    TTT= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])

    disp(['Time = ',num2str(TTT)])
end

L = [] ;
for i = 1:length(B)
    L = [L Q'*B{i}];
    
end




% [U,S,V] = SVD(L,0); % No truncation
% U = Q*U ;

% Writing G in sparse format
% G = diagonal(G{1},G{2},...G{q})
%dbstop('26')

