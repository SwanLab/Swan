function     [Anew,alpha,beta] = CollapseCellMatrix(A,alpha_c,beta_c,DATA)
if nargin == 0
    % dbstop('4')
    load('tmp.mat')
    DATA.MaxSizeMatrixGb = 0.005 ;
end
SIZEA = sum(alpha_c)*sum(beta_c)*8e-9 ;
f =ceil(SIZEA/DATA.MaxSizeMatrixGb) ;
p = length(alpha_c) ;
q = length(beta_c) ;
p_new = ceil(p/(p+q)*f) ;
q_new = ceil(f/p_new) ;

M = sum(alpha_c);
N = sum(beta_c) ;

Anew = cell(p_new,q_new) ;
alpha = zeros(1,p_new) ;
beta = zeros(1,q_new) ;

ncolAVG = ceil(N/q_new) ;
nrowAVG = ceil(M/p_new) ;

cumALPHA = cumsum(alpha_c) ;
cumBETA = cumsum(beta_c) ;

iniROW = 0 ;
IiniROW = 0 ;
for i = 1:p_new
    if i==p_new
        ROWBLOCK = (IiniROW+1):length(cumALPHA) ;
    else
        ROWBLOCK=  find(cumALPHA<=nrowAVG+iniROW) ;
        ROWBLOCK = ROWBLOCK(IiniROW+1:length(ROWBLOCK)) ;
    end
    ilastROW = length(ROWBLOCK) +IiniROW;
    if  i==1
        alpha(i) = cumALPHA(ilastROW);
    else
        alpha(i) = cumALPHA(ilastROW)-sum(alpha(1:i-1));
    end
    iniROW = alpha(i)    ;
    IiniROW = ilastROW ; 
    iniCOL = 0 ;
    IiniCOL = 0 ;

    for j = 1:q_new
        if j==q_new
            COLBLOCK = (IiniCOL+1):length(cumBETA) ;
        else
            COLBLOCK=  find(cumBETA<=ncolAVG+iniCOL) ;
            COLBLOCK = COLBLOCK(IiniCOL+1:length(COLBLOCK)) ;
        end
        ilastCOL = length(COLBLOCK) +IiniCOL;
        IiniCOL = ilastCOL ; 
        if j==1
            beta(j) = cumBETA(ilastCOL) ;
        else
            beta(j) = cumBETA(ilastCOL)-sum(beta(1:j-1)) ;
        end
        iniCOL = beta(j);
        Anew{i,j} = cell2mat(A(ROWBLOCK,COLBLOCK)) ;
        A(ROWBLOCK,COLBLOCK) = cell(length(ROWBLOCK),length(COLBLOCK)) ;  % Delete
        
    end
end

if sum(alpha) ~= sum(alpha_c) | sum(beta) ~=sum(beta_c)
    error('Check error....')
end

end



