function [U,S,V] = RSVDblockmNEW(A,alpha,beta,epsilon,DATA)
%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('COMPUTATION OF Q and B  (basis for column space of A)')
disp('----------------')
%dbstop('12')

[Q B gamma alpha_b beta_b] = RORTHgloNEW(A,alpha,beta,epsilon,DATA) ; 

% warning('-------')
%  A = cell2mat(A) ; 
%  diffff = norm(A- Q*(Q'*A),'fro')


disp('----------------')
disp('COMPUTATION OF P  (basis for the row space of A)')
disp('----------------')
 %gamma(:,:) = 0 ;  disp('Quita estoooo')
 DATA.rho = 0.08 ; 
 DATA = DefaultField(DATA,'gamma_zero',0); 
 if DATA.gamma_zero ==1
     gamma(:,:) = 0 ; 
 end
 DATA.EPSILON_ABSOLUTE = 1 ; 
 [P C gamma_c] = RORTHglo(B,alpha_b,beta_b,gamma',DATA) ; 
 
% B = cell2mat(B) ; 
 %diffff = norm(B- P*(P'*B),'fro')

%%%%
disp('COMPUTATION OF SVD(Q^T C P)')
[Ubar,S,Vbar] = SVD(cell2mat(C),0);
disp('---------------------------------------')
disp('DONE ... ')
disp('Computing left singular vectors U = X*Ubar')
U = Q*Ubar ;
disp('Done ')
disp('---------------------------------------')
disp('DONE ... ')
disp('Computing righbt singular vectors V = P*Vbar')
V = P*Vbar ;
disp('Done ')