function  [U,S,V,i] = RSVD(C,Omega,epsilon,dr)
if nargin == 0
    load('tmp.mat')
    epsilon = 0.001 ;
end

R  = size(Omega,2) ; [M,N] = size(C);
Y  = C*Omega ;
Q  = orth(Y) ;
i = 0 ;
if size(Q,2) > R-2
    nC = norm(C,'fro') ; % Frobenius norm of C
    tol = (max([M,N])*eps(nC))  ;% Machine precision
    dR = min(ceil(dr*R),N-R) ;
    dC = C-Q*(Q'*C) ;
    nC = norm(dC,'fro') ; nCold = 1e20 ;  ;
    
    while nC>=tol & (abs(nC-nCold)>tol) & size(Q,2)<N
        i = i + 1 ;
        Omega = randn(N,dR) ;
        Qi = orth(dC*Omega);
        Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
        dC = dC - Qi*(Qi'*dC) ;
        Q = [Q Qi] ; nCold = nC ;
        nC = norm(dC,'fro') ;
        disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
    end
end
D = Q'*C ;
[U,S,V] = SVD(D,epsilon);
U = Q*U ;

end