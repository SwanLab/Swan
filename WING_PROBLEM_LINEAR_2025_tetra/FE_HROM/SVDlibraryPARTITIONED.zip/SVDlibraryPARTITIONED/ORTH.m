function  U = ORTH(C,e0) 
% ORTH  returns an orthogonal basis matrix for the
% range of matrix C. It is similar to the built-in matlab function "orth",
% except for the fact that the truncation of singular values is determined
% by input tolerance e0 
%
% Written by Joaquín  A. Hernández, December 2016. 
% UPC/CIMNE, Barcelona, Spain 
% jhortega@cimne.upc.edu
%
[U,S] = SVD(C,0) ; % Singular value decomposition of  C
SingVsq =  (S.*S) ;
SingVsq = sort(SingVsq);  % s_r, s_{r-1} ... s_1
normEf2 = sqrt(cumsum(SingVsq)) ; % s_r , s_r + s_{r-1} ... s_r +s_{r-1}+ s_{r-2} ... + s_1
T = (sum(normEf2<e0)) ;
R = length(S)-T ;
U = U(:,1:R);


