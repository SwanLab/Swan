function [Qt_B b alphaLOC betaLOC B] = Product_Qt_B_cell(B,Q) 

if nargin == 0
    load('tmp.mat')
end

bMAT = zeros(size(B)) ;          % Norm of each submatrix
disp(['Computing Q^T B'])
Qt_B = cell(1,size(B,2)) ;
iacum = 1;
for j=1:size(B,2)
    disp('---------------------')
    disp(['Loading block j=',num2str(j),' of ',num2str(size(B,2))])
    disp('---------------------')
    iacum = 1;
    for i=1:size(B,1)
         disp(['i=',num2str(i),' of ',num2str(size(B,1))])
        %   disp(['Loading ...'])
        if  i==1 ; Qt_B{j} = 0 ; end
        SSS = load(B{i,j}) ;
     
        fff = fieldnames(SSS) ;
        bMAT(i,j) = norm(SSS.(fff{1}),'fro') ;
        alphaLOC(i) = size(SSS.(fff{1}),1) ;
        betaLOC(j) = size(SSS.(fff{1}),2) ;
        INDICES = iacum:iacum+alphaLOC(i)-1 ;
        Qt_B{j} = Qt_B{j} +   Q(INDICES,:)'*SSS.(fff{1});
        iacum = iacum + alphaLOC(i);
           B{i,j} = SSS.(fff{1}) ;
    end
    
end
b = norm(bMAT,'fro') ; % Norm of matrix "B"