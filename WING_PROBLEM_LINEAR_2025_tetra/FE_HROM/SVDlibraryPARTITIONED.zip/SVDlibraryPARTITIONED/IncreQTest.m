function Q = IncreQTest(C,Q,R,dR,DATA,mu)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N = size(C,2) ;
i = 0;
while size(Q,2) == R
    disp(['k=',num2str(i),' rank = ',num2str(R)])
    R = R + dR ;
    if (isempty(DATA.Omega) || size(DATA.Omega,1)<N  ||   size(DATA.Omega,2)<R) & R <= min(size(C))
        %   dbstop('36')
        DATA.Omega = randn(N,R) ;
    elseif R > min(size(C))
        % No randomization
        Q = [] ; 
        break
    end
    Q  = ORTH(C*DATA.Omega(1:N,1:R),mu) ;
    i = i +1 ;
end
if ~isempty(Q)
    disp(['k=',num2str(i),' rank = ',num2str(size(Q,2))])
end
%%%%%%%%%%%%%%%%%%%%%%