function [Q,L,INDICES,gamma] = RSVDincre(B,beta,epsilon,dr,rho,Rini,Omega,DATA)
% DATA: Partitioned matrix B = {B1 B2 ... Bq},
% error threshold epsilon (1 x q), rank estimation r
% RESULT: L = [L1 L2 ... Lq], and G = diag(G1,G2 ...Gq), where Li = Di*Hi,
% and Bi = Di*Hi*Di^T + ERROR(epsilon)
%dbstop('7')
if nargin == 0
    load('tmp1.mat') 
end
disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(B) ;
L = cell(1,q) ; G = cell(1,q) ;
if ~iscell(B) % Convert B into a cell array of submatrices
    M = size(B,1) ;
    B = mat2cell(B,M,beta) ;
end
R = zeros(1,q) ; Rlft = Rini ;
Nm = 0 ; % Maximum number of columns
for i=1:length(B)
    Nm = max(Nm,size(B{i},2)) ;
end
%Omega = randn(Nm,Nm) ; % Random matrix
Q = [] ;

%INDICES = randperm(q)
%dbstop('30')
[~, INDICES] = sort(epsilon) ;

epsilonSVD = zeros(size(INDICES)) ; 
gamma =  zeros(size(INDICES)) ;  
for j=1:q
    
    i = INDICES(j) ;
    
    disp('------------------------------------------')
    disp(['i = ',num2str(j), '  of ',num2str(q)])
    TTT =tic ;
    
    Ni = size(B{i},2) ;
    %  dbstop('31')
    Rest = ceil(rho*Rlft); dR = ceil(Rest*dr) ;
    if Rest ==0; Rest = ceil(0.2*Ni); dR = Rest ;   end
    Rest = min(Rest,Ni); 
    if Rest ==Ni
        % No random. 
        NORANDOM = 1  ; 
    else
        NORANDOM =  0 ; 
    end
 %   Omega = randn(Ni,Rest) ;
    if j==1
        dB = B{i} ;
    else
        dB = B{i} - Q*(Q'*B{i}) ; % Residual
    end
    b = norm(B{i},'fro') ;
    % dbstop('20')
    mu = (max(size(dB))*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        e0 = epsilon(i)*b ;
    else
        e0 = mu ;
    end
    
    if NORANDOM == 0
    [dQ,Hi,Gi,eSVD] = RSVDnew(dB,Omega(1:Ni,1:Rest),e0,dR,mu,DATA);
    else
     %   dbstop('70')
        DATA.tol = mu ; 
        [dQ,Hi,Gi] = SVD(dB,epsilon(i));
        eSVD = 0 ; 
    end
    
    if epsilon(i) > 0
        epsilonSVD(i) = eSVD/b ; 
        gamma(i) =  epsilon(i) - epsilonSVD(i) ; 
    else
        epsilonSVD(i) = eSVD ; 
    end
    
    if j>1
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    Q = [Q dQ];
    
    % L{i} = Q'*B{i} ;
    
    Rlft = size(dQ,2) ;
    
    TTT= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])

    disp(['Time = ',num2str(TTT)])
end

 L=[] ;
for i = 1:length(B)
    L = [L Q'*B{i}];    
end


%dbstop('108')
%DATA.SVD_after_each__ROW  = 0 ; 
DATA =DefaultField(DATA,'SVD_after_each__ROW',0) ;
if DATA.SVD_after_each__ROW == 1
 [U,S,V] = SVD(L,0); % No truncation
 Q = Q*U ;
 
 
  L = bsxfun(@times,V',S) ;

end


% Writing G in sparse format
% G = diagonal(G{1},G{2},...G{q})
%dbstop('26')

