clc
clear all

%%
CLASSIC_SVD = 0; 
RANK_PRE = 50 ;  
SIZE_A =20 ;     % Size matrix (Gbbytes)
p =1;   % Number of partitions along rows
q =  200 ;  % Number of partitions along columns
N = ceil(sqrt(SIZE_A/8*1e9)) ; % Number of columns
M = ceil( SIZE_A/8*1e9/N) ;  % Number of rows
DATASTORE = ['DATAWS/DATA_Amatrix/'] ; 
GENERATE_AGAIN = 0 ; 

beta = ceil(N/q) ; 
beta = repmat(beta,1,q) ; 
alpha = M ; 
MAXSTORE = 4.1;

SEM = randn(alpha(1),RANK_PRE) ; 

disp('Generation')
A = cell(p,q) ;  
for i = 1:length(alpha)
    disp(['i=',num2str(i)])
    for j = 1:length(beta) ; 
        if  SIZE_A > MAXSTORE
               disp(['j=',num2str(j)])
                            nameWS =[DATASTORE,'A_',num2str(i),'_',num2str(j),'.mat'] ; 

               if GENERATE_AGAIN == 1
             Aij = SEM*rand(size(SEM,2),beta(i)) ; 
                disp('Saving...')
             save(nameWS,'Aij') ; 
             disp('End...')
               end
               
               A{i,j} = nameWS ; 
          
            
        else
            
    A{i,j} = SEM*rand(size(SEM,2),beta(i)) ; 
        end
    end
end

disp('End Generation')


if CLASSIC_SVD == 1 
     A =cell2mat(A) ; 
     tic
    [U,S]  =SVD(A,0) ; 
    toc 
     figure(1)
    hold 
    on
    plot(log10(S),'b*')
else
    epsilon = zeros(size(A)) ; 
    [U,S,V,ETIME] =RSVDqp(A,epsilon) ; 
    ETIME
    
    figure(1)
    hold 
    on
    plot(log10(S),'r')
end

 

 