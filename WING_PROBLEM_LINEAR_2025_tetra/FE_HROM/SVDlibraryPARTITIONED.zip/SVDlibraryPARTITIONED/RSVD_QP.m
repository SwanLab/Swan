function [U,S,V,ETIME] = RSVD_QP(A,alpha,beta,epsilon,DATA)
%

if nargin == 0
    load('tmp.mat')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT INPUTS
% ---------------
DATA = DefaultField(DATA,'EPSILON_GLO',0) ;
DATA = DefaultField(DATA,'LAST_SVD_RANDOM',0) ;

ETIME = [] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dbstop('14')
disp('----------------')
disp('COMPUTATION OF Q and B  (basis for column space of A)')
disp('----------------')
tloc = tic ;
%dbstop('21')
[Q A gamma alpha_b beta_b ETIME.Qoper Rmax] = RORTHmatrix(A,alpha,beta,epsilon,DATA) ;

ETIME.Q = toc(tloc) ;
disp('----------------')
disp('COMPUTATION OF P  (basis for the row space of A)')
disp('----------------')
DATA.EPSILON_ABSOLUTE = 1 ;
tloc = tic ;
DATA.Rini = Rmax ;
[P A gamma_c alpha_c beta_c ETIME.Poper ] = RORTHmatrix(A,alpha_b,beta_b,gamma',DATA) ;

ETIME.P = toc(tloc) ;
%%%%
disp('----------------')
disp('SVD of A <-- Q^T A P')
disp('----------------')
eLOC = 0 ;
if sum(epsilon)==0; eLOC = DATA.EPSILON_GLO ; end
tloc = tic ;
if  DATA.LAST_SVD_RANDOM == 0
    disp('Direct SVD')
    [Ubar,S,Vbar] = SVD(cell2mat(A),eLOC);
else
   % dbstop('45')
    A = cell2mat(A) ;
    c = norm(A,'fro') ;
    mu = (max(size(A))*eps(c))  ;
    if  eLOC == 0
        e0 = mu ;
    else
        e0 = c*eLOC ;
    end
    %  Omega = [] ;
  %  dbstop('53')
    Rmax = max([alpha_c beta_c]) ;
    Rest =  Rmax ;
    dR =  Rest ;
    Omega = randn(size(A,2),Rest) ;
    DATA.COMPUTE_V_SVD = 1;
    DATA.Omega = [] ;
    [Ubar,S,Vbar] = RSVDt(A,e0,mu,Omega,DATA) ;
 % end
    
    
end
ETIME.C = toc(tloc) ;
disp('---------------------------------------')
disp('DONE ... ')
disp('--------------------------------------')
disp('Computing left singular vectors U = X*Ubar')
tloc = tic ;
U = Q*Ubar ;
ETIME.QUbar = toc(tloc) ;
disp('Done ')
disp('---------------------------------------')
disp('Computing righbt singular vectors V = P*Vbar')
tloc = tic ;
V = P*Vbar ;
ETIME.PVbar = toc(tloc) ;
disp('Done ')