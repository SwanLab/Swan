function  [U,S,V,i] = RSVD_viaQR(C,Omega,epsilon,dr)
%Omega = randn(N,R) ; % Normally distributed random matrix

R  = size(Omega,2) ; [M,N] = size(C);
theta = 1e-2 ; % Factor to dimish tolerance based on nC
nC = norm(C,'fro') ;
tol = theta*(max([M,N])*eps(nC))  ;
Q  = orth(C*Omega) ;  % Orthogonal basis matrix for range(C*Omega)
dC = C-Q*(Q'*C) ;     % Residual 
nC = norm(dC,'fro') ;
i = 0 ;
dR = min(ceil(dr*R),N-R) ;
while nC>=tol
    i = i + 1 ;
    Omega = randn(N,dR) ;
    Qi = orth(dC*Omega);
    Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
    dC = dC - Qi*(Qi'*dC) ;
    Q = [Q Qi] ;
    nC = norm(dC,'fro') ;
    disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
end

D = Q'*C ;
[U,S,V] = SVD(D,epsilon);
U = Q*U ;