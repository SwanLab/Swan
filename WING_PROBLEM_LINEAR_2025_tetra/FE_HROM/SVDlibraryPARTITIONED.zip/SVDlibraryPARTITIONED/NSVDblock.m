function [U,S,V] = NSVDblock(A,alpha,beta,epsilon,Nmax,DATA)
%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('LOOP OVER ROW BLOCK MATRICES')
disp('----------------')
p = length(alpha) ;
X = cell(1,p) ; K = cell(1,p) ;
M = sum(alpha) ; N = sum(beta);
Nmax = min(Nmax,min(M,N)-1) ; 
DATA = DefaultField(DATA,'epsilonGLOBAL',0) ; 
if ~iscell(A)
    A = mat2cell(A,alpha,beta) ;
end
%dbstop('18')
q = length(beta) ;
normAapprox = zeros(p,q) ; 
for i=1:p
    disp('------------------------------------------')
    disp(['row = ',num2str(i), '  of ',num2str(p)])
    TTT =tic ;
    if isnumeric(A{i,1})        
        [Xi,Zi,Ti,normAapprox(i,:)] = NSVDcol(A(i,:),beta,epsilon(i,:),Nmax,DATA)   ; 
    else
        error('Option not implemented yet')
%         disp('Retrieving from memory ...')
%         load(B{i}) ; % Retrieved from memory
%         disp('Done')
%         [Di,Hi,Gi] = SVD(Bi,epsilon(i));
%         Ni = size(Bi,2) ;
%         % Delete from memory
%         disp('Deleting...')
%         delete(B{i});
        
    end
    TTT= toc(TTT);    
    K{i} = bsxfun(@times,Ti',Zi)' ;
    %  dbstop('13')
    X{i} = sparse(Xi) ;
    disp(['R = ',num2str(length(Zi)),' of ',num2str(sum(beta)),' columns'])
    disp(['Time = ',num2str(TTT)])
end
X = blkdiag(X{:}) ;
disp('---------------------------------------')
disp('SVD of matrix K ... ')
disp('---------------------------------------')
%dbstop('50')
A = cell2mat(K) ;
ncolK = size(A,2) ; q = ceil(ncolK/Nmax);
gamma = MakePartition(ncolK,q) ;
[V,S,Ubar] = NSVDcol(A,gamma,zeros(size(gamma)),Nmax,DATA)   ; 
%% Determining level of truncation ---------------------

DATA = DefaultField(DATA,'TRUNCATE',0)  

if any(epsilon)
    
    if DATA.TRUNCATE == 1
        S2 = (S.^2) ;
        cS2 = cumsum(S2) ;
        threshold = sum(sum(normAapprox.^2)) ;
        R = sum(cS2<=threshold) ;
        V = V(:,1:R) ;
        S = S(1:R) ;
        Ubar = Ubar(:,1:R) ;
    end
else
    if DATA.epsilonGLOBAL >0
     
    SingVsq =  (S.*S) ;
    DENOM = sum(SingVsq) ;    NOMINAD = DENOM-cumsum(SingVsq) ;
    normB = sqrt(DENOM) ; ERROR = sqrt(NOMINAD) ;
    K = (sum(ERROR>= DATA.epsilonGLOBAL*normB))+1 ;
    Ubar = Ubar(:,1:K) ;
    V = V(:,1:K)  ; 
    S = S(1:K) ;
    end
end



disp('---------------------------------------')
disp('DONE ... ') 
U = X*Ubar ; 
