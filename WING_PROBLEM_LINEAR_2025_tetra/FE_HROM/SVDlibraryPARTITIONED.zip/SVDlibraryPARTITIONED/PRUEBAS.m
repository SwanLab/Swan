clc
clear all

load('tmp1.mat')


p = length(K) ; 
epsilon = zeros(1,p) ; 
dr = 0.1 ; 
rho = 1.2 ; 
Rini = size(K{1},2); 

 [V,S,Ubar] = RSVDincre_prueba(K,[],epsilon,dr,rho,Rini)   ; 
% 
% A = cell2mat(K) ; % To free memory
% clear K ;
% Rest = max(colK) ;
% 
% 
% 
% Omega = randn(size(A,2),Rest) ; dR =  Rest ;
% [V,S,Ubar,DATAOUT] = RSVD(A,Omega,0,dR)   ;
% disp('---------------------------------------')
% disp('DONE ... ')
% disp('Computing left singular vectors U = X*Ubar')
% U = X*Ubar ;
% disp('Done ')