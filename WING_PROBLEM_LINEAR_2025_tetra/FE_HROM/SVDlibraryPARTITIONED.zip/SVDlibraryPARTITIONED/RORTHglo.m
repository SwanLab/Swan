function [Q B gamma,alpha_b,beta_b] = RORTHgloNEW(A,alpha,beta,epsilon,DATA)

if nargin == 0
    load('tmp.mat')
end

DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ; 
DATA = DefaultField(DATA,'ISTRANSPOSE',0) ; 
DATA = DefaultField(DATA,'CALCULATE_C_AS_symmetric',0) ; 

 
 

p = length(alpha) ; q = size(beta,2) ;
Q = cell(1,p) ;  M = sum(alpha) ;
N = sum(beta);
if DATA.SYMMETRIC_QP == 0
    B = cell(size(A')) ;
else
    B = cell(size(A)) ;
end
%colK = zeros(p,1);
Mmax = (max([  beta])); 
DATA = DefaultField(DATA,'ISTRANSPOSE',0) ; 

DATA = DefaultField(DATA,'DefineInitialRANDOM',1) ; 

if DATA.DefineInitialRANDOM == 1
  %  dbstop('28')
    DATA = DefaultField(DATA,'UpperBoundTotalRank',Mmax) ;
    Mmax = min(Mmax,DATA.UpperBoundTotalRank);
Omega = randn(Mmax,Mmax) ; 
DATA.Omega = randn(Mmax,Mmax) ; 
else
    DATA.Omega = [] ;  
end

gamma = zeros(size(A)) ; 
alpha_b = zeros(size(alpha)) ; 
beta_b = beta ;  ; 
%dbstop('14')
for i=1:p
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
  %  Rini = 0 ;
  %dbstop('51')
    [Qi,Bi,gamma(i,:),~,~,epsilonSVD] = RORTHrow(A(i,:),beta,epsilon(i,:),DATA)   ;
 
    alpha_b(i) = size(Qi,2) ; 
  %  beta_b(i) = size(Qi,1);
    TTT= toc(TTT);    
    %  dbstop('13')
    Q{i} = sparse(Qi) ;
    if DATA.SYMMETRIC_QP == 0
    B(:,i) = Bi;
    elseif DATA.SYMMETRIC_QP == 1 & DATA.ISTRANSPOSE ==0
        B(i,:) = Bi;
      elseif DATA.SYMMETRIC_QP == 1 & DATA.ISTRANSPOSE ==1
        %   B(i,:) = []; Nothing is done...
    else
        error('Option not implemented')
    end
   % disp(['R = ',num2str(size(Bi,1)),' of ',num2str(sum(beta)),' columns']) 
    disp(['Time = ',num2str(TTT)])
  %  colK(i) = size(Li,1) ;
end



Q = blkdiag(Q{:}) ;


end