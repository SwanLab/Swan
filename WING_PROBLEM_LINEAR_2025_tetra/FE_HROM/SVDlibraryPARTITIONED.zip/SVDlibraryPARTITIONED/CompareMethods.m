clc
clear all

addpath('AUXFUN')

load('tmp_error.mat')
a = 0.005;
epsilon = a*ones(1,5) ;
Lmat = cell2mat(L) ;
% Randomized strategy
figure(1)
hold on


[U,Srandom,V,R,DATAOUT] = RNSVDcol(L,beta,epsilon,Nmax,r,dr,rho) ;

c = norm(Lmat,'fro') ;


[ERROR,R] = DiffApproxSVD(U,Srandom,V,c,L) ; 





h1=plot(log(Srandom),'b')


figure(1)
hold on
[U,Spart,V] = NSVDcol(L,beta,epsilon,Nmax) ;

c = norm(Lmat,'fro') ;
Capprox = bsxfun(@times,U',Spart)' ;
Capprox  = Capprox*V' ;
disp(['RANK = ',num2str(length(Spart))])


norm(Lmat-Capprox,'fro')/c


h1=plot(log(Srandom),'b')


%%%%%%%%%%%%%%%%%%%%%%%%%%%5
[U,Sincre,V,R] =RSVDincre(L,beta,epsilon,r,dr,rho) ;

Capprox = bsxfun(@times,U',Sincre)' ;
Capprox  = Capprox*V' ;
disp(['RANK = ',num2str(length(Sincre))])
norm(Lmat-Capprox,'fro')/c


h3= plot(log(Sincre),'k')


[U,S,V] = SVD(cell2mat(L),a) ;

Capprox = bsxfun(@times,U',S)' ;
Capprox  = Capprox*V' ;
disp(['RANK = ',num2str(length(S))])
norm(Lmat-Capprox,'fro')/c


h4 = plot(log(Spart),'g')


legend([h1 h2 h3 h4] ,{'RANDOM PART', 'PART','INCRE','STAND. '})

