function [U,S,V] = RSVDblockm(A,alpha,beta,epsilon,dr,rho,DATA)
%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('LOOP OVER ROW BLOCK MATRICES')
disp('----------------')
p = length(alpha) ; q = length(beta) ;
Q = cell(1,p) ; K = cell(1,p) ; M = sum(alpha) ;
N = sum(beta);
if ~iscell(A)
    A = mat2cell(A,alpha,beta) ;
end
colK = zeros(p,1);
Mmax = max([alpha  beta]); 
Omega = randn(Mmax,Mmax) ; 
  DATA.Omega  =  Omega ; 
Rini = 0.1*max(beta) ;
for i=1:p
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
  %  Rini = 0 ;
    [Qi,Li] = RSVDincre(A(i,:),beta,epsilon(i,:),dr,rho,Rini,Omega,DATA)   ; 
    TTT= toc(TTT);
    K{i} = Li' ;
    %  dbstop('13')
    Q{i} = sparse(Qi) ;
    disp(['R = ',num2str(size(Li,1)),' of ',num2str(sum(beta)),' columns']) 
    disp(['Time = ',num2str(TTT)])
    colK(i) = size(Li,1) ;
end

%dbstop('39')
Q = blkdiag(Q{:}) ;
disp('---------------------------------------')
disp('SVD of matrix K ... ')
disp('---------------------------------------')
Rini = size(K{1},2);
epsilon = zeros(size(K)) ;




 %dbstop('50')
[V,L] = RSVDincre(K,[],epsilon,dr,rho,Rini,Omega,DATA)   ;

% warning('borrarrrrr')
% K = cell2mat(K) ; 
% didfff =norm(K-V*(V'*K),'fro')


%warning('borrarrrrr')

%dimMATRIX = max(M,N) ;
DATA.tol = 0 ;
[Vbar,S,Ubar] = SVD(L,0); % No truncation
V = V*Vbar ;

disp('---------------------------------------')
disp('DONE ... ')
disp('Computing left singular vectors U = X*Ubar')
U = Q*Ubar ;
disp('Done ')
