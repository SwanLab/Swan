function [Q,L,gamma,nrowL,ncolL,epsilonSVD] = RORTHrow(B,beta,epsilon,DATA)
% DATA: Partitioned matrix B = {B1 B2 ... Bq},
% error threshold epsilon (1 x q), rank estimation r
% RESULT: L = [L1 L2 ... Lq], and G = diag(G1,G2 ...Gq), where Li = Di*Hi,
% and Bi = Di*Hi*Di^T + ERROR(epsilon)
%dbstop('7')
if nargin == 0
    load('tmp1.mat')
    %   DATA.nouseRORTH =1  ;
end
dr = DATA.dr;
rho = DATA.rho ;
DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
DATA = DefaultField(DATA,'Rini',0) ;
DATA = DefaultField(DATA,'Omega',[]) ;
DATA = DefaultField(DATA,'ComputeLtranspose',0) ;
DATA = DefaultField(DATA,'TOL_2ndstepORTHO',1) ;
DATA = DefaultField(DATA,'CALCULATE_C_AS_symmetric',0) ;
DATA = DefaultField(DATA,'SVD_after_each__ROW',0) ;
DATA = DefaultField(DATA,'CalculateGammaAfterQ',0) ;
DATA = DefaultField(DATA,'SortTolerances',1) ;
DATA = DefaultField(DATA,'FractionTolerance',1) ; 

ftol = DATA.FractionTolerance ; 


 disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(B) ;
G = cell(1,q) ;
if ~iscell(B) % Convert B into a cell array of submatrices
    M = size(B,1) ;
    B = mat2cell(B,M,beta) ;
end
R = zeros(1,q) ; Rlft = DATA.Rini ;  ;
% Nm = 0 ; % Maximum number of columns
% for i=1:length(B)
%     Nm = max(Nm,size(B{i},2)) ;
% end
%Omega = randn(Nm,Nm) ; % Random matrix
Q = [] ;

%INDICES = randperm(q)
%dbstop('30')
if DATA.SortTolerances == 1
[~, INDICES] = sort(epsilon) ;
else
    INDICES = 1:length(epsilon) ; 
end

epsilonSVD = zeros(size(INDICES)) ;
gamma =  zeros(size(INDICES)) ;

bnorm = gamma ;
for j=1:q
    
    i = INDICES(j) ;
    disp('------------------------------------------')
    disp(['i = ',num2str(j), '  of ',num2str(q)])
    TTT =tic ;
    if DATA.ISTRANSPOSE == 0
        Ni = size(B{i},2) ;
    else
        Ni = size(B{i},1) ;
    end
    %  dbstop('31')
    Rest = ceil(rho*Rlft); dR = ceil(Rest*dr) ;
    if Rest ==0; Rest = ceil(0.1*Ni); dR = Rest ;   end
    Rest = min(Rest,Ni);
    if DATA.ISTRANSPOSE == 0
        if j==1
            dB = B{i} ;
        else
            dB = B{i} - Q*(Q'*B{i}) ; % Residual
        end
    else
        if j==1
            dB = B{i}' ;
        else
            dB = B{i}' - Q*(Q'*B{i}') ; % Residual
        end
    end
    b = norm(B{i},'fro') ;
    bnorm(i) = b ;
    % dbstop('20')
    mu = (max(size(dB))*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        if DATA.EPSILON_ABSOLUTE ==0
            % What was the usefulness of this ???
            e0 = ftol*epsilon(i)*b ;
        else
            %  dbstop('71')
            e0 = epsilon(i) ;
        end
    else
        %  disp('QUITA la b abajo')
        e0 = mu ;
    end
    
    e0 = max(e0,mu) ; 
    
    %    if NORANDOM == 0
    if ~isempty(dB)
        %   dbstop('95')
        if j>1
            db = norm(dB,'fro');
        else
            db = b ;
        end
        if db > e0 | j==1
            if isempty(DATA.Omega) || size(DATA.Omega,1)<Ni  ||   size(DATA.Omega,2)<Rest
                % dbstop('98')
                DATA.Omega = randn(Ni,Rest) ;
            end
            [dQ,Hi,Gi,eSVD,DATA] = RSVDnew(dB,DATA.Omega(1:Ni,1:Rest),e0,dR,mu,DATA);
        else
            dQ = [] ; Hi = [] ; Gi = [] ;
            eSVD = db ;
        end
        
        
        if epsilon(i) > 0
            epsilonSVD(i) = eSVD/b ;
            if DATA.TOL_2ndstepORTHO ==0
                gamma(i) =  epsilon(i)*b - eSVD ;
            else
                gamma(i) =  sqrt((epsilon(i)*b)^2 - eSVD^2) ;
            end
        else
            epsilonSVD(i) = eSVD ;
        end
    else
        dQ = [] ;
        Hi = [] ;
        Gi = [] ;
        eSVD = [] ;
    end
    %     else
    %       %%  dbstop('70')
    %      %   DATA.tol = mu ;
    %         [dQ,Hi,Gi] = SVD(dB,epsilon(i));
    %         eSVD = 0 ;
    %     end
    
    
    
    if j>1 & ~isempty(dQ)
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    Q = [Q dQ];
    
    % L{i} = Q'*B{i} ;
    
    if   ~isempty(dQ)
    Rlft = size(dQ,2) ;
    end
    
    
    
    
    TTT= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])
    
    disp(['Time = ',num2str(TTT)])
end

ncolL  = zeros(size(B)) ;
nrowL  = zeros(size(B)) ;


gammaAFTER = zeros(size(gamma)) ;

%dbstop('160')
if  DATA.SYMMETRIC_QP == 0
    if  DATA.CALCULATE_C_AS_symmetric  ==0
        L = cell(q,1) ;
        for i = 1:length(B)
            L{i} =B{i}'*Q ; % [Q'*B{i}];
            ncolL(i) = size(L{i},2) ;
            nrowL(i) = size(L{i},1) ;
            % if DATA.CalculateGammaAfterQ ==1
            gammaAFTER(i) = sqrt((bnorm(i)*epsilon(i))^2 - norm( B{i} - Q*L{i}','fro')^2  );
            % end
        end
    else
        L = cell(1,q) ;
        for i = 1:length(B)
            L{i} =B{i}*Q;  ; % [Q'*B{i}];
            ncolL(i) = size(L{i},2) ;
            nrowL(i) = size(L{i},1) ;
        end
        
        
    end
elseif DATA.SYMMETRIC_QP == 1
    
    if DATA.ISTRANSPOSE == 0
        % First step
        %  dbstop('150')
        L = cell(1,q) ;
        for i = 1:length(B)
            L{i} =Q'*B{i};  ; % [Q'*B{i}];
            ncolL(i) = size(L{i},2) ;
            nrowL(i) = size(L{i},1) ;
        end
        
    else
        if DATA.ComputeLtranspose == 0
            L = [] ;
        else
            L = cell(q,1) ;
            for i = 1:length(B)
                L{i} =B{i}*Q;  ; % [Q'*B{i}];
                ncolL(i) = size(L{i},1) ;
                nrowL(i) = size(L{i},2) ;
            end
        end
        
    end
    
else
    error('Option not implemented')
end

DATA.Rini  = 0 ;

%dbstop('216')
ddd = find(gamma==0) ;
gammaAFTER(ddd) = 0 ;
if DATA.CalculateGammaAfterQ  ==1
    gamma = gammaAFTER ;
    
end

%
% [U,S,V] = SVD(L,0); % No truncation
% U = Q*U ;

% Writing G in sparse format
% G = diagonal(G{1},G{2},...G{q})
%dbstop('26')

