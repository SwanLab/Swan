function [Q,i,nC] = RORTH(C,Q,e0,dR) ;

[M,N] = size(C); % Frobenius norm of C
dC = C-Q*(Q'*C) ;
nC = norm(dC,'fro') ;  
i = 0 ; 
while nC>=e0  & size(Q,2)<N
    i = i + 1 ;
    Omega = randn(N,dR) ;
    Qi = orth(dC*Omega);
    Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
    dC = dC - Qi*(Qi'*dC) ;
    Q = [Q Qi] ; 
    nC = norm(dC,'fro') ;
    disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
end
