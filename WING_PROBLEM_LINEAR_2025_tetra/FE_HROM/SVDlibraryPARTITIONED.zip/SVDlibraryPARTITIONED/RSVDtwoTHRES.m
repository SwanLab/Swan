function [U,S,V,ETIME,rankR] = RSVDtwoTHRES(A,ISEXACT,DATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Given a matrix A, RSVDqp returns   a factorization  [U,S,V] of the form
%   A =  U*S*V^T + E   (E = 0 when no truncation is introduced)
% --------------------------
% INPUTS
%------------------------------------------------------------------------------
%  A:    Matrix to be factorized. It can be given as a single numeric array,
%       or as a  p x q cell array containing a conforming partition of A, i.e.:
%
%     A = {A_11, A_12 ... A_1q
%       A_21, A_22 ....A_2q
%       ... .... ..... ...
%       A_p1, A_p2 ... A_pq}
%
%     In turn, each entry A_ij may be a numeric array, or the name of a MAT-file containing
%     the numeric array. The second option is preferred when the whole
%     matrix does not fit into fast memory
%
% -------------------------------------------------------------------------------
%  ISEXACT : Boolean matrix that indicates which submatrices are to be
%  approximated exactly (if == 1). size(ISEXACT) = size(A)
%
%
% -----------------------------------------------------------------------------
%
%  OUTPUTS
%  ------
%  U --> (M x r)  Matrix of left singular vectors (it approximately spans
%  the column space of A); r denotes the rank of the approximation.
%  V --> (N x r)  Matrix of right singular vectors (it approximately spans
%  the row space of A)
%  S ---> Vector of singular values  (r x 1)
%  ETIME --> Structure containing the times required for each operation
%  eSVD --> Approximation error (Frobenius norm)
%
%  RankMatrix --> rank(Q'*A*P). If epsilon = zeros(size(A)), then
%  RankMatrix = rank(A)
%
%  NOTES: If ISEXACT(i,j) = 0 or 1 for all i,j, then the obtained
%  factorization is the classical truncated SVD
%  ----------------
%  OPTIONAL INPUTS, (with default values)
%  -----------------
% 1)  DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP = 0
% 2)  DATA.Rini = 0
% 3)  DATA.rho_est = 0.05
% 4)  DATA.TRANSPOSE = 0
% 5)  DATA.COMPUTE_V_LAST_SVD = 1
%
%  When each A{i,j} is a .MAT
%  filename,    the contents of A{i,j} are discarded from memory
%  after its corresponding incremental basis vectors are computed.
%  The product of the transponse of basis matrix Qi  times the i-th row
%  block is stored in memory if variable
%  DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP = 1 ;
%
%    DATA.Rini = Initial estimation for the rank of submatrix A{1,1}. The
%    default value is min(DATA.rho_est*ceil(max(size(A{1,1})))).
%
%  DATA.TRANSPOSE -> The factorization is calculated on the transpose of
%  the matrix
%
%  DATA.COMPUTE_V_LAST_SVD -->  If 0, the matrix of right singular vectors
%  is not calculated
%
%
%
%  Written by Joaquín A. Hernández Ortega, Dec. 2016
%  UPC/CIMNE. jhortega@cimne.upc.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dbstop('86')
if nargin == 0
    load('tmp.mat')
end


if exist('DefaultField') == 0
    addpath('AUXFUN')
end

if nargin == 2
    DATA = [];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT INPUTS
% ----------------------------------------------------
DATA = DefaultField(DATA,'EPSILON_GLO',0) ; % See preabmble
DATA = DefaultField(DATA,'USE_SLOW_MEMORY',[]) ;  %
DATA.USE_SLOW_MEMORY = DefaultField(DATA.USE_SLOW_MEMORY,'STORE_ALSO_SECOND_STEP',0) ;  %
DATA = DefaultField(DATA,'EPSILON_GLO_isRELATIVE',1) ; % For multi-level version
DATA = DefaultField(DATA,'COMPUTE_V_LAST_SVD',1) ; % It computes the matrix of right-singular vectors
DATA = DefaultField(DATA,'TWOLEVELMETHOD',[]) ; % Two-level method
DATA.TWOLEVELMETHOD = DefaultField(DATA.TWOLEVELMETHOD,'ACTIVE',0) ; % Two-level method
DATA = DefaultField(DATA,'Rini',0) ; % Initial estimation for the rank
DATA = DefaultField(DATA,'TRANSPOSE',0) ; %
DATA = DefaultField(DATA,'PARALLEL',0) ; %
DATA = DefaultField(DATA,'rho_est',0.05) ; %

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ETIME.TOTAL = tic ;
% Preprocessing input data (check whether it is a cell array, or a numeric array and other operations)
% -------------------------------------------------------------------------------------------------------
NAMEF = [] ;
DATA.USE_SLOW_MEMORY.ACTIVE = 0 ;
if iscell(A)
    CHECK = cellfun(@ischar,A) ;
    if  any(CHECK)
        [ aaa bbb]= find(CHECK==1) ;
        NAMEF = A{aaa(1),bbb(1)} ;
        DATA.USE_SLOW_MEMORY.ACTIVE = 1 ;
    end
    
    [p q]= size(A) ;
    alpha = zeros(1,p) ; beta = zeros(1,q) ;
    for iii=1:size(A,1)
        for jjj=1:size(A,2)
            
            if  ischar(A{iii,jjj})
                matObj = matfile(A{iii,jjj})
                fff = fieldnames(matObj) ;
                for kkk = 1:length(fff)
                    switch fff{kkk}
                        case 'Properties'
                        otherwise
                            var = fff{kkk} ;
                    end
                end
                info = whos(matObj,var) ;
                sizeX = info.size ;
                alpha(iii) = sizeX(1) ;
                beta(iii) = sizeX(2) ;
            else
                alpha(iii) = size(A{iii,jjj},1) ;
                beta(jjj) = size(A{iii,jjj},2) ;
            end
            
        end
    end
    
    DATA.alpha = alpha ;
    DATA.beta =beta ;
    
    
    
end
if isnumeric(A) || (iscell(A) && isempty(NAMEF) && size(A,1)==1 & size(A,2)==1 )
    if  size(A,1)==1 & size(A,2)==1
        A = A{1,1} ;
    end
    DATA.PATH_STORE_AUX  = [] ;
    p = 1; q = 1;
    DATA.TRANSPOSE = 0 ;
else
    [p,q] = size(A) ;
    if ~isempty(NAMEF)
        NAMEF = fileparts(NAMEF) ;
        DATA.PATH_STORE_A = NAMEF ;
        DATA.PATH_STORE_AUX = [DATA.PATH_STORE_A,'AUXtmpj/'] ;  % Path in which temporary files are stored
    else
        DATA.PATH_STORE_AUX  = [] ;
        
    end
    % dbstop('34')
    if DATA.TRANSPOSE == 1
        p_old = p ; q_old = q ;
        p = q_old ; q = p_old ;
        A  = A' ;
        epsilon = epsilon' ;
    end
end
% Creating folder for storing temporary files
if ~isempty( DATA.PATH_STORE_AUX ) && ~exist(DATA.PATH_STORE_AUX)
    mkdir(DATA.PATH_STORE_AUX)
end
%-----------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Qr = [] ; Ql=[] ; P = [] ; alpha_c = [] ; ETIME_Qoper =[] ; ETIME_Poper = [] ;
EPSILON_GLO = DATA.EPSILON_GLO ;
DATA.EPSILON_GLO  = 0 ;

% while iter <= DATA.ITERMAX & SIZEA>=DATA.MaxSizeMatrixGb


disp('-------------------------------------------------')
disp('Column blocks requiring exact approximation')
disp('-------------------------------------------------')
%  Qini = cell(p,1) ;
BLOCKS = ISEXACT ;
SSS = sum(BLOCKS,1) ;
COLexact =  find(SSS ==size(BLOCKS,1) );
BLOCKSloc = zeros(size(BLOCKS)) ;
BLOCKSloc(:,COLexact) = 1;

tloc = tic ;
COMPUTE_V_LAST_SVD = DATA.COMPUTE_V_LAST_SVD   ;
DATA.COMPUTE_V_LAST_SVD = 0 ;
[Qr,~,~,ETIMEr,eSVDr,RankMatrixR] = RSVDqpEA(A,BLOCKSloc,DATA) ;
DATA.COMPUTE_V_LAST_SVD = COMPUTE_V_LAST_SVD ;
[QtAr,dA,normAoriginal] = ProductQQtA(A,Qr);
% Singular value decomposition of QtAr
[Ur,Sr,Vr] = SVD(QtAr,0) ;
Ur = Qr*Ur ;
ETIME.SVDr = toc( tloc) ;

tloc = tic ;
disp('-------------------------------------------------')
disp('column Blocks whose SVD can be truncated')
disp('-------------------------------------------------')
BLOCKS = ones(size(A)) ;
epsilonLOC = zeros(size(A)) ;
[Ql,Sl,~,ETIMEl,eSVDl,RankMatrixL] = RSVDqpEA(dA,BLOCKS,DATA,normAoriginal) ;
ETIME.Ql = toc( tloc) ;
%   Product (Ql*Ql*A')
% ----------------
[~, dA,~] = ProductQQtA(A,Ql,1);




% Now we repeate the procedure, but for the row space
BLOCKS = ISEXACT' ;
SSS = sum(BLOCKS,1) ;
COLexact =  find(SSS ==size(BLOCKS,1) );
BLOCKSloc = zeros(size(BLOCKS)) ;
BLOCKSloc(:,COLexact) = 1;

COMPUTE_V_LAST_SVD = DATA.COMPUTE_V_LAST_SVD   ;
DATA.COMPUTE_V_LAST_SVD = 0 ;

[Pr,Slr,~,ETIMEr,eSVDr,RankMatrixR] = RSVDqpEA(dA,BLOCKSloc,DATA,normAoriginal) ;
DATA.COMPUTE_V_LAST_SVD = COMPUTE_V_LAST_SVD ;
[QtAr,dA] = ProductQQtA(dA,Pr);
% Singular value decomposition of QtAr
[Vlr,Slr,Ulr] = SVD(QtAr,0) ;
Vlr = Pr*Vlr ;



BLOCKS = ones(size(A)) ;
[Vll,Sll,Ull,ETIMEl,eSVDl,RankMatrixL] = RSVDqpEA(dA,BLOCKS,DATA,normAoriginal) ;
ETIME.Ql = toc( tloc) ;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Therefore

U = [Ur Ulr Ull] ;
S = [Sr; Slr; Sll] ;
V = [Vr Vlr Vll] ;





c = norm(normAoriginal,'fro') ;
%dbstop('159')
mu = (max([sum(DATA.alpha) sum(DATA.beta)])*eps(c))  ;  % Machine epsilon parameter
eLOC = DATA.EPSILON_GLO ; 
if  eLOC == 0
    e0 = mu ;
else
    e0 = c*eLOC ;
end

% -----------------------------------------
% Estimation rank A

if  e0<=mu
    R = length(find(S>mu)) ;
else
    disp(['Rank matrix =',num2str(RankMatrix)]) ;
    SingVsq =  (S.*S) ;
    SingVsq = SingVsq(length(SingVsq):-1:1);  % s_r, s_{r-1} ... s_1
    normEf2 = sqrt(cumsum(SingVsq)) ; % s_r , s_r + s_{r-1} ... s_r +s_{r-1}+ s_{r-2} ... + s_1
    tol = e0 ;
    if tol<=mu
        R = length(S) ;
    else
        T = (sum(normEf2<tol)) ;
        R = length(S)-T ;
    end
end
% Actual error
e_svd = sqrt(sum(S(R+1:end).^2)) ;
U = U(:,1:R);
S = S(1:R) ;
if ~isempty(V)
    V = V(:,1:R) ;
end
disp(['Truncated rank=',num2str(R)]) ;



SingVsq =  (S.*S) ;
DENOM = sum(SingVsq) ;    NOMINAD = DENOM-cumsum(SingVsq) ;
ERRORsvd = sqrt(NOMINAD/DENOM);


figure(100)
hold on 
xlabel('Mode')
ylabel('Error SVD (%)')

plot(ERRORsvd*100,'b')

title(['Rank RCOL = ',num2str(length(Sr)),'; Rank RROW= ',num2str(length(Slr)),'; Rank L =',num2str(length(S)-(length(Sr)+length(Slr)))])

aaa = axis ; 

r =length(Sr) ; 
rl = length(Sr)+ length(Slr) ; 
 
plot([r r],[aaa(3:4)],'r-')
plot([rl rl],[aaa(3:4)],'r-')



rankR = length(Sr);%+length(Slr) ; 




end

