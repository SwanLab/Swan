function  [U,S,V,e_svd,DATA] = RSVDnew(C,Omega,e0,dR,mu,DATA)

%dbstop('4')
if nargin == 0
    load('tmp.mat')
    %epsilon = 0.001 ;
end

DATA = DefaultField(DATA,'nouseRORTH',0) ;
DATA = DefaultField(DATA,'Omega',[]) ;


R  = size(Omega,2) ;
Q  = orth(C*Omega) ;

Q = orth(C*Omega) ;





i = 0 ;
nC = 0 ;
if size(Q,2) == R & size(Q,2) ~=min(size(C))
    % dbstop('18')
    if DATA.nouseRORTH == 0;
        [Q,i,nC] = RORTH(C,Q,e0,dR) ;
    else
        N = size(C,2) ;
        i = 0;
        while size(Q,2) == R
            %      dbstop('25')
            R = R + dR ;
            if isempty(DATA.Omega) || size(DATA.Omega,1)<N  ||   size(DATA.Omega,2)<R
               % dbstop('36')
                DATA.Omega = randn(N,R) ; 
            end
            Omega = DATA.Omega(1:N,1:R) ;
            %   Omega = rand(N,R) ;
            Q  = orth(C*Omega) ;
            i = i +1 ;
        end
        
    end
end

D = Q'*C ;

% DATA.tol = mu  ;
[U,S,V] = SVD(D,0); % No truncation





U = Q*U ;
%
SingVsq =  (S.*S) ;
SingVsq = sort(SingVsq);  % s_r, s_{r-1} ... s_1
normEf2 = sqrt(cumsum(SingVsq)) ; % s_r , s_r + s_{r-1} ... s_r +s_{r-1}+ s_{r-2} ... + s_1

if  DATA.nouseRORTH == 0;
tol = sqrt(e0^2 - nC^2);
else
   tol = e0 ;  
end 

if tol<mu
    R = length(S) ;
else
    
    T = (sum(normEf2<tol)) ;
    R = length(S)-T ;
end

% Actual error
e_svd = sqrt(nC^2 + sum(S(R+1:end).^2)) ;

U = U(:,1:R);
S = S(1:R) ;
V = V(:,1:R) ;



