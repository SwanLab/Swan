function [Q B alpha_b beta_b ] = RORTHmatrixEA(A,BLOCKS,DATA,normAref)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Given a block matrix A, RORTHmatrix returns a cell array of basis matrices, Q, that approximately
% spans the  column space of A (with accuracy specified by epsilon).
% --------------------------
% INPUTS  (mandatory)
%------------------------------------------------------------------------------
%  A:      p x q cell array containing a conforming partition of A, i.e.:
%
%     A = {A_11, A_12 ... A_1q
%       A_21, A_22 ....A_2q
%       ... .... ..... ...
%       A_p1, A_p2 ... A_pq}
%
%     In turn, each entry A_ij may be a numeric array, or the name of a MAT-file containing
%     the numeric array. The second option is preferred when the whole
%     matrix does not fit into fast memory
%
%   BLOCKS : ....
%
%
%   OPTIONAL INPUTS  (with default values )
%   ----------------
%   1)  DATA.EPSILON_ABSOLUTE   = 0  (see definition epsilon)
%   2)  DATA.Rini = 0
%   3)  DATA.rho_est =0.05
%   4)  DATA.PARALLEL = 0
%
%    DATA.Rini = Initial estimation for the rank of submatrix A{1,1}. The
%    default value is min(DATA.rho_est*ceil(max(size(A{1,1})))).
%
%    DATA.PARALLEL = Enable parallelization of the loop over row blocks.
%    The only difference of the parallel loop and the serial one is that,
%    in the serial one, the maximum rank of the submatrices of A(:,i) is
%    used as initial estimation for the rank of A(1,i+1)
%
%    NOTE: If you try to run with the parallel option, a warning message
%    will appear indicating that the parallelization configuration should
%    be included before the parfor loop (the default options may not be optimal).
%
% -----------------------------------------------------------------------------
%
%  OUTPUTS
%  ------
%  Q  -->   (1 x size(A,1)) cell array such that Q{i}  approximately spans the
%  column space of row block  A(i,:)  (see description input data epsilon)%
%
%   B -->   Cell array of dimensions size(B) = size(A'),  where B{j,i} =
%   A{j,i}'*Q{i}
%
%   GAMMA --> size(A) matrix containing the difference between the error made in approximating
%   each submatrix, and the specified tolerance:
%   GAMMA(i,j) = sqrt(epsilon(i,j)^2*norm(A{i,j}'fro')^2 - norm(E{i,j}),'fro')
%
%   alpha_b and beta_b: Row matrices with the dimensions of B  (size(B{i,j}) = [alpha_b(i) beta_b(j)])
%
%   Rmax: max(rank(A{i,j})). Maximum rank of all submatrices of A
%
%  ETIME_row --> Cell array containing the times required for computing
%  each Q{i}
%
%
%  Written by Joaquín A. Hernández Ortega, Dec. 2016
%  UPC/CIMNE. jhortega@cimne.upc.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin == 0
    load('tmp1.mat')
  %  Qini = cell(size(A,1),1) ; 
end

if nargin == 3
    normAref =[] ; 
end

DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
DATA = DefaultField(DATA,'Rini',0) ;

p = size(A,1) ; Qloc = cell(1,p) ;  Q = cell(1,p) ; B = cell(size(A')) ; q = size(A,2) ;
GAMMA = zeros(size(A)) ; alpha_b = zeros(1,q) ; beta_b = zeros(1,p) ;
Rmax = 0 ; ETIME_row =cell(1,p);
%dbstop('17')
disp('----------------')
disp('LOOP OVER ROW BLOCKS')
disp('----------------')

%dbstop('91')

epsilon = zeros(size(A)) ; 
epsilon(BLOCKS==0) = -1 ;  % epsilon(i,j) = -1 means that this block is not taking into account


if DATA.PARALLEL == 0
    for i=1:p
        disp('------------------------------------------')
        disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
        disp('------------------------------------------')
        
        if isempty(normAref)
            DATA.normREF = [] ; 
        else
            DATA.normREF = normAref(i,:) ; 
        end
        
        [Q{i},B(:,i),GAMMA(i,:),ncolA,Rmax_loc,ETIME_row{i}] = RORTH1rowEA(A(i,:),epsilon(i,:),DATA)   ;
        DATA.Rini = Rmax_loc ;
        
     %   Q{i} = Qloc{i}(:,size(Qini{i},2)+1:end) ; 
        
        
        Rmax = max(Rmax,Rmax_loc) ;
        beta_b(i) = size(Q{i},2) ;
        if sum(ncolA)>0
        alpha_b = ncolA ;
        end
    end
    
else
    
 %   error('Set below the parallelization parameters (or comment this line  if you want to use the default ones)')
    if matlabpool('size') ==0
        matlabpool open
    end
  %  matlabpool open
    ncolA = cell(p,1); Rmax_loc = zeros(p,1) ; 
    parfor i=1:p
        [Q{i},B(:,i),GAMMA(i,:),ncolA{i},Rmax_loc(i),ETIME_row{i}] = RORTH1rowEA(A(i,:),epsilon(i,:),DATA)   ;
        beta_b(i) = size(Q{i},2) ;
    %    Q{i} = Qloc{i}(:,size(Qini{i},2)+1:end) ;
    end
    
 %   matlabpool close
    alpha_b = ncolA{1} ;
    Rmax = max(Rmax_loc) ;
end

end