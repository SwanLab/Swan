function [U,S,V,R,DATAOUT] = RNSVDcol(L,beta,epsilon,Nmax,r,dr,rho)
% -------------------------------------------------------
if nargin == 0
    load('tmpz.mat')
    epsilon = 0.001*ones(size(epsilon)) ; 
end
N =sum(beta);  % Number of columns of B
gamma = beta; J = 1 ; u = epsilon ; K = 1e20 ;  j = 1;
ncolL = N ; q0 = length(beta) ; q = 0 ; 
Nmax = min(Nmax,N-1) ;
while ncolL > Nmax & ncolL<K & q<q0
    K = ncolL ;  
    disp('-----------------------------------------')
    disp(['Iter = ',num2str(j), ' ncolL =',num2str(ncolL)])                                                                                                                                                                                                       
    [L,G,R_L] = RSVDloop(L,gamma,u,r,dr,rho) ; % SVD of all submatrices
    disp('-----------------------------------------')
    if j==1; R = R_L; end
    G = J*G ; ncolL = size(L,2) ; q0 = length(gamma) ;
    q = ceil(ncolL/Nmax);
    gamma = MakePartition(ncolL,q) ; % EQually-sized partitions such that Ni<Nmax
  %  dbstop('28')
    u(:) =0;  J = G ;  j = j+1 ;   r = max(R_L)*ones(size(gamma)) ;  dr =1 ; 
end

clear J ;
disp(['End of iterations  (total =',num2str(j-1),')'])
disp(['Nrows(L) =',num2str(size(L,2))])
if ncolL > Nmax
    warning('ncol(L) > than Nmax')
end

disp('--------------')
disp('Last SVD: ')
disp('--------------')
Rmax = max(R_L) ; % Estimation for the rank of L
Omega = randn(size(L,2),Rmax) ; dR = ceil(dr*Rmax) ;
[U,S,Vbar] = RSVD(L,Omega,0,dR) ;
V = G*Vbar ;
disp('Done')
DATAOUT = [] ;