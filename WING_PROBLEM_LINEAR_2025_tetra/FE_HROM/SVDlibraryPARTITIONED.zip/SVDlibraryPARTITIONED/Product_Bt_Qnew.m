function [Bt_Q  nrowL ncolL] = ProductQQtA(B,Q,DATA)

%dbstop('4')
if nargin == 0
    load('tmp1.mat')
end

[] = cellfun(@size,B) 


% 
% 
% Bt_Q = cell(size(B,2),1) ;
% nrowL = zeros(size(B,2),1) ;
% ncolL = zeros(size(B,2),1) ;
% iacum = 1;
% for j=1:size(B,2)
%     iacum = 1;
%     Bt_Q_loc = 0 ;
%     disp('--------------------------------------------')
%     disp(['j=',num2str(j),' of ',num2str(size(B,2)) ])
%     disp('--------------------------------------------')
%     for i=1:size(B,1)
%            disp(['i=',num2str(i),' of ',num2str(size(B,1)) ])
%         %     if  i==1 ; Bt_Q{j} = 0 ; end
%         if ischar(B{i,j})
%             SSS = load(B{i,j}) ;
%             fff = fieldnames(SSS) ;
%             alphaLOC_i = size(SSS.(fff{1}),1) ;
%             %  betaLOC(j) = size(SSS.(fff{1}),2) ;
%             INDICES = iacum:iacum+alphaLOC_i-1 ;
%             Bt_Q_loc =  Bt_Q_loc +  Q(INDICES,:)'*SSS.(fff{1});
%         else
%              alphaLOC_i = size(B{i,j},1) ;
%              INDICES = iacum:iacum+alphaLOC_i-1 ;
%              Bt_Q_loc =  Bt_Q_loc +  Q(INDICES,:)'*B{i,j};
%         end
%         iacum = iacum + alphaLOC_i;
%     end
%     
%     if  DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP_multi ==0
%         Bt_Q{j}=Bt_Q_loc; % [Q'*B{i}];
%         %  ncolL{i} = size(L{i},2) ;
%         %  nrowL{i} = size(L{i},1) ;
%     else
%         
%         nnn = dir(B{i,j}) ;%(1:end-4)
%         nnn = nnn.name ;
%         Bt_Q{j}  =  [DATA.PATH_STORE_AUX,nnn(1:end-4),'.mat'] ;
%         %   Li = LiT' ;
%         disp(['Saving ',Bt_Q{j},' ....'])
%         save(Bt_Q{j} ,'Bt_Q_loc') ;
%         disp('...done')
%     end
%     
%     nrowL(j) =size(Bt_Q_loc,1) ;
%     ncolL(j) = size(Bt_Q_loc,2) ;
% end
% 
% if  DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP_multi ==0
%     %    dbstop('46')
%     Bt_Q = cell2mat(Bt_Q) ;
%     nrowL = size(Bt_Q,1) ;
%     ncolL = size(Bt_Q,2) ;
% end
% 
% 
% 
