clc
clear all

format long g

addpath('AUXFUN')


% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
SIZE_A =8e3 ;     % Size matrix (Mbytes)
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;
N = ceil(sqrt(SIZE_A/8*1e6)) ; % Number of columns
M = N ;  % Number of rows
DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
p0_glo =6;  [4 8 16 32];  % Number of partitions along rows
q0_glo = 6 ; [4 8 16 32]; % Number of partitions along columns
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
COMPUTE_TRANSPOSE =0;
CALCULATE_ERROR_PART= 0 ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ERROR TOLERANCES
% -----------------------------------------
DATA.EPSILON_GLO = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs for the new version
% --------------------------
DATA.USE_SLOW_MEMORY.ACTIVE = 1 ;  
DATA.USE_SLOW_MEMORY.GENERATE_AGAIN = 1 ; 
DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP =  1; 
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;  

DATA.MaxSizeMatrixGb = 0.5 ; 
DATALOC.RUN_NESTED = 1; 
DATA.USE_ORTHwithTOL = 1 ;  
DATA.rho =1.05;  % Uncertainty factor (to estimate upper bound for rank of each submatrix)
DATA.dr = 1 ; % Incremental rank (relative)
DATA.LAST_SVD_RANDOM = 1; 
% END INPUTS -----------------------------------------------------
 
% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ; 
for  iproj = 1:length(p0_glo)
p0 = p0_glo(iproj) ;
q0 = q0_glo(iproj);
epsilon = 0.0*ones(p0,q0) ; % Tolerance

NAMEWS = ['DATAWS/ETIME_GLO_size',num2str(SIZE_A),'_lim_',num2str(DATA.MaxSizeMatrixGb ),'_SAVE_',...
    num2str(DATA.USE_SLOW_MEMORY.ACTIVE),'.mat'] ; 

[ETIME{iproj} Sincre] =...
    RSVD_QP_test(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE,CALCULATE_ERROR_PART,...
    DATALOC) ; 
end 
 
save(NAMEWS,'ETIME')
