clc
clear all

addpath('AUXFUN')


% INPUTS -------------------------------------------------------------
SIZE_B = 1e3 ;     % Size matrix (Mbytes)
R = 500  ; % Rank matrix, for DATA.TYPE = 1
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ; DATA.RetrieveBmemory = 0 ;
DATA.StoreSnapshotsRowWise = 0 ; DATA.DoNotGenerateAgainSnapshots =0 ;
N = ceil(sqrt(SIZE_B/8*1e6)) ; % Number of columns
M = N ;  % Number of rows

Nmax = N ; % Number of columns that can be processed at onc
q =  20; % Number of partitions
p = 3 ;
epsilon = 0.1*ones(p,q) ; % Tolerance
%epsilon(:,3) = 0.1 ;
dr = 0.1 ; % Incremental rank (relative)
RUN_INCRE = 1;  RUN_INCRE_COLROW = 0 ;
% END INPUTS -----------------------------------------------------
DATA.Dmu = [-2,3*pi ; -2,3*pi] ;
rho = 1.1 ;
% Generate matr
beta = MakePartition(N,q) ;
alpha = MakePartition(M,p) ;
disp('Approximated si0+ze')
disp([num2str(M*N*8e-6),' Mbytes'])
A = GenerateMatrixBlock(alpha,beta,DATA);
% -------------------------------------------------------------------

hold on 
figure(1)
ylabel('log10(Singular Values)')

if RUN_INCRE == 1
    disp('Randomized incremental method')
    disp('---------------------')
    TIMEpart = tic ;    
    [Uincre,Sincre,Vincre] = RSVDblockm(A,alpha,beta,epsilon,dr,rho,DATA) ;
    disp(['RANK = ',num2str(length(Sincre))])
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME incre (random). = ',num2str(TIMEpart)])
    disp('---------------------')    
    figure(1)
    hold on
    h = plot(log10(Sincre)) ; 
    legend(h,['p = ',num2str(p), ', q=',num2str(q)])  
    legend('off')  
    legend('show')    
end



if RUN_INCRE_COLROW == 1
    disp('Randomized incremental method (both column- and row-wise)')
    disp('---------------------')
    TIMEpart = tic ;
    
    [Uincre,Sincre,Vincre] = RSVDblockmRC(A,alpha,beta,epsilon,dr,rho,DATA) ;
    disp(['RANK = ',num2str(length(Sincre))])
    TIMEpart = toc(TIMEpart) ;
    disp(['TIME incre (random). = ',num2str(TIMEpart)])
    disp('---------------------')
    
end


