 
% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
DATA.TryToPrecomputeQtB = 0; % 
SIZE_A =0.1e3 ;     % Size matrix (MBytes)
ratioNM =10 ; 
N = ceil(sqrt(SIZE_A/8*1e6)/sqrt(ratioNM)) ; % Number of columns
M = ceil( SIZE_A/8*1e6/N) ;  % Number of rows
p0 =1;   % Number of partitions along rows
q0 =5 ;  % Number of partitions along columns
DATA.USE_SLOW_MEMORY.ACTIVE =0;
%DATA.USE_SLOW_MEMORY.GENERATE_AGAIN =0;  % Generate again matrix data
%DATA.MAXIMUM_STORAGE_SLOW_MEMORY = 0.5 ; %  mAXIMUM SIZE THAT CAN BE STORED IN FAST MEMORY (one-level method)
%DATA.MaxSizeMatrixGb = 0.25; % Maximum size of a single submatrix (FOR SUBPART.).  TWO LEVEL METHOD !!!!
%DATA.TWOLEVELMETHOD.ACTIVE = 1;  % To activate the multilevel method
%DATA.TWOLEVELMETHOD.TypePartition = 'UNIFORM' ;  % Type of sub-partition  (for generation purposes)
% Testing just one row 
% DATALOC.TEST_ONE_ROW = 0; 
% DATALOC.SYMMETRIC_PRUEBA = 0; 

%%%% ACCURACY DATA 
epsilon = 1*ones(p0,q0) ; % Block-wise tolerance 
epsilon(:,1) = 0 ; % Block-wise tolerance 
%epsilon(1,:) =0 ; % Block-wise tolerance 

DATA.EPSILON_GLO = 0; 
%% OTHER INPUTS 
DATA.TWOLEVELMETHOD.LimitGbytes = 4.5;  %
DATA.NITER_RORTH = 10 ; 
DATA.TRANSPOSE =0;
DATA.PARALLEL = 0;  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% -----------------------------------------


%% DEFAULT OPTIONS
% ------------------
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;

DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
CALCULATE_ERROR_PART=1;
DATALOC.ERROR_PART_ABSOLUTE = 0 ; 
COMPUTE_TRANSPOSE =0;  
DATALOC.RESHAPE =[] ;  [2 3]; [] ;  [2 2];  [2 2] ; 
p0_REF =p0; 
q0_REF = q0; 
DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES  = 0;

% END INPUTS -----------------------------------------------------

% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ;
%for  iproj = 1:length(p0_glo)