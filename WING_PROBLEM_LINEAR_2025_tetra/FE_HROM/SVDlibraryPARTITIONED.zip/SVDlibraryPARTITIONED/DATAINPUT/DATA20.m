DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES  = 0;
 
% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
SIZE_A =1e3 ;     % Size matrix (Gbbytes)
ratioNM =40 ; 
N = ceil(sqrt(SIZE_A/8*1e6)/sqrt(ratioNM)) ; % Number of columns
M = ceil( SIZE_A/8*1e6/N) ;  % Number of rows
p0 =20;   % Number of partitions along rows
q0 =1 ;  % Number of partitions along columns
epsilon = 1e-4*ones(p0,q0) ; % Block-wise tolerance 
epsilon([1,5,15,20]) = 1e-8 ; 
DATA.EPSILON_GLO = 0; 
p0_REF =p0; 
q0_REF = q0; 
DATA.USE_SLOW_MEMORY.ACTIVE = 1;    % Use slow memory (default when twolevel is active)
DATA.USE_SLOW_MEMORY.GENERATE_AGAIN =1;  % Generate again matrix data
DATA.MAXIMUM_STORAGE_SLOW_MEMORY = 4 ; 
DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP =  0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.NITER_RORTH = 10 ; 
DATA.TRANSPOSE =0;
DATA.PARALLEL = 0;  

%DATA.Rini = 500 ; 
%%%%%%%%%%%%%%%%
% ERROR TOLERANCES
% -----------------------------------------


% Inputs for the new version
% --------------------------
DATA.TWOLEVELMETHOD.ACTIVE = 0;  % To activate the multilevel method
DATA.TWOLEVELMETHOD.TypePartition = 'UNIFORM' ;  % Type of sub-partition
DATA.TWOLEVELMETHOD.TryToUseFastMemory = 1;  % 
DATA.TWOLEVELMETHOD.LimitGbytes = 1;  %
DATA.MaxSizeMatrixGb = 0.5; % Maximum size of a single submatrix

%% DEFAULT OPTIONS
% ------------------
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;

DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;

DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
CALCULATE_ERROR_PART=1;
DATALOC.ERROR_PART_ABSOLUTE = 0 ; 
COMPUTE_TRANSPOSE =0;  
DATALOC.RESHAPE =[] ;  [2 3]; [] ;  [2 2];  [2 2] ; 

% END INPUTS -----------------------------------------------------

% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ;
%for  iproj = 1:length(p0_glo)