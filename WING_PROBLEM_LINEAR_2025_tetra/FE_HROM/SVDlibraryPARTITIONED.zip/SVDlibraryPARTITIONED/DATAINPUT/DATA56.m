 
% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
DATA.COMPLETE_SVD = 1;

DATA.TryToPrecomputeQtB = 1; %
SIZE_A =0.2e3 ;     % Size matrix (Gbbytes)
ratioNM =1 ;
p0 =10;   % Number of partitions along rows
q0 =  10 ;  % Number of partitions along columns
%%%% ACCURACY DATA
epsilon = 1*ones(p0,q0) ; % Block-wise tolerance
epsilon([1  ],:) =0;  % Block-wise tolerance
 epsilon(:,[1  ]) =0;  % Block-wise tolerance

DATA.EPSILON_GLO = 0.01;

%%%%%%%%%%%%%%%%%%%%%%%%%
N = ceil(sqrt(SIZE_A/8*1e6)/sqrt(ratioNM)) ; % Number of columns
M = ceil( SIZE_A/8*1e6/N) ;  % Number of rows

DATA.USE_SLOW_MEMORY.ACTIVE =0;
DATA.USE_SLOW_MEMORY.GENERATE_AGAIN =1;  % Generate again matrix data
DATA.MAXIMUM_STORAGE_SLOW_MEMORY = 0.001 ; %  mAXIMUM SIZE THAT CAN BE STORED IN FAST MEMORY (one-level method)
DATA.MaxSizeMatrixGb = 0.25; % Maximum size of a single submatrix (FOR SUBPART.).  TWO LEVEL METHOD !!!!
DATA.TWOLEVELMETHOD.ACTIVE = 0;  % To activate the multilevel method
DATA.TWOLEVELMETHOD.TypePartition = 'UNIFORM' ;  % Type of sub-partition  (for generation purposes)





%% OTHER INPUTS 
DATA.TWOLEVELMETHOD.LimitGbytes = 4.5;  %
DATA.NITER_RORTH = 10 ; 
DATA.TRANSPOSE =0;
DATA.PARALLEL = 0;  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% -----------------------------------------


%% DEFAULT OPTIONS
% ------------------
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;

DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
CALCULATE_ERROR_PART=1;
DATALOC.ERROR_PART_ABSOLUTE = 0 ; 
COMPUTE_TRANSPOSE =0;  
DATALOC.RESHAPE =[] ;  [2 3]; [] ;  [2 2];  [2 2] ; 
p0_REF =p0; 
q0_REF = q0; 
DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES  = 0;

% END INPUTS -----------------------------------------------------

% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ;
%for  iproj = 1:length(p0_glo)