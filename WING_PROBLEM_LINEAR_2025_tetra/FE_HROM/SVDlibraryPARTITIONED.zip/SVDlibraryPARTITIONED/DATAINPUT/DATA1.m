DATALOC.RUN_ONELEVEL_FOR_COMPARING_PURPOSES  = 0;
% INPUTS FOR GENERATING MATRIX
% ----------------------------------------------------------------------
SIZE_A =1e3 ;     % Size matrix (Mbytes)
p0 =1;   % Number of partitions along rows
q0 =10 ;  % Number of partitions along columns
p0_REF =1; 
q0_REF = 1; 
DATALOC.RESHAPE =[] ;  [2 3]; [] ;  [2 2];  [2 2] ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.NITER_RORTH = 10 ; 
DATA.PREGENERATION_RANDOM = 1; 
%%%%%%%%%%%%%%%%
% ERROR TOLERANCES
% -----------------------------------------
DATA.EPSILON_GLO = 0.00; %1e-6 ; % 5e-7; % Global tolerance
epsilon = 0.0*ones(p0,q0) ; % Block-wise tolerance 
% Inputs for the new version
% --------------------------
DATA.TWOLEVELMETHOD.ACTIVE = 0;  % To activate the multilevel method
DATA.TWOLEVELMETHOD.TypePartition = 'UNIFORM' ;  % Type of sub-partition
DATA.TWOLEVELMETHOD.TryToUseFastMemory = 1;  % 
DATA.TWOLEVELMETHOD.LimitGbytes = 1;  %
DATA.MaxSizeMatrixGb = 0.5; % Maximum size of a single submatrix
DATA.USE_SLOW_MEMORY.ACTIVE = 0 ;    % Use slow memory (default when twolevel is active)
DATA.USE_SLOW_MEMORY.GENERATE_AGAIN =1;  % Generate again matrix data
%% DEFAULT OPTIONS
% ------------------
DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP =  1;
DATA.PATH_STORE_A = ['DATAWS/DATA_Amatrix/'] ;

DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ;
ratioNM = 1 ; 
N = ceil(sqrt(SIZE_A/8*1e6)/ratioNM) ; % Number of columns
M = ceil( SIZE_A/8*1e6/N) ;  % Number of rows
DATA.Dmu = [-3,4*pi ; -3,4*pi] ;
nrepROWS = 1;   % Number of tiling copies  (A = [A; A; A ; ....])
nrepCOLS = 1;  % Number of tiling copies (A = [A, A, A ....])
COMPUTE_TRANSPOSE =0;
CALCULATE_ERROR_PART=0;

% END INPUTS -----------------------------------------------------

% Generate matrix (by tiling several copies of the same matrix)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DATA.SIZE_A = SIZE_A ;
%for  iproj = 1:length(p0_glo)