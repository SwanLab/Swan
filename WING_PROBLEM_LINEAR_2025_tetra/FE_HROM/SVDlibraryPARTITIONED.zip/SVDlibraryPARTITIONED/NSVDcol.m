function [U,S,V,normLapprox] = NSVDcol(L,beta,epsilon,Nmax,DATA)
% DATA: Partitioned matrix B = [B1 B2 ... Bq], where B{i} = B(:,beta{i}),
% error threshold epsilon (1 x q)
% Nlim: Number of columns that can be processed at once
% RESULT: Orthogonal matrices U,V, and S = diag(s1,s2,,,sk)
% 6-Oct-2016, Joaquín A. Hernández, UPC-CIMNE, jhortega@cimne.upc.edu
% -------------------------------------------------------
if nargin == 0
    load('tmp.mat')
end
N =sum(beta);  % Number of columns of B
gamma = beta; J = 1 ; u = epsilon ; K = 1e20 ;  j = 1;
ncolL = N ; q0 = length(beta) ; q = 0 ; 

if Nmax >= N 
    Nmax = N-1; 
end

%dbstop('20')
while ncolL > Nmax & ncolL<K & q<q0
    K = ncolL ;  
    disp('-----------------------------------------')
    disp(['Iter = ',num2str(j), ' ncolL =',num2str(ncolL)])                                                                                                                                                                                                       
    [L,G,normLapprox_j] = SVDloop(L,gamma,u) ; % SVD of all submatrices
    if j ==1; normLapprox =  normLapprox_j ; end
    disp('-----------------------------------------')
    G = J*G ; ncolL = size(L,2) ;  q0 = length(gamma) ;
    q = ceil(ncolL/Nmax);
    gamma = MakePartition(ncolL,q) ; % EQually-sized partitions such that Ni<Nmax
    u(:) =0;  J = G ;  j = j+1 ; 
end

clear J ;
disp(['End of iterations  (total =',num2str(j-1),')'])
disp(['Nrows(L) =',num2str(size(L,2))])
if ncolL > Nmax
    warning('ncol(L) > than Nmax')
end

disp('Last SVD: ')
[U,S,Vbar] = SVD(L,0) ;
%dbstop('44')
%% Determining level of truncation 
% S2 = (S.^2) ; 
% cS2 = cumsum(S2) ; 
% threshold = sum(sum(normLapprox.^2)) ; 
% R = sum(cS2<=threshold) ;
% Vbar = Vbar(:,1:R) ; 
% S = S(1:R) ; 
% U = U(:,1:R) ;


V = G*Vbar ;
disp('Done')
DATAOUT = [] ;