function [ETIME ERROR_PART  Sincre RankR] =  RunTestsFinal(NAMEINPUT)


if nargin == 0
    NAMEINPUT = 'DATA4' ; 
end


if exist('InitalDiscretization') ==0
addpath('AUXFUN')
end
addpath('DATAINPUT')

%%%%%%%%%%%%%%%%%%%%5

eval(NAMEINPUT) ; 

%%%%%%%%%%%%%%%%%%%%%%%%5



NAMEWS = ['DATAWS/NAMEINPUT',num2str(SIZE_A),'_SAVE_',mfilename,'.mat'] ;

[ETIME  Sincre ERROR_part Uincre Vincre A] =...
    RSVD_QP_test(N,q0,M,p0,DATA,epsilon,nrepROWS,nrepCOLS,COMPUTE_TRANSPOSE,CALCULATE_ERROR_PART,...
    DATALOC) ;
%end



%  epsilon = 0.01*ones(size(A)) ;
ERROR_PART = [] ;
a = 0 ; 
%dbstop('67')




if CALCULATE_ERROR_PART == 1 
    
 %   A = cell2mat(A) ; 
  %  beta = MakePartition(size(A,2),q0_REF) ;
   %  alpha = MakePartition(size(A,1),p0_REF) ;
    %A = mat2cell(A,alpha,beta) ;
    
    [ERROR_PART,RANK] = DiffApproxSVD( Uincre(:,1:end-a),Sincre(1:end-a),Vincre(:,1:end-a),[],A,...
        DATALOC) ;
    
end


save(NAMEWS,'ETIME','Sincre','ERROR_part')
