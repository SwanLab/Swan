function [Q,L,gamma,nrowL,ncolL,epsilonSVD,Rmax,ETIME] = RORTH1rowINT(B,beta,epsilon,DATA)

dbstop('4')
if nargin == 0
    load('tmp.mat')    
end

q = length(beta) ; 
if q ==1
     [Q,L,gamma,nrowL,ncolL,epsilonSVD,Rmax,ETIME] = RORTH1row(B,beta,epsilon,DATA) ; 
else
%% Computing intersection spaces 
% ------------------------------
Ui = {} ; 
e0 = 0 ; mu = 0 ; R = DATA.Rini ;  Rmax = 0 ; 
for i = 1:q-1
    % Basis matrix i-th submatrix 
    [Ui{i},Si,Vi,e_svdi,RankMatrix] = RSVDt(B{i},e0,mu,R,DATA) ; 
    R = RankMatrix ; 
    Rmax = max(R,Rmax) ; 
end

% Intersection of column spaces
I ={} ; 
iacum = 1; 
for i=1:q-1
    for j= i+1:q
        I{iacum} = Ui{i}*(Ui{i}'*B{j}); 
        iacum = iacum + 1; 
    end
end

% Basis matrix for the column space
epsilonLOC = 0.01*ones(size(I)) ; 
DATA.DOnotCOMPUTE_BQt = 1 ; 
[Q,L,gamma,nrowL,ncolL,epsilonSVD,Rmax,ETIME] = RORTH1row(I,[],epsilonLOC,DATA) ; 

% Now we determine the actual Q
DATA.Q = Q ; 
DATA.Rini = Rmax ; 
[Q,L,gamma,nrowL,ncolL,epsilonSVD,Rmax,ETIME] = RORTH1row(B,beta,epsilon,DATA) ; 





   
end
 