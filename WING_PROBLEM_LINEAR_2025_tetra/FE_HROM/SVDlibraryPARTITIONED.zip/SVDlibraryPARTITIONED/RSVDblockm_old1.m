function [U,S,V] = RSVDblockm_old1(A,alpha,beta,epsilon,dr,rho,DATA)
%
%dbstop('4')
if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('LOOP OVER ROW BLOCK MATRICES')
disp('----------------')
p = length(alpha) ; q = length(beta) ;
X = cell(1,p) ; K = cell(1,p) ; M = sum(alpha) ;
N = sum(beta);
if ~iscell(A)
    A = mat2cell(A,alpha,beta) ;
end
colK = zeros(q,1);
%dbstop('19')
for i=1:p
    disp('------------------------------------------')
    disp('------------------------------------------')
    disp(['ROW block = ',num2str(i), '  of ',num2str(p)])
    disp('------------------------------------------')
    disp('------------------------------------------')
    TTT =tic ;
    Rini = 0 ;
    [Xi,Zi,Ti,epsilonSVD] = RSVDincre(A(i,:),beta,epsilon(i,:),dr,rho,Rini)   ; 
    TTT= toc(TTT);
    K{i} = bsxfun(@times,Ti',Zi)' ;
    %  dbstop('13')
    X{i} = sparse(Xi) ;
    disp(['R = ',num2str(length(Zi)),' of ',num2str(sum(beta)),' columns']) 
    disp(['Time = ',num2str(TTT)])
    colK(i) = length(Zi) ;
end

%dbstop('45')
X = blkdiag(X{:}) ;
disp('---------------------------------------')
disp('SVD of matrix K ... ')
disp('---------------------------------------')
Rini = size(K{1},2);
epsilon = zeros(size(K)) ;
[V,S,Ubar] = RSVDincre(K,[],epsilon,dr,rho,Rini)   ;
%dbstop('49')
%A = cell2mat(K) ; % To free memory
% %clear K ;
% Rest = max(colK) ;
% Omega = randn(size(A,2),Rest) ; dR =  Rest ;
% [V,S,Ubar,DATAOUT] = RSVD(A,Omega,0,dR)   ;
disp('---------------------------------------')
disp('DONE ... ')
disp('Computing left singular vectors U = X*Ubar')
U = X*Ubar ;
disp('Done ')
