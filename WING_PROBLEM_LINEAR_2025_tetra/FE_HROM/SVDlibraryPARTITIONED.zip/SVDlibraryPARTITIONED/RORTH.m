function [Q,i,nC] = RORTH(C,Q,mu,dR) 

%dbstop('4')
if nargin == 0
    load('tmp1.mat')
end

[M,N] = size(C); % Frobenius norm of C
dC = C-Q*(Q'*C) ;
nC = norm(dC,'fro') ;  
i = 0 ; 
STORE_nc = []; 
RANKS = [] ;
while nC>=mu  & size(Q,2)<N
 
    i = i + 1 ;
    Omega = randn(N,dR) ;
     %Omega = rand(N,dR) ;
    Qi = ORTH(dC*Omega,mu);
    Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
    dC = dC - Qi*(Qi'*dC) ;
    Q = [Q Qi] ; 
    nC = norm(dC,'fro') ;
    STORE_nc(end+1) = nC ;
    RANKS(end+1) = size(Q,2);
    disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
end

hold on
xlabel('RANK')
ylabel('ERROR')
plot(RANKS,STORE_nc)

end
