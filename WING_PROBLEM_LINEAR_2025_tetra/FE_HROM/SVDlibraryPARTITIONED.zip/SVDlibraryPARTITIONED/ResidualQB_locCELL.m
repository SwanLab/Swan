function [B  b db alphaLOC betaLOC]= ResidualQB_loc(B,Q,DATA)

% dB = B- Q^T*Q*B
% First we make  --> dB <-- Q^T*Q*B, and then   dB <-- B-dB
%dbstop('6')
if nargin == 0
    load('tmp3.mat')
end

[Qt_B b alphaLOC betaLOC B] = Product_Qt_B_cell(B,Q) ;
%% Difference betwee n B and Q*(Q^T B), and norm of each submatrix dB_{ij}
%-------------------------------------------------------------------------
iacum = 1;
%dB= cell(size(B)) ;
dbMAT = zeros(size(B)) ;
disp(['Computing dB = B- Q*Q^T B'])
for i=1:size(B,1)
    disp('_________________________________________')
    disp(['i=',num2str(i),' of ',num2str(size(B,1))])
    disp('_________________________________________')
    for j=1:size(B,2)
        disp(['j=',num2str(j),' of ',num2str(size(B,2))])      
        INDICES = iacum:iacum+alphaLOC(i)-1 ;
        B{i,j} = B{i,j} - Q(INDICES,:)*Qt_B{j};        
        dbMAT(i,j) = norm(B{i,j},'fro') ;
    end
    iacum = iacum + alphaLOC(i);
end
db = norm(dbMAT,'fro') ; % Norm of matrix "B"