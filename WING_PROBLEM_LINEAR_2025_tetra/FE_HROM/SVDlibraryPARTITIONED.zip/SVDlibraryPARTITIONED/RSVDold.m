function [U,S,V] = RSVD(C,epsilon,Omega)
% Randomized SVD
% INPUTS: C: Matrix to be factorized (M x n),
%         0<= epsilon <= 1: Error threshold
%         Omega: Randomized test matrix  (M x R), where R is an estimation
%         of rank(C)
% OUTPUT: U,S,V, truncated SVD, C =U*S*V' + E such that norm(E,'F')/norm(C,'F')<=epsilon
% % 10-Oct-2016, Joaquín A. Hernández, UPC-CIMNE, jhortega@cimne.upc.edu
% --------------------------------------------------------------------------------
%dbstop('11')
if nargin == 0
    load('tmp.mat')
    M = 4000 ; n  = 4000 ; R = 100 ;  nrep = 10 ;
     C = 1e3*rand(ceil(M/nrep),n) ;
     C = repmat(C,nrep,1) ;
     Omega = rand(n,R) ;
     epsilon = 0 ;
     METHOD = 0;
end

tic ;
[M n]= size(C);
R = size(Omega,2) ;
% ---------------------------
Y = C*Omega ; 
Q = orth(Y) ;
if size(Q,2) == R
    [U, S,V] = svd(C,'econ') ;
else
    % --------------------------
    D = Q'*C ;
    [U, S,V] = svd(D,'econ') ;
    U = Q*U ;
end
% ------------------------------

% --------------------------------
S = diag(S) ; % S = [S1 S2 ... SR]'
tol = max(size(C))*eps(max(S));
R = sum(S > tol);

if  epsilon ==0
    K = R ;
else
    % Determining level of truncation
    SingVsq =  (S.*S) ;
    DENOM = sum(SingVsq) ;    NOMINAD = DENOM-cumsum(SingVsq) ;
    ERRORsvd = sqrt(NOMINAD)/sqrt(DENOM);
    K = length(find(ERRORsvd>=epsilon)) ;
end
K = min(R,K);
U = U(:,1:K)  ;
S = S(1:K)    ;
V =  V(:,1:K) ;
% ------------------------------------


toc ;
%
% profile off
%
%
% dbstop('91')
% COMPROBAR = 1;
% if COMPROBAR == 1
%     tic
%     [Ue,Se,Ve] = svd(C,'econ') ;
%     toc
%
%     Ue = Ue(:,1:K);
%     norm(abs(Ue)-abs(U))
% end
%
%
%
%
%


