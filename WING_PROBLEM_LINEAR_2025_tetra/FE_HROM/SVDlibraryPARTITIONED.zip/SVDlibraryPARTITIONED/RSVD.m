function [U,S,V,e_svd,RankMatrix] = RSVD(C,e0,mu,Omega,DATA)


%tic
% Basis matrix for the column space of C
[Q] = RORTH_adapt(C,Omega,mu) ;
if isempty(Q)
    U = [] ;     S = [] ;     V = [] ;
    e_svd = 0 ;
else
    %  DATA.tol = mu  ;
    if  isnumeric(Q)
        D = Q'*C ;
        if DATA.COMPUTE_V_SVD == 0
            [U,S] = SVD(D,0); % No truncation
            V = [] ;
        else
            [U,S,V] = SVD(D,0); % No truncation
        end
        U = Q*U ;
    else
        % C appears to be full rank
        if DATA.COMPUTE_V_SVD == 0
            [U,S] = SVD(C,0); % No truncation
            V = [] ;
        else
            [U,S,V] = SVD(C,0); % No truncation
        end
    end
    %% Truncation
    RankMatrix = length(S);
    disp(['Rank matrix =',num2str(RankMatrix)]) ;
    SingVsq =  (S.*S) ;
    SingVsq = sort(SingVsq);  % s_r, s_{r-1} ... s_1
    normEf2 = sqrt(cumsum(SingVsq)) ; % s_r , s_r + s_{r-1} ... s_r +s_{r-1}+ s_{r-2} ... + s_1
    tol = e0 ;
    if tol<=mu
        R = length(S) ;
    else
        T = (sum(normEf2<tol)) ;
        R = length(S)-T ;
    end
    % Actual error
    e_svd = sqrt(sum(S(R+1:end).^2)) ;
    U = U(:,1:R);
    S = S(1:R) ;
    if ~isempty(V)
        V = V(:,1:R) ;
    end
    disp(['Truncated rank=',num2str(R)]) ;
end
%toc
