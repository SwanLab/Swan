function [Q,L,gamma,nrowL,ncolL,epsilonSVD,tloc,Rmax,tsave] = RORTH1rowCOUPLED(B,beta,epsilon,DATA,Pit)

%dbstop('4')
if nargin == 0
    load('tmp.mat')
    
end

if isempty(beta)
    for i = 1:length(B)
        beta(i) = size(B{i},2) ;
    end
end

DATA = DefaultField(DATA,'dr',1) ;
DATA = DefaultField(DATA,'rho',1.05) ;

dr = DATA.dr;
rho = DATA.rho ;
DATA = DefaultField(DATA,'EPSILON_ABSOLUTE',0) ;
DATA = DefaultField(DATA,'Rini',0) ;



disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(B) ;
G = cell(1,q) ;
% if ~iscell(B) % Convert B into a cell array of submatrices
%     M = size(B,1) ;
%     B = mat2cell(B,M,beta) ;
% end
R = zeros(1,q) ;
Rlft = DATA.Rini ;


[~, INDICES] = sort(epsilon) ;

epsilonSVD = zeros(size(INDICES)) ;
gamma =  zeros(size(INDICES)) ;

DATA = DefaultField(DATA,'Omega',[]) ;
if isempty(DATA.Omega)
    DATA.Omega = randn(max(beta),max(beta)) ;
end


bnorm = gamma ;
tloc = zeros(1,q) ;
Q = [] ;
tsave = 0 ;
for j=1:q
    
    i = INDICES(j) ;
    disp('------------------------------------------')
    disp(['i = ',num2str(j), '  of ',num2str(q)])
    TTT =tic ;
    %  dbstop('42')
    if isstr(B{i})
        loct1 =  tic ;
        disp(['Loading ...'])
        SSS = load(B{i}) ;
        fff = fieldnames(SSS) ;
        Bi = SSS.(fff{1}) ; SSS = [] ;
        disp(['...Done'])
        tsave = tsave + toc(loct1) ;
    else
        Bi = B{i} ;
    end
    
    Ni = size(Bi,2) ;
    Mi = size(Bi,1) ;
    RiUP = min(Ni,Mi); % Upper bound for the rank
    
    Rest = ceil(rho*Rlft); dR = ceil(Rest*dr) ;
    rho_est = 0.1 ;
    if Rest ==0; Rest = ceil(rho_est*RiUP); dR = Rest ;   end
    Rest = min(Rest,RiUP);
    %%%%
    b = norm(Bi,'fro') ;
    bnorm(i) = b ;
    mu = (max(size(Bi))*eps(b))  ;% Machine precision
    
    
    BPPt = Bi*Pit{i}*Pit{i}' ;
    % Basis matrix for its column space
    e0 = mu ;
    RestLOC = ceil(rho*size(Pit{i},2)) ;
    dR =RestLOC ;
    [Qp,Hi,Gi,eSVD,RankMatrix] = RSVDt(BPPt,DATA.Omega(1:Ni,1:RestLOC),e0,dR,mu,DATA);
    
    if j==1
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % The firt submatrix of Q will be that of the column space of
        % Bi*P*P^T
        
        % Therefore
        Q =  [Qp] ;
        dB = Bi- Q*(Q'*Bi) ;
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %   dB = Bi ;
    else
        
        % Therefore, we make
        dbstop('111')
     %   Qp = ORTH(Qp - Q*(Q'*Qp),mu) ;
        dB = Bi- Qp*Qp'*Bi ;     
       %  db = norm(dB,'fro') ;
        %          muLOC = (max(size(dB))*eps(db))  ;% Machine precision

         Q  =ORTH(Q-Qp*(Qp'*Q),mu) ;
 
     
  
        % and proceed as usual
        
        dB = dB - Q*(Q'*dB) ; % Residual
              Q = [Q Qp];
    end
    
    
    if epsilon(i) > 0
        if DATA.EPSILON_ABSOLUTE ==0
            e0 = epsilon(i)*b ;
        else
            e0 = epsilon(i) ;
        end
    else
        e0 = mu ;
    end
    
    e0 = max(e0,mu) ;
    
    if ~isempty(dB)
        %      dbstop('95')
        %  if j>1
        db = norm(dB,'fro');
        % else
        %    db = b ;
        % end
        if db > e0 %| j==1
            %  dbstop('100')
            DATA.Rest  =Rest ;
            [dQ,Hi,Gi,eSVD,RankMatrix] = RSVDt(dB,DATA.Omega(1:Ni,1:Rest),e0,dR,mu,DATA);
            if isempty(dQ)
                eSVD = db ;
            end
        else
            dQ = [] ; Hi = [] ; Gi = [] ;
            eSVD = db ;
            RankMatrix = Rest ;
        end
        
        
        if epsilon(i) > 0
            epsilonSVD(i) = eSVD/b ;
            
            gamma(i) =  sqrt((epsilon(i)*b)^2 - eSVD^2) ;
        else
            epsilonSVD(i) = eSVD ;
        end
    else
        dQ = [] ;
        Hi = [] ;
        Gi = [] ;
        eSVD = [] ;
        RankMatrix = Rest ;
    end
    
    
    
    
    if j>1 & ~isempty(dQ)
        dQ = ORTH(dQ - Q*(Q'*dQ),mu) ;
    end
    Q = [Q dQ];
    
    % dbstop('136')
    R(j) = RankMatrix;
    if   ~isempty(dQ)
        Rlft = RankMatrix ;
    end
    
    
    
    
    tloc(j)= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns (rank = ',num2str(RankMatrix),')'])
    disp(['ERROR = ', num2str(epsilonSVD(i)),' (THRESHOLD:',num2str(epsilon(i)),' )'])
    
    disp(['Time = ',num2str(tloc(j))])
end

ncolL  = zeros(size(B)) ;
nrowL  = zeros(size(B)) ;




L = cell(q,1) ;
for i = 1:length(B)
    
    if isstr(B{i})
        loct1 =  tic ;
        disp(['Loading ...'])
        SSS = load(B{i}) ;
        fff = fieldnames(SSS) ;
        Bi = SSS.(fff{1}) ; SSS = [] ;
        disp(['...Done'])
        
        if  DATA.USE_SLOW_MEMORY.STORE_ALSO_SECOND_STEP ==0
            L{i} =Bi'*Q ; % [Q'*B{i}];
            ncolL(i) = size(L{i},2) ;
            nrowL(i) = size(L{i},1) ;
        else
            
            %  dbstop('173')
            dirREF = dir(B{i}) ; dirREF = dirREF.name ;
            L{i}  =  [DATA.PATH_STORE_AUX,dirREF(1:end-4),num2str(i),'.mat'] ;
            
            
            Li = Bi'*Q ;
            save(L{i},'Li') ;
            
        end
        tsave = tsave + toc(loct1) ;
    else
        %   Bi =  ;
        L{i} =B{i}'*Q ; % [Q'*B{i}];
        ncolL(i) = size(L{i},2) ;
        nrowL(i) = size(L{i},1) ;
        
    end
    
    
    
end

%dbstop('144')
Rmax = max(R)  ;

