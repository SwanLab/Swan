function [U,S,V,R,DATAOUT] = RSVDiter(B,beta,epsilon,r,dr,rho)
% -------------------------------------------------------
if nargin == 0
    load('tmp1.mat')
    epsilon = 0.001*ones(size(epsilon)) ;
end

if nargin == 0
    load('tmp.mat')
end
disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(beta) ;
L = cell(1,q) ; G = cell(1,q) ;
if ~iscell(B) % Convert B into a cell array of submatrices
    M = size(B,1) ;
    B = mat2cell(B,M,beta) ;
end
R = zeros(1,q) ; Rlft = 0 ;
Nm = 0 ; % Maximum number of columns
for i=1:length(B)
    Nm = max(Nm,size(B{i},2)) ;
end
Omega = randn(Nm,Nm) ; % Random matrix
for i=1:q
    disp('------------------------------------------')
    disp(['i = ',num2str(i), '  of ',num2str(q)])
    TTT =tic ;
    if isnumeric(B{i})
        Ni = size(B{i},2) ;
        %  dbstop('31')
        Rest = ceil(rho*max(Rlft,r(i))); dR = ceil(Rest*dr) ;
        if Rest ==0; Rest = ceil(dr*Ni); dR = Rest ;   end
        [Di,Hi,Gi] = RSVD(B{i},Omega(1:Ni,1:Rest),epsilon(i),dR);
        
    else
        error('Option not implemented yet')
        %         disp('Retrieving from memory ...')
        %         load(B{i}) ; % Retrieved from memory
        %         Ni = size(Bi,2) ;
        %         disp('Done')
        %         Omega = rand(Ni,R) ;
        %         [Di,Hi,Gi] = RSVD(Bi,epsilon(i),Omega);
        %
        %         % Delete from memory
        %         disp('Deleting...')
        %         delete(B{i});
        
    end
    R(i) = size(Di,2) ; Rlft = R(i)  ;
    TTT= toc(TTT);
    
    L{i} = bsxfun(@times,Di',Hi)' ;
    %  dbstop('13')
    G{i} = sparse(Gi) ;
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns'])
    disp(['Time = ',num2str(TTT)])
end

% Writing G in sparse format
% G = diagonal(G{1},G{2},...G{q})
%dbstop('26')
L = cell2mat(L) ;
G = blkdiag(G{:}) ;
