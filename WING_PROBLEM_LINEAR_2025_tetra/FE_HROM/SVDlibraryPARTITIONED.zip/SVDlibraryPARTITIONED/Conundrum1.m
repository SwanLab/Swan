clc
clear all

addpath('AUXFUN')


% INPUTS -------------------------------------------------------------
SIZE_B = 0.0001e3 ;     % Size matrix (Mbytes)
R = 500  ; % Rank matrix, for DATA.TYPE = 1
DATA.SAVE = 0; DATA.LOAD = 0; DATA.TYPE = 2 ; DATA.RetrieveBmemory = 0 ; 
DATA.StoreSnapshotsRowWise = 0 ; DATA.DoNotGenerateAgainSnapshots =0 ; 
N = ceil(sqrt(SIZE_B/8*1e6)) ; % Number of columns
M = N ;  % Number of rows

Nmax = N ; % Number of columns that can be processed at onc
q =  20; % Number of partitions
p = 1;
epsilon = 0.01*ones(p,q) ; % Tolerance
epsilon(:,end) = 0.000; 
DATA.SVD_after_each__ROW = 0; 
DATA.gamma_zero = 1; 
rho =1; 

dr = 0.2 ; % Incremental rank (relative)
RUN_DIR = 0;  RUN_NESTED = 0; RUN_RNESTED=0; RUN_INCREQP =0;RUN_INCRE=1 ; 
RUN_INCRENEW = 0 ; 
% END INPUTS -----------------------------------------------------
DATA.Dmu = [-3,4*pi ; -3,4*pi] ; 

% Generate matr
beta = MakePartition(N,q) ;
alpha = MakePartition(M,p) ;
disp('Approximated si0+ze')
disp([num2str(M*N*8e-6),' Mbytes'])
A = GenerateMatrixBlock(alpha,beta,DATA);

% REPEAT 
% ------
%RECALC = 1; 
%if RECALC == 1
A = cell2mat(A); 


% LEt us determine a basis matrix for colspace(A)
r = 30 ; 
[q1, ~, ~] = SVD(A,0.01) ; 
% Now the corresponding basis matrix for the colspace(q1'*A)
p1 = orth((q1'*A)');
dA1 = A-q1*q1'*A ; 
dA1_2 = A-q1*q1'*A*p1*p1' ;
% Error
nda1 = norm(dA1,'fro')
%%%% NOW we proceed the other way around 
% We compute q1 from p1 as 
q1new = orth(A*p1) ; 
dA1new = A-q1new*q1new'*A*p1*p1' ;
nda1NEW = norm(dA1new,'fro')
