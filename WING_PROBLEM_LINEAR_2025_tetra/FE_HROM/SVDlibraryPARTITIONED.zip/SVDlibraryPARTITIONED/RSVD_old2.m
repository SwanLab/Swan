function  [U,S,V,i] = RSVD(C,Omega,epsilon,dr)
%Omega = randn(N,R) ; % Normally distributed random matrix
theta = 1e-2 ; % Factor to dimish tolerance based on nC
R  = size(Omega,2) ; [M,N] = size(C);
Y  = C*Omega ;
Q  = orth(Y) ;
if size(Q,2) > R-2
    nC = norm(C,'fro') ; % Frobenius norm of C

tol = theta*(max([M,N])*eps(nC))  ;% Machine precision
tol = tol*nC ; 
    % The basis matrix for range(C) is to be incrementally computed
    % b  is set to a percentage of R,
    dR = min(ceil(dr*R),N-R) ;
    dC = C-Q*(Q'*C) ;
    nC = norm(dC,'fro') ;
    i = 0 ;
    while nC>=tol
        i = i + 1 ;
        Omega = randn(N,b) ;
        Qi = orth(dC*Omega);
        Qi = orth(Qi - Q*(Q'*Qi)) ; % Reorthogonalization
        dC = dC - Qi*(Qi'*dC) ;
        Q = [Q Qi] ;
        nC = norm(dC,'fro') ;
        disp(['iter = ',num2str(i),'  nC =',num2str(nC),' R =',num2str(size(Q,2))])
    end    
end
D = Q'*C ;
[U,S,V] = SVD(D,epsilon);
U = Q*U ;