function  [Q] = RORTHaug(C,Omega,epsilon,dR)

%dbstop('4')
if nargin == 0
    load('tmp.mat')
    epsilon = 0.001 ;
end

R  = size(Omega,2) ;  
Y  = C*Omega ;
Q  = orth(Y) ;
i = 0 ;
if size(Q,2) < R
    D = Q'*C ;
    [U,S,V] = SVD(D,epsilon);
    U = Q*U ;
else
    c = norm(C,'fro') ;
   % dbstop('20')
    mu = (max(size(C))*eps(c))  ;% Machine precision
    if epsilon > 0
        e0 = epsilon*c ;
    else
        e0 = mu ;
    end
    [Q,i,nC] = RORTH(C,Q,e0,dR) ;  
    D = Q'*C ;
    [U,S,V] = SVD(D,0); % No truncation
    U = Q*U ;
    % 
    SingVsq =  (S.*S) ;
    SingVsq = sort(SingVsq);  % s_r, s_{r-1} ... s_1
    normEf2 = sqrt(cumsum(SingVsq)) ; % s_r , s_r + s_{r-1} ... s_r +s_{r-1}+ s_{r-2} ... + s_1
    tol2 = (e0^2 - nC^2);
    if tol2<=mu
        R = length(S) ;
    else
        T = (sum(normEf2<sqrt(tol2))) ;
        R = length(S)-T ;
    end
    U = U(:,1:R);
    S = S(1:R) ;
    V = V(:,1:R) ;    
end

