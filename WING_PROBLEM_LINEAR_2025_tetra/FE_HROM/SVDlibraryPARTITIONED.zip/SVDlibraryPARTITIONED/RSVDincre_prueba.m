function [U,S,V] = RSVDincre_prueba(B,beta,epsilon,dr,rho,Rini)
% DATA: Partitioned matrix B = {B1 B2 ... Bq},
% error threshold epsilon (1 x q), rank estimation r
% RESULT: L = [L1 L2 ... Lq], and G = diag(G1,G2 ...Gq), where Li = Di*Hi,
% and Bi = Di*Hi*Di^T + ERROR(epsilon)
if nargin == 0
    load('tmp1.mat')
    epsilon  =0.01*ones(size(B)) ;
    epsilon(1) = 0 ;
end
disp('----------------')
disp('LOOP OVER BLOCKS')
disp('----------------')
q = length(B) ;
L = cell(1,q) ; G = cell(1,q) ;
if ~iscell(B) % Convert B into a cell array of submatrices
    M = size(B,1) ;
    B = mat2cell(B,M,beta) ;
end
R = zeros(1,q) ; Rlft = Rini ;
Nm = 0 ; % Maximum number of columns
for i=1:length(B)
    Nm = max(Nm,size(B{i},2)) ;
end
%Omega = randn(Nm,Nm) ; % Random matrix
Q = [] ;

for i=1:q
    
    disp('------------------------------------------')
    disp(['i = ',num2str(i), '  of ',num2str(q)])
    TTT =tic ;
    
    Ni = size(B{i},2) ;
    %  dbstop('31')
    Rest = ceil(rho*Rlft); dR = ceil(Rest*dr) ;
    if Rest ==0; Rest = ceil(dr*Ni); dR = Rest ;   end
  
    if i==1
        dB = B{i} ;
    else
        dB = B{i} - Q*(Q'*B{i}) ; % Residual
    end
    b = norm(B{i},'fro') ;
    % dbstop('20')
    mu = (max(size(dB))*eps(b))  ;% Machine precision
    if epsilon(i) > 0
        e0 = epsilon(i)*b ;
    else
        e0 = mu ;
    end
    Omega = randn(Ni,Rest) ;
    [dQ,Hi,Gi] = RSVDnew(dB,Omega,e0,dR,mu);
    
    
    
    
    if i>1
        dQ = orth(dQ - Q*(Q'*dQ)) ;
    end
    Q = [Q dQ];
    
    % L{i} = Q'*B{i} ;
    
    Rlft = size(dQ,2) ;
    
    TTT= toc(TTT);
    
    
    disp(['K = ',num2str(length(Hi)),' of ',num2str(Ni),' columns'])
    disp(['Time = ',num2str(TTT)])
end

L = [] ;
for i = 1:length(B)
    L = [L Q'*B{i}];
    
end




[U,S,V] = SVD(L,0); % No truncation
U = Q*U ;

% Writing G in sparse format
% G = diagonal(G{1},G{2},...G{q})
%dbstop('26')

