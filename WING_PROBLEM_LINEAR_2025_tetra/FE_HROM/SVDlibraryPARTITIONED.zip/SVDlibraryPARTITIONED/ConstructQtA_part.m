function [Acond Q] = ConstructQtA_part(A,Q,DATA)


if ~isnumeric(A)
    %
    % Constructing the matriw Qt*A  (taking into account the zeros)
    ISSS = cellfun(@isempty,A) ;
    ISSS = (ISSS==0) ;
    Acond = []  ;
    nrowsQ = zeros(size(Q)) ; 
    for j = 1:size(A,2)
        if any(ISSS(:,j))
            Aloc = [] ;
            INDMZ = find(ISSS(:,j) ==1) ;
            ncolLOC = size(A{INDMZ(1),j},2);
            for i = 1:size(A,1)
                 INDMZ = find(ISSS(i,:) ==1) ;
                 if  ~isempty(INDMZ)
                 nrowLOC = size(A{i,INDMZ(1)},1);
                 else 
                     nrowLOC = 1; 
                 end
                 nrowsQ(i) = nrowLOC ; 
                if isempty(A{i,j})
                    Aloc = [Aloc; zeros(nrowLOC,ncolLOC)] ;
                else
                    Aloc = [Aloc;  A{i,j}] ; 
                end
            end
            Acond = [Acond Aloc] ; 
        end
        
    end
end

% Consistent cell array for the basis matrix Q
for i = 1:length(Q)
    if isempty(Q{i})
        Q{i} = zeros(DATA.alpha(i),nrowsQ(i)) ; 
    end
end
