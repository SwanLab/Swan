function [ ] = xi2xdmf_ParaView_v5( Savepath, case_name, step, type_file, time_set, file_path_xi )
%UNTITLED15 Summary of this function goes here
%   Detailed explanation goes here
%
% INPUTS:
%   filename:
%   type_file: 'txt' | 'xdmf'


%% Initial verifications
if (strcmp('txt',type_file))
    endformat = '\r\n';
elseif (strcmp('xdmf3',type_file) || strcmp('xdmf',type_file) || strcmp('xmf',type_file))
    endformat = '\n';
else
    error('wrong file type');
end

if ~exist('time_set','var')
   time_set = 'all';
% elseif (strcmp(time_set,'last') && ~functions_share_mesh)
%     functions_share_mesh = 1;
end

if ~exist('file_path_xi','var')
   file_path_xi = Savepath;    
end

%% File name

rel_path = relativepath( file_path_xi, Savepath);

temp1 = struct2cell(dir([file_path_xi,filesep,'*',case_name,'_nodal_*.xi']));

if size(temp1,2)>=1
    nodal_grid=1;
else
	nodal_grid=0;
end

file_name_nodal_cell = temp1(1,:)';

temp1 = struct2cell(dir([file_path_xi,filesep,'*',case_name,'_gauss_*.xi']));

if size(temp1,2)>=1
    gauss_grid=1;
else
	gauss_grid=0;
end

file_name_gauss_cell = temp1(1,:)';

switch time_set
    case 'all'
        XDMFname = strcat(Savepath,filesep,case_name,'_1_to_',num2str(step),'.', type_file);
    case 'last'
        if nodal_grid
            file_name_nodal_cell = file_name_nodal_cell(end,1);
        end
        if gauss_grid
            file_name_gauss_cell = file_name_gauss_cell(end,1);
        end
        XDMFname = strcat(Savepath,filesep,case_name,'_',num2str(step),'.', type_file);
end

if nodal_grid
    file_name_nodal_cell = strcat(rel_path,file_name_nodal_cell);
end
if gauss_grid
    file_name_gauss_cell = strcat(rel_path,file_name_gauss_cell);
end

%% Write XDMF file

% Open File
fh = fopen(XDMFname, 'w');
% Print header
fprintf(fh, ['<?xml version="1.0" ?>',endformat]);
fprintf(fh, ['<!DOCTYPE Xdmf SYSTEM "Xdmf.dtd" []>',endformat]);
fprintf(fh, ['<Xdmf Version="3.0" xmlns:xi="http://www.w3.org/2003/XInclude">',endformat]);
% fprintf(fh, ['<Xdmf xmlns:xi="[http://www.w3.org/2003/XInclude]">',endformat]);
% fprintf(fh, ['<Xdmf>',endformat]);
fprintf(fh, ['  <Domain>',endformat]);

if nodal_grid
grid_name = 'Field_data_nodal';
fprintf(fh, ['    <Grid Name="%s" GridType="Collection" CollectionType="Temporal">',endformat],grid_name);
fprintf(fh, ['        <xi:include href="%s"/>',endformat],file_name_nodal_cell{:,1}); % parse="xml"
% fprintf(fh, ['        <xi:include href="%s%s"/>',endformat],rel_path,file_name_nodal_cell{:,1}); % parse="xml"
fprintf(fh, ['    </Grid>',endformat]);
end

if gauss_grid
grid_name = 'Field_data_gauss';
fprintf(fh, ['    <Grid Name="%s" GridType="Collection" CollectionType="Temporal">',endformat],grid_name);
fprintf(fh, ['        <xi:include href="%s"/>',endformat],file_name_gauss_cell{:,1}); % parse="xml"
% fprintf(fh, ['        <xi:include href="%s%s"/>',endformat],rel_path,file_name_gauss_cell{:,1}); % parse="xml"
fprintf(fh, ['    </Grid>',endformat]);
end

fprintf(fh, ['  </Domain>',endformat]);
fprintf(fh, ['</Xdmf>',endformat]);

% Close file
fclose(fh);


end
