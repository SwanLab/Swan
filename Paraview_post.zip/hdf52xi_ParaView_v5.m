function [ ] = hdf52xi_ParaView_v5( Savepath, filename_save, step, file_name_mesh, file_name_fields , type_file, typeMesh, functions_share_mesh )
%UNTITLED15 Summary of this function goes here
%   Detailed explanation goes here
%
% INPUTS:
%   filename:
%   type_file: 'txt' | 'xdmf'
%   typeMesh: a type of linear or quadratic element, or 'Mixed' (then add the corresponding number to each cell in the connectivity table ) 
%             Linear
%               Polyvertex - a group of unconnected points 
%               Polyline - a group of line segments (Complicated)
%               Polygon (Complicated)
%               Triangle
%               Quadrilateral
%               Tetrahedron
%               Pyramid
%               Wedge
%               Hexahedron
%             Quadratic
%               Edge_3 - Quadratic line with 3 nodes
%               Tri_6
%               Quad_8
%               Tet_10
%               Pyramid_13
%               Wedge_15
%               Hex_20
%             Mixed
%               1 - POLYVERTEX
%               2 - POLYLINE (Complicated)
%               3 - POLYGON (Complicated)
%               4 - TRIANGLE
%               5 - QUADRILATERAL
%               6 - TETRAHEDRON
%               7 - PYRAMID
%               8 - WEDGE
%               9 - HEXAHEDRON
%               16 - POLYHEDRON (Complicated)
%               34 - EDGE_3
%               35 - QUADRILATERAL_9
%               36 - TRIANGLE_6
%               37 - QUADRILATERAL_8
%               38 - TETRAHEDRON_10
%               39 - PYRAMID_13
%               40 - WEDGE_15
%               41 - WEDGE_18
%               48 - HEXAHEDRON_20
%               49 - HEXAHEDRON_24
%               50 - HEXAHEDRON_27

%% Initial verifications
if (strcmp('txt',type_file))
    endformat = '\r\n';
elseif (strcmp('xi',type_file))
    endformat = '\n';
else
    error('wrong file type');
end

% if nargin == 3
%     functions_share_mesh = false;
% end

if length(typeMesh)==1
   typeMesh = {typeMesh,typeMesh};    
end





% if isempty(file_name_mesh)
%    mesh_file = 0;
% else
%    mesh_file = 1;
% end
% 
% if isempty(file_name_fields)
%    gauss_file = 0;
% else
%    gauss_file = 1;
% end

% if ~exist('time_set','var')
%    time_set = 'all';
% % elseif (strcmp(time_set,'last') && ~functions_share_mesh)
% %     functions_share_mesh = 1;
% end

%% File name

XIname_nodal = strcat(Savepath,filesep,filename_save,'_nodal_',num2str(step),'.', type_file);
XIname_gauss = strcat(Savepath,filesep,filename_save,'_gauss_',num2str(step),'.', type_file);

printZeroTime = 1;

name_mesh = strsplit(file_name_mesh,filesep); name_mesh = name_mesh{end};
name_field = strsplit(file_name_fields,filesep); name_field = name_field{end};

rel_file_name_mesh = [relativepath( fileparts(file_name_mesh), fileparts(XIname_nodal)),name_mesh];
rel_file_name_fields = [relativepath( fileparts(file_name_fields), fileparts(XIname_nodal)),name_field];

%% Load and process mesh metadata
% Load mesh metadata

try
    Info = h5info(file_name_mesh, '/MESH_nodal');
    [mesh_nodal] = detect_data_Mesh (functions_share_mesh,Info,'nodal');
    nodal_file = 1;
catch
    nodal_file = 0;
end

try 
    Info = h5info(file_name_mesh, '/MESH_gauss');
    [mesh_gauss] = detect_data_Mesh (functions_share_mesh,Info,'gauss');  
    gauss_file = 1;
catch
    gauss_file = 0;
end
                
% Info = h5info(filename, '/MESH_gauss');
% 
% [nTimes_Mesh,nProcs,nPoints,nDim,nCells,cellLength,procNo,CellPrecision,CellNumberType,PointsPrecision,PointsNumberType,meshNames] = ...
%                     detect_data_Mesh (functions_share_mesh,Info,'gauss');
%% Load and process field metadata
% Load mesh metadata

if nodal_file
    Info = h5info(file_name_fields, '/FIELDS_nodal');
    [fields_nodal] = detect_data_Fields (Info,'nodal',mesh_nodal.nProcs);
end

if gauss_file
    Info = h5info(file_name_fields, '/FIELDS_gauss');
    [fields_gauss] = detect_data_Fields (Info,'gauss',mesh_gauss.nProcs);
end

%% Write XDMF file

% Sort time values
try
    [T, idx] = sort(fields_nodal.timeVals);
catch
    [T, idx] = sort(fields_gauss.timeVals);
end

if nodal_file
% Open File
fh = fopen(XIname_nodal, 'w');

% print_grid_xdmf (file_name_mesh,file_name_fields,'Field_data_nodal',mesh_nodal,fields_nodal,fh,functions_share_mesh,printZeroTime,typeMesh{1},T,idx,endformat,'nodal');

print_grid_xdmf (rel_file_name_mesh,rel_file_name_fields,'Field_data_nodal',mesh_nodal,fields_nodal,fh,functions_share_mesh,printZeroTime,typeMesh{1},T,idx,endformat,'nodal');

% Close file
fclose(fh);
end

if gauss_file
% Open File
fh = fopen(XIname_gauss, 'w');

% print_grid_xdmf (file_name_mesh,file_name_fields,'Field_data_gauss',mesh_gauss,fields_gauss,fh,functions_share_mesh,printZeroTime,typeMesh{2},T,idx,endformat,'gauss');

print_grid_xdmf (rel_file_name_mesh,rel_file_name_fields,'Field_data_gauss',mesh_gauss,fields_gauss,fh,functions_share_mesh,printZeroTime,typeMesh{2},T,idx,endformat,'gauss');

% Close file
fclose(fh);
end

% % % % Print header
% % % fprintf(fh, ['<?xml version="1.0" ?>',endformat]);
% % % fprintf(fh, ['<!DOCTYPE Xdmf SYSTEM "Xdmf.dtd" []>',endformat]);
% % % fprintf(fh, ['<Xdmf Version="2.0" xmlns:xi="[http://www.w3.org/2001/XInclude]">',endformat]);
% % % % fprintf(fh, ['<Xdmf xmlns:xi="[http://www.w3.org/2003/XInclude]">',endformat]);
% % % % fprintf(fh, ['<Xdmf>',endformat]);
% % % fprintf(fh, ['  <Domain>',endformat]);
% % % 
% % % grid_name = 'Field_data_nodal';
% % % fprintf(fh, ['    <Grid Name="%s" GridType="Collection" CollectionType="Temporal">',endformat,endformat],grid_name);
% % % 
% % % if mesh_file
% % %     print_grid_xdmf (file_name_mesh,'Field_data_nodal',mesh_nodal,fields_nodal,fh,functions_share_mesh,printZeroTime,typeMesh{1},T,idx,endformat,'nodal',time_set)
% % % end
% % % fprintf(fh, ['    </Grid>',endformat]);
% % % 
% % % grid_name = 'Field_data_gauss';
% % % fprintf(fh, ['    <Grid Name="%s" GridType="Collection" CollectionType="Temporal">',endformat,endformat],grid_name);
% % % if gauss_file
% % %     print_grid_xdmf (file_name_fields,'Field_data_gauss',mesh_gauss,fields_gauss,fh,functions_share_mesh,printZeroTime,typeMesh{2},T,idx,endformat,'gauss',time_set)
% % % end
% % % fprintf(fh, ['    </Grid>',endformat]);
% % % 
% % % fprintf(fh, ['  </Domain>',endformat]);
% % % fprintf(fh, ['</Xdmf>',endformat]);
% % % 
% % % % Close file
% % % fclose(fh);


end


function [struct_mesh] = ... %nTimes_Mesh,nProcs,nPoints,nDim,nCells,cellLength,procNo,CellPrecision,CellNumberType,PointsPrecision,PointsNumberType,meshNames
                    detect_data_Mesh (functions_share_mesh,Info,type_info)


if functions_share_mesh == 1
    struct_mesh.nTimes_Mesh = 1;
else
    struct_mesh.nTimes_Mesh = size(Info.Groups, 1);
end

% Find number of processes in file
struct_mesh.nProcs = size(Info.Groups(1,1).Groups, 1);

% Find number of points, cells and dataset length for each process
struct_mesh.nPoints = zeros( struct_mesh.nTimes_Mesh, struct_mesh.nProcs, 1);
struct_mesh.nDim = zeros(struct_mesh.nTimes_Mesh, struct_mesh.nProcs, 1);
struct_mesh.nCells = zeros(struct_mesh.nTimes_Mesh, struct_mesh.nProcs, 1);
struct_mesh.cellLength = zeros(struct_mesh.nTimes_Mesh, struct_mesh.nProcs, 2);
struct_mesh.procNo = zeros(struct_mesh.nTimes_Mesh, struct_mesh.nProcs, 1);

for i_times_Mesh = 1:struct_mesh.nTimes_Mesh
    for i_proc=1:struct_mesh.nProcs
        struct_mesh.cellLength(i_times_Mesh,i_proc,:) = Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(1,1).Dataspace.Size;
        struct_mesh.nPoints(i_times_Mesh,i_proc,1) = Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(2,1).Dataspace.Size(2);
        struct_mesh.nDim(i_times_Mesh,i_proc,1) = Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(2,1).Dataspace.Size(1);
        struct_mesh.nCells(i_times_Mesh,i_proc,1) = str2double(Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(1,1).Attributes.Value{1});
        
        %   cellLength(i) = 2000*8;%Info.Groups(1,1).Groups(i,1).Datasets(1,1).Dataspace.Size;
        %   nPoints(i) = 2541;%Info.Groups(1,1).Groups(i,1).Datasets(2,1).Dataspace.Size(1);
        %   nDim(i) = 3;%Info.Groups(1,1).Groups(i,1).Datasets(2,1).Dataspace.Size(2);
        %   nCells(i) = 2000;%str2double(Info.Groups(1,1).Groups(i,1).Datasets(1,1).Attributes.Value{1});
        
        struct_mesh.CellPrecision{i_times_Mesh,i_proc} = deblank(Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(1,1).Attributes.Value{4}); % 1 | 2 (Int or UInt only) | 4 | 8
        struct_mesh.CellNumberType{i_times_Mesh,i_proc} = deblank(Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(1,1).Attributes.Value{3}); % Float | Int | UInt | Char | UChar
        
        struct_mesh.PointsPrecision{i_times_Mesh,i_proc} = deblank(Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(2,1).Attributes.Value{4}); % 1 | 2 (Int or UInt only) | 4 | 8
        struct_mesh.PointsNumberType{i_times_Mesh,i_proc} = deblank(Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Datasets(2,1).Attributes.Value{3}); % Float | Int | UInt | Char | UChar
        
        struct_mesh.meshNames{i_times_Mesh,i_proc} =  Info.Groups(i_times_Mesh,1).Groups(i_proc,1).Name;
        struct_mesh.procNo(i_times_Mesh,i_proc,1) = sscanf(struct_mesh.meshNames{i_times_Mesh,i_proc}, ['/MESH_',type_info,'/%*f/processor%i']);
    end   
end

end

function [struct_fields] = detect_data_Fields (Info,type_info,nProcs) 
%nTimes,timeNames,timeVals,nFields,fieldNames,fieldPrecision,fieldNumberType,fieldType,fieldCenter,fieldCmps,fieldSize,...
%     nFunctions,functionGroupNames,nfields_function,functionNames,functionPrecision,functionNumberType,functionCmps,functionSize...
%     ,functionType,functionCenter,functionElementFamily,functionElementDegree,functionElementCell

% Find times
struct_fields.nTimes = size(Info.Groups, 1);
for i_time=1:struct_fields.nTimes
  struct_fields.timeNames{i_time} = Info.Groups(i_time,1).Name;
  struct_fields.timeVals(i_time) = sscanf(struct_fields.timeNames{i_time}, ['/FIELDS_',type_info,'/%f']);
  
  for i_proc = 1:nProcs
      % Find number of fields (in total) 
      struct_fields.nFields(i_time,i_proc) =  size(Info.Groups(i_time,1).Groups(i_proc,1).Datasets, 1);

      % Classify and name vector- and scalarfields
      % fieldCmps = zeros(nFields, 1);
      for i_field=1:struct_fields.nFields(i_time,i_proc)
          struct_fields.fieldNames{i_time,i_proc,i_field} = Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Name;
          struct_fields.fieldPrecision{i_time,i_proc,i_field} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Attributes.Value{6}); % 1 | 2 (Int or UInt only) | 4 | 8
          struct_fields.fieldNumberType{i_time,i_proc,i_field} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Attributes.Value{5}); % Float | Int | UInt | Char | UChar
          struct_fields.fieldType{i_time,i_proc,i_field} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Attributes.Value{4}); % Scalar | Vector | Tensor | Tensor6 | Matrix
          struct_fields.fieldCenter{i_time,i_proc,i_field} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Attributes.Value{3}); % Node | Edge | Face | Cell | Grid | Other
          struct_fields.fieldCmps(i_time,i_proc,i_field) = str2double(Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Attributes.Value{2}); % #columns
          struct_fields.fieldSize(i_time,i_proc,i_field) = str2double(Info.Groups(i_time,1).Groups(i_proc,1).Datasets(i_field,1).Attributes.Value{1}); % #rows
      end

      % Find number of functions
      struct_fields.nFunctions(i_time,i_proc) =  size(Info.Groups(i_time,1).Groups(i_proc,1).Groups, 1);

      % Classify and name vector- and scalarfields
      for i_function=1:struct_fields.nFunctions(i_time,i_proc)

          temp = strsplit(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Name,'/','CollapseDelimiters',true);
          struct_fields.functionGroupNames{i_time,i_proc,i_function} = temp{end};

          struct_fields.nfields_function{i_time,i_proc,i_function} = size(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets, 1);

          for j_dataitems = 1:struct_fields.nfields_function{i_time,i_proc,i_function}
              struct_fields.functionNames{i_time,i_proc,i_function,j_dataitems} = Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(j_dataitems,1).Name;
              struct_fields.functionPrecision{i_time,i_proc,i_function,j_dataitems} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(j_dataitems,1).Attributes.Value{6}); % 1 | 2 (Int or UInt only) | 4 | 8 %dofmap
              struct_fields.functionNumberType{i_time,i_proc,i_function,j_dataitems} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(j_dataitems,1).Attributes.Value{5}); % Float | Int | UInt | Char | UChar %dofmap

              struct_fields.functionCmps(i_time,i_proc,i_function,j_dataitems) = str2double(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(j_dataitems,1).Attributes.Value{2}); % #columns %dofmap
              struct_fields.functionSize(i_time,i_proc,i_function,j_dataitems) = str2double(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(j_dataitems,1).Attributes.Value{1}); % #rows %dofmap
          end

          struct_fields.functionType{i_time,i_proc,i_function} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(1,1).Attributes.Value{4}); % Scalar | Vector | Tensor | Tensor6 | Matrix
          struct_fields.functionCenter{i_time,i_proc,i_function} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(1,1).Attributes.Value{3}); % Node | Edge | Face | Cell | Grid | Other

          struct_fields.functionElementFamily{i_time,i_proc,i_function} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(1,1).Attributes.Value{8});
          struct_fields.functionElementDegree{i_time,i_proc,i_function} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(1,1).Attributes.Value{9});
          struct_fields.functionElementCell{i_time,i_proc,i_function} = deblank(Info.Groups(i_time,1).Groups(i_proc,1).Groups(i_function,1).Datasets(1,1).Attributes.Value{10});

      end
  end

end

end

function [] = print_grid_xdmf (filename_mesh,filename_fields,grid_name,mesh_struct,field_struct,fh,functions_share_mesh,printZeroTime,typeMesh,T,idx,endformat,center_point)

% switch time_set
%     case 'all'
        nTime_set = field_struct.nTimes;
        idx_set = idx;
%     case 'last'
%         nTime_set = 1;
%         idx_set = idx(end);
% end


% fprintf(fh, ['    <Grid Name="%s" GridType="Collection" CollectionType="Temporal">',endformat,endformat],grid_name);

% Time loop
for t=1:nTime_set
  i_time = idx_set(t);
  
  if (functions_share_mesh)
        i_mesh = 1;
  else
        i_mesh = i_time;
  end
  
  if (field_struct.timeVals(i_time) == 0 && printZeroTime == 0)
    continue;
  end
  
  fprintf(fh, ['      <Grid GridType="Collection" CollectionType="Spatial">',endformat]);
  fprintf(fh, ['        <Time Type="Single" Value="%f" />',endformat], field_struct.timeVals(i_time));
  
  % Process loop
  for i_proc=1:mesh_struct.nProcs
    fprintf(fh, ['        <Grid Name="time%f-processor%i-center%s" Type="Uniform">',endformat],field_struct.timeVals(i_time), i_proc-1,center_point);
    
    if (functions_share_mesh && i_time>1 )%&& strcmp(time_set,'all'))
%         fprintf(fh, ['          <Topology Reference="//Grid[@Name="time%f-processor%i"]/Topology[1]"/>',endformat], timeVals(1), j-1); %@Name="time%f-processor%i"  "/Xdmf/Domain[1]/Grid[1]/Grid[1]/Time[1]/Grid[1]/Topology[1]"
%         fprintf(fh, ['          <Geometry Reference="//Grid[@Name="time%f-processor%i"]/Geometry[1]"/>',endformat], timeVals(1), j-1);
        
        fprintf(fh, ['          <Topology Reference="XML"> //Grid[@Name="time%f-processor%i-center%s"]/Topology[1] </Topology>',endformat], field_struct.timeVals(1), i_proc-1,center_point); %@Name="time%f-processor%i"  "/Xdmf/Domain[1]/Grid[1]/Grid[1]/Time[1]/Grid[1]/Topology[1]"
        fprintf(fh, ['          <Geometry Reference="XML"> //Grid[@Name="time%f-processor%i-center%s"]/Geometry[1] </Geometry>',endformat], field_struct.timeVals(1), i_proc-1,center_point);
    else
        % Geometry definition
        fprintf(fh, ['          <Topology Type="%s" NumberOfElements="%i">',endformat], typeMesh, mesh_struct.nCells(i_mesh,i_proc,1));
        if strcmp('Mixed',typeMesh)
            fprintf(fh, ['            <DataItem Dimensions="%i" NumberType="%s" Presicion="%s" Format="HDF">',endformat], mesh_struct.cellLength(i_mesh,i_proc,1), mesh_struct.CellNumberType{i_mesh,i_proc},mesh_struct.CellPrecision{i_mesh,i_proc});
        else
            fprintf(fh, ['            <DataItem Dimensions="%i %i" NumberType="%s" Presicion="%s" Format="HDF">',endformat], mesh_struct.cellLength(i_mesh,i_proc,2),mesh_struct.cellLength(i_mesh,i_proc,1), mesh_struct.CellNumberType{i_mesh,i_proc},mesh_struct.CellPrecision{i_mesh,i_proc});
        end
        fprintf(fh, ['              %s:%s/CELLS',endformat], filename_mesh, mesh_struct.meshNames{i_mesh,i_proc});
        fprintf(fh, ['            </DataItem>',endformat]);
        fprintf(fh, ['          </Topology>',endformat]);
        if (mesh_struct.nDim(i_mesh,i_proc,1)==3); coord = 'XYZ'; else; coord='XY'; end;
        fprintf(fh, ['          <Geometry GeometryType="%s">',endformat],coord);
        fprintf(fh, ['            <DataItem Dimensions="%i %i" NumberType="%s" Presicion="%s" Format="HDF">',endformat], mesh_struct.nPoints(i_mesh,i_proc,1), mesh_struct.nDim(i_mesh,i_proc,1), mesh_struct.PointsNumberType{i_mesh,i_proc},mesh_struct.PointsPrecision{i_mesh,i_proc});
        fprintf(fh, ['              %s:%s/POINTS',endformat], filename_mesh, mesh_struct.meshNames{i_mesh,i_proc});
        fprintf(fh, ['            </DataItem>',endformat]);
        fprintf(fh, ['          </Geometry>',endformat]);
    end
    
    % Field loop
    for i_field=1:field_struct.nFields(i_time,i_proc)
      fprintf(fh, ['          <Attribute Name="%s" Center="%s" AttributeType="%s">',endformat], field_struct.fieldNames{i_time,i_proc,i_field},field_struct.fieldCenter{i_time,i_proc,i_field},field_struct.fieldType{i_time,i_proc,i_field});
      if (field_struct.fieldCmps(i_time,i_proc,i_field) == 1)
          fprintf(fh, ['            <DataItem Format="HDF" NumberType="%s" Precision="%s" Dimensions="%i">',endformat], field_struct.fieldNumberType{i_time,i_proc,i_field}, field_struct.fieldPrecision{i_time,i_proc,i_field}, field_struct.fieldSize(i_time,i_proc,i_field));
      else %fieldCmps(k) ~= 1
          fprintf(fh, ['            <DataItem Format="HDF" NumberType="%s" Precision="%s" Dimensions="%i %i">',endformat], field_struct.fieldNumberType{i_time,i_proc,i_field}, field_struct.fieldPrecision{i_time,i_proc,i_field}, field_struct.fieldSize(i_time,i_proc,i_field),field_struct.fieldCmps(i_time,i_proc,i_field));
      end
      fprintf(fh, ['              %s:%s/processor%i/%s',endformat], filename_fields, field_struct.timeNames{i_time}, mesh_struct.procNo(i_mesh,i_proc,1), field_struct.fieldNames{i_time,i_proc,i_field});
      fprintf(fh, ['            </DataItem>',endformat]);
      fprintf(fh, ['          </Attribute>',endformat]);
    end
    
    for i_function=1:field_struct.nFunctions(i_time,i_proc)
        fprintf(fh, ['          <Attribute ItemType="FiniteElementFunction" ElementFamily="%s" ElementDegree="%s" ElementCell="%s" Name="%s" Center="%s" AttributeType="%s">',endformat], field_struct.functionElementFamily{i_time,i_proc,i_function},field_struct.functionElementDegree{i_time,i_proc,i_function},field_struct.functionElementCell{i_time,i_proc,i_function},field_struct.functionGroupNames{i_time,i_proc,i_function},field_struct.functionCenter{i_time,i_proc,i_function},field_struct.functionType{i_time,i_proc,i_function});
        fprintf(fh, ['            <DataItem Format="HDF" NumberType="%s" Precision="%s" Dimensions="%i %i">',endformat], field_struct.functionNumberType{i_time,i_proc,i_function,1}, field_struct.functionPrecision{i_time,i_proc,i_function,1}, field_struct.functionSize(i_time,i_proc,i_function,1),field_struct.functionCmps(i_time,i_proc,i_function,1)); %Name="Index" 
        fprintf(fh, ['              %s:%s/processor%i/%s/%s',endformat], filename_fields, field_struct.timeNames{i_time}, procNo(i_mesh,i_proc,1), field_struct.functionGroupNames{i_time,i_proc,i_function},field_struct.functionNames{i_time,i_proc,i_function,1});
        fprintf(fh, ['            </DataItem>',endformat]);
        
        vec_temp = [1,2,4,3];
        for ml=2:field_struct.nfields_function{i_time,i_proc,i_function}
            m = vec_temp(ml);
            if (field_struct.functionCmps(i_time,i_proc,i_function,2) == 1)
                fprintf(fh, ['            <DataItem Format="HDF" DataType="%s" Precision="%s" Dimensions="%i">',endformat], field_struct.functionNumberType{i_time,i_proc,i_function,m}, field_struct.functionPrecision{i_time,i_proc,i_function,m}, field_struct.functionSize(i_time,i_proc,i_function,m)); %Name="Value" 
            else %fieldCmps(k) ~= 1
                fprintf(fh, ['            <DataItem Format="HDF" NumberType="%s" Precision="%s" Dimensions="%i %i">',endformat], field_struct.functionNumberType{i_time,i_proc,i_function,m}, field_struct.functionPrecision{i_time,i_proc,i_function,m}, field_struct.functionSize(i_time,i_proc,i_function,m),field_struct.functionCmps(i_time,i_proc,i_function,m)); %Name="Value" 
            end
          fprintf(fh, ['              %s:%s/processor%i/%s/%s',endformat], filename_fields, field_struct.timeNames{i_time}, mesh_struct.procNo(i_mesh,i_proc,1), field_struct.functionGroupNames{i_time,i_proc,i_function},field_struct.functionNames{i_time,i_proc,i_function,m});
            fprintf(fh, ['            </DataItem>',endformat]);
        end
      fprintf(fh, ['          </Attribute>',endformat]);
    end
    fprintf(fh, ['        </Grid>',endformat,endformat]);
  end
  fprintf(fh, ['      </Grid>',endformat,endformat,endformat]);
end

% Print footer
% fprintf(fh, ['    </Grid>',endformat]);

end