clc
clear
close all

%% Parameters

%Create folders to store the data
files_in_folders = 0;
%Define a common mesh
function_share_mesh = 1;
%Create txt files of xi, xdmf files for easy reading
txt_creation = 1;


%% Define triangular mesh

elem_type = 'Quadrilateral';
nx = 4;
ny = 4;
coordinates = [repmat((0:nx-1)',ny,1),reshape(repmat(0:ny-1,nx,1),[],1)];

connectivities = reshape(1:(nx*ny),nx,ny);
P = 2; Q = 2;
connectivities = im2col(connectivities,[P Q],'sliding')';
connectivities = connectivities(:,[1,2,4,3]);

nelem = size(connectivities,1);
nnodes = nx*ny;

nnode = 4;
ngaus = 1;

%% Plot triangular mesh

figure(1)
patch('Vertices',coordinates,'Faces',connectivities,'EdgeColor','black','FaceColor','none')
xlabel('x')
ylabel('y')
title('Mesh')

%% Create fields nodal

Elem_scl = (1:nelem)'; 
Node_scl = 2*(1:nnodes)'; 

Elem_vect = [2*rand(nelem,2),zeros(nelem,1)]; 
Node_vect = [3*rand(nnodes,2),zeros(nnodes,1)];

Elem_Tensor6 = 5*rand(nelem,6);
Node_Tensor6 = 4*rand(nnodes,6);

Elem_Tensor9 = 5*rand(nelem,9);
Node_Tensor9 = 4*rand(nnodes,9);

%% Create fields gauss and gaussian-lobato mesh

nnodes_gauss = nnode*nelem;

connectivities_gauss = bsxfun(@plus,nnode*((1:nelem)'-1),1:nnode);
coordinates_gauss = coordinates(reshape(connectivities',[],1),:);

ncomp = 1;
Gauss_scl = bsxfun(@times,bsxfun(@plus,(1:ngaus)',1:nelem),permute(1:ncomp,[1,3,2]));
[ ~, Gauss_scl_nod ] = Gauss2nodes( Gauss_scl,elem_type,nnode,ngaus );
Gauss_scl_nod = reshape(Gauss_scl_nod,[],1);

ncomp = 2;
Gauss_vect = bsxfun(@times,bsxfun(@plus,(1:ngaus)',1:nelem),permute(1:ncomp,[1,3,2]));
[ ~, Gauss_vect_nod ] = Gauss2nodes( Gauss_vect,elem_type,nnode,ngaus );
Gauss_vect_nod = [reshape(Gauss_vect_nod,[],ncomp),zeros(nnodes_gauss,1)];

ncomp = 6;
Gauss_Tensor6 = bsxfun(@times,bsxfun(@plus,(1:ngaus)',1:nelem),permute(1:ncomp,[1,3,2]));
[ ~, Gauss_Tensor6_nod ] = Gauss2nodes( Gauss_Tensor6,elem_type,nnode,ngaus );
Gauss_Tensor6_nod = reshape(Gauss_Tensor6_nod,[],ncomp);

ncomp = 9;
Gauss_Tensor = bsxfun(@times,bsxfun(@plus,(1:ngaus)',1:nelem),permute(1:ncomp,[1,3,2]));
[ ~, Gauss_Tensor_nod ] = Gauss2nodes( Gauss_Tensor,elem_type,nnode,ngaus );
Gauss_Tensor_nod = reshape(Gauss_Tensor_nod,[],ncomp);

%% Define save path


[file_save_path,case_name,ext] = fileparts(which('Quadrilateral_4nodes_1gpoint'));

if exist([file_save_path,filesep,case_name],'dir')
    rmdir([file_save_path,filesep,case_name],'s');
end
mkdir([file_save_path,filesep,case_name])
file_save_path = [file_save_path,filesep,case_name];


switch files_in_folders
    case 1
        mkdir([file_save_path,filesep,'hdf5_files'])
        mkdir([file_save_path,filesep,'xi_files'])
        mkdir([file_save_path,filesep,'xdmf_files_iter'])
        mkdir([file_save_path,filesep,'xdmf_files_range'])
        
        filename_mesh = 'hdf5_files\\%s_mesh_%i.h5';
        filename_fields = 'hdf5_files\\%s_fields_%i.h5';
        
        file_save_path_xi = [file_save_path,filesep,'xi_files'];
        file_save_path_xdmf_iter = [file_save_path,filesep,'xdmf_files_iter'];
        file_save_path_xdmf_range = [file_save_path,filesep,'xdmf_files_range'];
        
    case 0
        filename_mesh = '%s_mesh_%i.h5';
        filename_fields = '%s_fields_%i.h5';
        
        file_save_path_xi = file_save_path;
        file_save_path_xdmf_iter = file_save_path;
        file_save_path_xdmf_range = file_save_path;
end

%% Save data to hdf5 nodal/cell time1

time_num = 1;
proc_num = 1;

hdf5_write_coordinates( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_nodal/%f/processor%i',time_num,proc_num), 'POINTS', coordinates', 'Float', '8', 'overwrite' )
hdf5_write_connectivities( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_nodal/%f/processor%i',time_num,proc_num), 'CELLS', int64(connectivities'-1), 'Int', '8', 'append' ) 
 
hdf5_write_nodal_sclfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_Scl', Node_scl, 'Float', '8', 'overwrite' )
hdf5_write_nodal_vfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_vect', Node_vect', 'Float', '8', 'append' )
hdf5_write_nodal_Tensor6field( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_Tensor6', Node_Tensor6', 'Float', '8', 'append' )
hdf5_write_nodal_Tensorfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_Tensor9', Node_Tensor9', 'Float', '8', 'append' )

hdf5_write_cell_sclfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_Scl', Elem_scl, 'Float', '8', 'append' )
hdf5_write_cell_vfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_vect', Elem_vect', 'Float', '8', 'append' )
hdf5_write_cell_Tensor6field( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_Tensor6', Elem_Tensor6', 'Float', '8', 'append' )
hdf5_write_cell_Tensorfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_Tensor9', Elem_Tensor9', 'Float', '8', 'append' )

%% Save data to hdf5 nodal/cell time2

time_num = 2;
proc_num = 1;

%Mesh files not required if function_share_mesh==1
hdf5_write_coordinates( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_nodal/%f/processor%i',time_num,proc_num), 'POINTS', coordinates', 'Float', '8', 'overwrite' )
hdf5_write_connectivities( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_nodal/%f/processor%i',time_num,proc_num), 'CELLS', int64(connectivities'-1), 'Int', '8', 'append' ) 
  
hdf5_write_nodal_sclfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_Scl', 2*Node_scl, 'Float', '8', 'overwrite' )
hdf5_write_nodal_vfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_vect', 2*Node_vect', 'Float', '8', 'append' )
hdf5_write_nodal_Tensor6field( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_Tensor6', 2*Node_Tensor6', 'Float', '8', 'append' )
hdf5_write_nodal_Tensorfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Node_Tensor9', 2*Node_Tensor9', 'Float', '8', 'append' )

hdf5_write_cell_sclfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_Scl', 2*Elem_scl, 'Float', '8', 'append' )
hdf5_write_cell_vfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_vect', 2*Elem_vect', 'Float', '8', 'append' )
hdf5_write_cell_Tensor6field( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_Tensor6', 2*Elem_Tensor6', 'Float', '8', 'append' )
hdf5_write_cell_Tensorfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_nodal/%f/processor%i',time_num,proc_num), 'Elem_Tensor9', 2*Elem_Tensor9', 'Float', '8', 'append' )

%% Save data to hdf5 gauss time1

time_num = 1;
proc_num = 1;

hdf5_write_coordinates( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_gauss/%f/processor%i',time_num,proc_num), 'POINTS', coordinates_gauss', 'Float', '8', 'append' )
hdf5_write_connectivities( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_gauss/%f/processor%i',time_num,proc_num), 'CELLS', int64(connectivities_gauss'-1), 'Int', '8', 'append') 

hdf5_write_nodal_sclfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_Scl', Gauss_scl_nod, 'Float', '8', 'append' )
hdf5_write_nodal_vfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_vect', Gauss_vect_nod', 'Float', '8', 'append' )
hdf5_write_nodal_Tensor6field( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_Tensor6', Gauss_Tensor6_nod', 'Float', '8', 'append' )
hdf5_write_nodal_Tensorfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_Tensor9', Gauss_Tensor_nod', 'Float', '8', 'append' )

%% Save data to hdf5 gauss time2
time_num = 2;
proc_num = 1;

%Mesh files not required if function_share_mesh==1
hdf5_write_coordinates( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_gauss/%f/processor%i',time_num,proc_num), 'POINTS', coordinates_gauss', 'Float', '8', 'append' )
hdf5_write_connectivities( [file_save_path,filesep,sprintf(filename_mesh,case_name,time_num)], sprintf('/MESH_gauss/%f/processor%i',time_num,proc_num), 'CELLS', int64(connectivities_gauss'-1), 'Int', '8', 'append') 

hdf5_write_nodal_sclfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_Scl', 2*Gauss_scl_nod, 'Float', '8', 'append' )
hdf5_write_nodal_vfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_vect', 2*Gauss_vect_nod', 'Float', '8', 'append' )
hdf5_write_nodal_Tensor6field( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_Tensor6', 2*Gauss_Tensor6_nod', 'Float', '8', 'append' )
hdf5_write_nodal_Tensorfield( [file_save_path,filesep,sprintf(filename_fields,case_name,time_num)], sprintf('/FIELDS_gauss/%f/processor%i',time_num,proc_num), 'Gauss_Tensor9', 2*Gauss_Tensor_nod', 'Float', '8', 'append' )

%% Create xdmf files

nstep = 2;
for i_step=1:nstep
    
    switch function_share_mesh
        case 0
            file_mesh = [file_save_path,filesep,sprintf(filename_mesh,case_name,i_step)];
        case 1
            file_mesh = [file_save_path,filesep,sprintf(filename_mesh,case_name,1)];
    end
    file_fields = [file_save_path,filesep,sprintf(filename_fields,case_name,i_step)];
    
    if txt_creation 
        hdf52xi_ParaView_v5( file_save_path_xi, case_name, i_step, file_mesh, file_fields, 'txt' , {elem_type,elem_type}, 0)
    end
    hdf52xi_ParaView_v5( file_save_path_xi, case_name, i_step, file_mesh, file_fields, 'xi'  , {elem_type,elem_type}, 0)
    
    if txt_creation 
        xi2xdmf_ParaView_v5( file_save_path_xdmf_iter, case_name, i_step, 'txt', 'last', file_save_path_xi)
    end
    xi2xdmf_ParaView_v5( file_save_path_xdmf_iter, case_name, i_step, 'xdmf', 'last',  file_save_path_xi)
    
    if txt_creation 
        xi2xdmf_ParaView_v5( file_save_path_xdmf_range, case_name, i_step, 'txt', 'all', file_save_path_xi )
    end
    xi2xdmf_ParaView_v5( file_save_path_xdmf_range, case_name, i_step, 'xdmf', 'all', file_save_path_xi )
end
