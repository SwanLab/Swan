function [] = hdf5_write_cell_vfield( filename, Dataset_location, Dataset_name, Dataset_variable, Dataset_type, Dataset_precision, hdf5mode )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%
%INPUTS: 
%   filename:
%   Dataset_location:
%   Dataset_name:
%   Dataset_variable: [3,#cells] (V_X V_Y V_Z)
%   Dataset_type: Float | Int | UInt | Char | UChar
%   Dataset_precision: 1 | 2 (Int or UInt only) |4 | 8 (bytes)
%	hdf5mode: 'overwrite' or 'append'

dset = Dataset_variable;
dset_details.Location = Dataset_location;
dset_details.Name = Dataset_name;

attr = {num2str(size(dset,2)),num2str(size(dset,1)),'Cell','Vector',Dataset_type,Dataset_precision};
attr_details.Name = 'Matlabdata';
attr_details.AttachedTo = [Dataset_location,'/',Dataset_name];
attr_details.AttachType = 'dataset';
hdf5write(filename, dset_details, dset, attr_details, attr, 'Writemode',hdf5mode);

end