function [] = hdf5_write_other_sclfield( filename, Dataset_location, Dataset_name, Dataset_variable, Dataset_type, Dataset_precision,...
                                                                                ElementFamily, ElementDegree, ElementCell, hdf5mode )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%
%INPUTS: 
%   filename:
%   Dataset_location:
%   Dataset_name:
%   Dataset_variable:
%   Dataset_type: Float | Int | UInt | Char | UChar
%   Dataset_precision: 1 | 2 (Int or UInt only) |4 | 8 (bytes)
%	hdf5mode: 'overwrite' or 'append'


% dset = reshape(Dataset_variable{1},[],1);
dset = Dataset_variable{1};
dset_details.Location = [Dataset_location,'/',Dataset_name];
dset_details.Name = [Dataset_name,'_Dofmap'];

% attr = {num2str(size(dset,1)),num2str(size(dset,2)),'Other','Scalar',Dataset_type{1},Dataset_precision{1},'FiniteElementFunction',ElementFamily,num2str(ElementDegree),ElementCell};
attr = {num2str(size(dset,2)),num2str(size(dset,1)),'Other','Scalar',Dataset_type{1},Dataset_precision{1},'FiniteElementFunction',ElementFamily,num2str(ElementDegree),ElementCell};
attr_details.Name = 'Matlabdata';
attr_details.AttachedTo = [Dataset_location,'/',Dataset_name,'/',Dataset_name,'_Dofmap'];
attr_details.AttachType = 'dataset';
hdf5write(filename, dset_details, dset, attr_details, attr, 'Writemode',hdf5mode);


dset = Dataset_variable{2};
dset_details.Location = [Dataset_location,'/',Dataset_name];
dset_details.Name = [Dataset_name,'_Valmap'];

attr = {num2str(size(dset,1)),num2str(size(dset,2)),'Other','Scalar',Dataset_type{2},Dataset_precision{2},'FiniteElementFunction',ElementFamily,num2str(ElementDegree),ElementCell};
attr_details.Name = 'Matlabdata';
attr_details.AttachedTo = [Dataset_location,'/',Dataset_name,'/',Dataset_name,'_Valmap'];
attr_details.AttachType = 'dataset';
hdf5write(filename, dset_details, dset, attr_details, attr, 'Writemode',hdf5mode);

%% Added

% dset = int64(cumsum([0,3*ones(1,size(Dataset_variable{1},2))])');
% dset_details.Location = [Dataset_location,'/',Dataset_name];
% dset_details.Name = [Dataset_name,'_x_cell_dofs'];
% 
% attr = {num2str(size(dset,1)),num2str(size(dset,2)),'Other','Scalar','Int','8','FiniteElementFunction',ElementFamily,num2str(ElementDegree),ElementCell};
% attr_details.Name = 'Matlabdata';
% attr_details.AttachedTo = [Dataset_location,'/',Dataset_name,'/',Dataset_name,'_x_cell_dofs'];
% attr_details.AttachType = 'dataset';
% hdf5write(filename, dset_details, dset, attr_details, attr, 'Writemode',hdf5mode);
% 
% dset = int64([0:(size(Dataset_variable{1},2)-1)]');
% dset_details.Location = [Dataset_location,'/',Dataset_name];
% dset_details.Name = [Dataset_name,'_cells'];
% 
% attr = {num2str(size(dset,1)),num2str(size(dset,2)),'Other','Scalar','Int','8','FiniteElementFunction',ElementFamily,num2str(ElementDegree),ElementCell};
% attr_details.Name = 'Matlabdata';
% attr_details.AttachedTo = [Dataset_location,'/',Dataset_name,'/',Dataset_name,'_cells'];
% attr_details.AttachType = 'dataset';
% hdf5write(filename, dset_details, dset, attr_details, attr, 'Writemode',hdf5mode);



% attData = {num2str(1),num2str(1),'Other','Scalar',};
% h5writeatt(filename,[Dataset_location,'/',Dataset_name],'Matlabdata',attData);

end