function [ N_shape, Nodes_val, nnode, degree ] = Gauss2nodes( Gauss_val,element_type,nnode,ngaus )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

% Triangle 3-nodes
%                   %  3 \
%                   %  |   \
%                   %  |     \
%                   %  |       \
%                   %  1--------2
%
% Triangle 6-nodes
%
%                   %  3 \
%                   %  |   \
%                   %  6     5
%                   %  |       \
%                   %  1---4---2
%
% Quadrilateral 4-nodes
%                   %  4--------3
%                   %  |        |
%                   %  |        |
%                   %  |        |
%                   %  1--------2
%
% Quadrilateral 9-nodes
%                   %  4------7------3
%                   %  |             |
%                   %  |             |
%                   %  8      9      6
%                   %  |             |
%                   %  |             |
%                   %  1------5------2
%
% Tetrahedra 4-nodes
%
%
%
%
%
%
% Hexahedron 8-nodes
%
%
%
%
%
%

%%

switch element_type
    case 'Triangle'
        switch ngaus
            case 1
                switch nnode
                    case 3
                        N_shape = ones(1,nnode)/3;
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 1;
                    case 6
                        N_shape = [     -1/9           -1/9           -1/9            4/9            4/9            4/9];
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 2;
                end
            case 3
                switch nnode
                    case 3
                        N_shape = [        1/6            2/3            1/6     
                                           1/6            1/6            2/3     
                                           2/3            1/6            1/6     ];
                        
                        rhs = Gauss_val;
                        
                        degree = 1;
                    case 6
                        N_shape = [       -1/9            2/9           -1/9            4/9            4/9            1/9     
                                          -1/9           -1/9            2/9            1/9            4/9            4/9     
                                           2/9           -1/9           -1/9            4/9            1/9            4/9     ];
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 2;
                end
            case 4
                switch nnode
                    case 3
                        error('impossible');
                    case 6
                        N_shape = [   -1/9           -1/9           -1/9            4/9            4/9            4/9     
                                       3/25          -3/25          -3/25          12/25           4/25          12/25    
                                      -3/25           3/25          -3/25          12/25          12/25           4/25    
                                      -3/25          -3/25           3/25           4/25          12/25          12/25    ];
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 2;
                end
        end
    case 'Quadrilateral'
        switch ngaus
            case 1
                switch nnode
                    case 4
                        N_shape = ones(1,nnode)/4;
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 1;
                    case 9
                        
                        N_shape =[0 0 0 0 0 0 0 0 1];
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 2;
                end
            case 4
                switch nnode
                    case 4
                        
                        N_shape = [ 2651/4262         1/6          130/2911         1/6
                                       1/6          130/2911         1/6         2651/4262
                                       1/6         2651/4262         1/6          130/2911
                                     130/2911         1/6         2651/4262         1/6     ];
                        
                        rhs = Gauss_val;
                        
                        degree = 1;
                    case 9
                        
                        N_shape = [      927/4471        -1/18         130/8733        -1/18         537/1769      -537/6602      -537/6602       537/1769         4/9     
                                          -1/18         130/8733        -1/18         927/4471      -537/6602      -537/6602       537/1769       537/1769         4/9     
                                          -1/18         927/4471        -1/18         130/8733       537/1769       537/1769      -537/6602      -537/6602         4/9     
                                         130/8733        -1/18         927/4471        -1/18        -537/6602       537/1769       537/1769      -537/6602         4/9   ];
                        
                        warning('least-square fitting');
                        rhs = N_shape'*Gauss_val; 
                        N_shape = N_shape'*N_shape;
                        
%                         temp = diag(ones(nnode-1,1),1);
%                         N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
%                         
%                         rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 2;
                end
            case 9
%                 nnode = 9;
                switch nnode
                    case 4
                        warning('least-square fitting');
                        
                        N_shape = [      781/992          1/10         248/19525        1/10    
                                         248/559        248/4401       248/4401       248/559   
                                           1/10         248/19525        1/10         781/992   
                                         248/559        248/559        248/4401       248/4401  
                                           1/4            1/4            1/4            1/4     
                                         248/4401       248/4401       248/559        248/559   
                                           1/10         781/992          1/10         248/19525 
                                         248/4401       248/559        248/559        248/4401  
                                         248/19525        1/10         781/992          1/10    ];
                                     
                       rhs = N_shape'*Gauss_val; 
                       N_shape = N_shape'*N_shape;
                       
                       degree = 1;
                       
                    case 9
                        
                        N_shape = [      419/887         -3/50         171/22438       -3/50        1619/5889      -171/4897      -171/4897      1619/5889         4/25    
                                           0              0              0              0              0           -211/2417         0           1066/1551         2/5     
                                          -3/50         171/22438       -3/50         419/887       -171/4897      -171/4897      1619/5889      1619/5889         4/25    
                                           0              0              0              0           1066/1551         0           -211/2417         0              2/5     
                                           0              0              0              0              0              0              0              0              1       
                                           0              0              0              0           -211/2417         0           1066/1551         0              2/5     
                                          -3/50         419/887         -3/50         171/22438     1619/5889      1619/5889      -171/4897      -171/4897         4/25    
                                           0              0              0              0              0           1066/1551         0           -211/2417         2/5     
                                         171/22438       -3/50         419/887         -3/50        -171/4897      1619/5889      1619/5889      -171/4897         4/25    ];
                                                
                        rhs = Gauss_val;
                        
                        degree = 2;
                end
        end
    case 'Tetrahedron'
        switch ngaus
            case 1
                switch nnode
                    case 4
                        N_shape =[        1/4            1/4            1/4            1/4     ];
                        
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 1;
                        
                    case 10
                        
                end
            case 4
                switch nnode
                    case 4
                        N_shape = [     305/2207       305/2207       305/2207       963/1645  
                                        963/1645       305/2207       305/2207       305/2207  
                                        305/2207       305/2207       963/1645       305/2207  
                                        305/2207       963/1645       305/2207       305/2207  ];
                                    
                        rhs = Gauss_val;
                        degree = 1;
                        
                    case 10
                        
                end
            case 5
                switch nnode
                    case 4
                        N_shape = [        1/4            1/4            1/4            1/4     
                                           1/6            1/6            1/6            1/2     
                                           1/2            1/6            1/6            1/6     
                                           1/6            1/6            1/2            1/6     
                                           1/6            1/2            1/6            1/6 ];
                                       
                       rhs = N_shape'*Gauss_val;
                       N_shape = N_shape'*N_shape;

                       degree = 1;
                    case 10
                        
                end
        end
        
        
    case 'Hexahedron'
        switch ngaus
            case 1
                switch nnode
                    case 8
                        N_shape = ones(1,nnode)/8;
                        temp = diag(ones(nnode-ngaus,1),1);
                        N_shape = [N_shape;eye(nnode-ngaus,nnode)-temp(1:(nnode-ngaus),:)];
                        
                        rhs = [Gauss_val;zeros(nnode-ngaus,size(Gauss_val,2),size(Gauss_val,3))];
                        
                        degree = 1;
                    case 20
                        
                end
                
            case 8
                switch nnode
                    case 8
                        N_shape = [     2703/5510       130/989        130/3691       130/989        130/989        130/3691        26/2755       130/3691  
                                         130/989        130/3691        26/2755       130/3691      2703/5510       130/989        130/3691       130/989   
                                         130/989        130/3691       130/989       2703/5510       130/3691        26/2755       130/3691       130/989   
                                         130/3691        26/2755       130/3691       130/989        130/989        130/3691       130/989       2703/5510  
                                         130/989       2703/5510       130/989        130/3691       130/3691       130/989        130/3691        26/2755  
                                         130/3691       130/989        130/3691        26/2755       130/989       2703/5510       130/989        130/3691  
                                         130/3691       130/989       2703/5510       130/989         26/2755       130/3691       130/989        130/3691  
                                          26/2755       130/3691       130/989        130/3691       130/3691       130/989       2703/5510       130/989   ];
                                      
                        rhs = Gauss_val;
                        
                        degree = 1;              
                    case 20
                        
                end
                
            case 27
                switch nnode
                    case 8
                        N_shape = [      927/1327       248/2795       248/22005      248/2795       248/2795       248/22005       51/35627      248/22005 
                                         781/1984         1/20         124/19525        1/20         781/1984         1/20         124/19525        1/20    
                                         248/2795       248/22005       51/35627      248/22005      927/1327       248/2795       248/22005      248/2795  
                                         781/1984         1/20           1/20         781/1984         1/20         124/19525      124/19525        1/20    
                                         124/559        124/4401       124/4401       124/559        124/559        124/4401       124/4401       124/559   
                                           1/20         124/19525      124/19525        1/20         781/1984         1/20           1/20         781/1984  
                                         248/2795       248/22005      248/2795       927/1327       248/22005       51/35627      248/22005      248/2795  
                                           1/20         124/19525        1/20         781/1984         1/20         124/19525        1/20         781/1984  
                                         248/22005       51/35627      248/22005      248/2795       248/2795       248/22005      248/2795       927/1327  
                                         781/1984       781/1984         1/20           1/20           1/20           1/20         124/19525      124/19525 
                                         124/559        124/559        124/4401       124/4401       124/559        124/559        124/4401       124/4401  
                                           1/20           1/20         124/19525      124/19525      781/1984       781/1984         1/20           1/20    
                                         124/559        124/559        124/559        124/559        124/4401       124/4401       124/4401       124/4401  
                                           1/8            1/8            1/8            1/8            1/8            1/8            1/8            1/8     
                                         124/4401       124/4401       124/4401       124/4401       124/559        124/559        124/559        124/559   
                                           1/20           1/20         781/1984       781/1984       124/19525      124/19525        1/20           1/20    
                                         124/4401       124/4401       124/559        124/559        124/4401       124/4401       124/559        124/559   
                                         124/19525      124/19525        1/20           1/20           1/20           1/20         781/1984       781/1984  
                                         248/2795       927/1327       248/2795       248/22005      248/22005      248/2795       248/22005       51/35627 
                                           1/20         781/1984         1/20         124/19525        1/20         781/1984         1/20         124/19525 
                                         248/22005      248/2795       248/22005       51/35627      248/2795       927/1327       248/2795       248/22005 
                                           1/20         781/1984       781/1984         1/20         124/19525        1/20           1/20         124/19525 
                                         124/4401       124/559        124/559        124/4401       124/4401       124/559        124/559        124/4401  
                                         124/19525        1/20           1/20         124/19525        1/20         781/1984       781/1984         1/20    
                                         248/22005      248/2795       927/1327       248/2795        51/35627      248/22005      248/2795       248/22005 
                                         124/19525        1/20         781/1984         1/20         124/19525        1/20         781/1984         1/20    
                                          51/35627      248/22005      248/2795       248/22005      248/22005      248/2795       927/1327       248/2795  ];
                                
                       rhs = N_shape'*Gauss_val;
                       N_shape = N_shape'*N_shape;

                       degree = 1;       
                        
                    case 20
                        
                end
                
        end
        
        
        
        
end

if size(Gauss_val,3)>1
    
    Nodes_val = zeros(nnode,size(Gauss_val,2),size(Gauss_val,3));
    for i_dim = 1:size(Gauss_val,3)
        Nodes_val(:,:,i_dim) = N_shape\rhs(:,:,i_dim);
    end
else
    Nodes_val = N_shape\rhs;
end

end

