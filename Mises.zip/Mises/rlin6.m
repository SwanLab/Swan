function [phi,J,k]=rlin6(phi,dd,J,b,p,e,t,np,c0,a0,f0,F1,M1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,k,Mps,mureg,creg,penalisation,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp)
cok=0.5;
dd=dd./sqrt(dot(Mps*dd,dd));
pscal=dot(Mps*dd,phi); 
theta=real(acos(pscal))+1e-6;
disp(['theta = ',num2str(theta*180/pi)]);
Jold=J; phiold=phi;
[ar,a1,a2,a3]=pdetrg(p,t); 

J=J+1; 
k=min(1,k*1.5); 
while(J>Jold)
    phi=(sin((1-k)*theta)*phiold+sin(k*theta)*dd)./sin(theta);
    J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp,ar);
    J=J+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
    disp(['k = ',num2str(k),', a = ',num2str(k*theta*180/pi),' and J =', num2str(J)]);
    k=k*cok;
end;

% k=0.5;
% phi=(sin((1-k)*theta)*phiold+sin(k*theta)*dd)./sin(theta);
% J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu);

phi=phi./sqrt(dot(Mps*phi,phi)); k=k/cok;