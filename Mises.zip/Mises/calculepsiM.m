function vpsi=calculepsiM(N,p)
y1=[0:1/N:1-1/N];
y2=[0:1/N:1-1/N];
x1=(exp(1./(1-y1))-exp(1))/4;
x2=(exp(1./(1-y2))-exp(1))/4;
vpsi=[];
for i=1:N
    for j=1:N
    vpsi(i,j)=psiM(x1(i),x2(j),p);
    end;
end;
vpsi=[vpsi,zeros(size(vpsi,1),1)]; vpsi=[vpsi;zeros(1,size(vpsi,2))];