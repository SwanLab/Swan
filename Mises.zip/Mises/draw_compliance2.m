figure(6); clf;
nload=length(compliance);
pas=2/(nload-1);
X=[-1:pas:1];
plot(X,compliance,'b-',X,compmax'*ones(1,nload),'r--'); xlim([-1,1]);