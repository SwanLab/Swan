figure(5); clf;
nload=length(compliance);
pas=2/(nload-1);
X=[-1:pas:1];
plot(X,mucomp*nload); xlim([-1,1]);