figure(5); clf;
nload=length(compliance);
pas=360/(nload-1);
X=[0:pas:360];
plot(X,mucomp*nload); xlim([0,360]);