function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=crack2

load geocrack2.mat; % Load geometry

E=1; nu=1/3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation

prec=1000;
[p1,e1,t1]=poimesh(g1,20,16); p1=round(prec*p1)/prec;
[p2,e2,t2]=poimesh(g2,10,4); p2=round(prec*p2)/prec;
[p3,e3,t3]=poimesh(g3,10,4); p3=round(prec*p3)/prec;

[b,p,e,t]=raccommodesp2(b1,p1,e1,t1,b2,p2,e2,t2);
[b,p,e,t]=raccommodesp2(b,p,e,t,b3,p3,e3,t3);
g=[g1,g2,g3];

%ip0=find(p(1,:)<=2&p(2,:)==0);
%ie1=ismember(e(1,:),ip0);
%ie2=ismember(e(2,:),ip0);
%ie0=ie1.*ie2;
%ie0=find(ie0==0);
%e=e(:,ie0);

[p,e,t]=refinemesh(g,p,e,t,'longest');
%[p,e,t]=refinemesh(g,p,e,t);
%[p,e,t]=refinemesh(g,p,e,t);

xg=(p(1,t(1,:))+p(1,t(2,:))+p(1,t(3,:)))/3;
yg=(p(2,t(1,:))+p(2,t(2,:))+p(2,t(3,:)))/3;
iraf=find((xg-2).^2+(yg-0).^2<0.2^2);
%[p,e,t]=refinemesh(g,p,e,t,iraf');

xg=(p(1,t(1,:))+p(1,t(2,:))+p(1,t(3,:)))/3;
yg=(p(2,t(1,:))+p(2,t(2,:))+p(2,t(3,:)))/3;
iraf=find((xg-2).^2+(yg-0).^2<0.1^2);
%[p,e,t]=refinemesh(g,p,e,t,iraf');

figure(2); clf; pdemesh(p,e,t);

np0=size(p,2); nraf=0;

%yl=1.5;
%i0=find(p(2,t(1,:))>yl & p(2,t(2,:))>yl & p(2,t(3,:))>yl);
%t(4,i0)=2;

% Load

nload=1; iload=[1]; floadx=[0]; floady=[0]; iappli=[];
[floadx,floady,nappl,iappli,iload]=fairefload(p,nload);
lreg=0.2; creg=lreg^2;
mupe=0; mureg=mupe*4/lreg;

mulag=1;

%mucomp=5e-3*ones(1,nload);
%mucomp=1e-1*ones(1,nload);
compmax=25; %6;%5e-6;
pascomp=2e-3;%5e-4;%e9;
baug=2e-3;%2e-4;

gamma=100; gmax=2; %gamma=0;
gmax=gmax*sqrt(2);

%mucomp=mucomp/nload; pascomp=pascomp/nload; baug=baug/nload;
mucomp=1;

%ifixx=find(p(1,:)==1&(p(2,:)==0|p(2,:)==1));
%ifixy=find(p(1,:)==1&(p(2,:)==0|p(2,:)==1));
ifixx=find(p(1,:)==0&p(2,:)==0);
ifixy=find(p(1,:)<=1&p(2,:)==0);

%ifixx=[]; ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);
%ipos=find((p(1,:)-2).^2+p(2,:).^2<0.2^2);
%phi0(ipos)=1;