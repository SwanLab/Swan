function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax]=mast()

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation
% load geoT.mat; % Load geometry
% [p,e,t]=initmesh(g,'Hmax',0.32,'Hgrad',1.9);
% [p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
% %[p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
% np0=size(p,2);
% nraf=0; % Mesh refinement for the computation

% Construction of a regular mesh

load geoT3.mat; % Load geometry
%[p1,e1,t1]=poimesh(g1,8,16); [p2,e2,t2]=poimesh(g2,16,8); 
[p1,e1,t1]=poimesh(g1,16,32); [p2,e2,t2]=poimesh(g2,32,16); 
[p1,e1,t1]=refinemesh(g1,p1,e1,t1,'longest'); [p2,e2,t2]=refinemesh(g2,p2,e2,t2,'longest');

[b,p,e,t]=raccommode(b1,p1,e1,t1,b2,p2,e2,t2);
g=[g1,g2];
%[p,e,t]=refinemesh(g,p,e,t);
%[p,e,t]=refinemesh(g,p,e,t);
p=jigglemesh(p,e,t,'opt','mean');
np0=size(p,2); nraf=0;
%figure(3); clf; pdemesh(p,e,t); pause;

% Load

loadcase=2;
if (loadcase==1)
% single load
%mulag=15; % Lagrange multiplier for the weight
iload=[find((abs(p(1,:))==2) & (p(2,:)==4))]'; % Location of the load
floadx=[[0];[0]];
floady=[[-1];[-1]]; % Intensity of the load
lreg=0.05; creg=lreg^2;
mupe=1; mureg=mupe*4/lreg;
mulag=1;mucomp=1/10;
compmax=100;
pascomp=1/10000;
else
% multiple load (wind)
iload=[[find((abs(p(1,:))==2) & (p(2,:)==4))]',[find((abs(p(1,:))==2) & (p(2,:)==4))]',[find((abs(p(1,:))==2) & (p(2,:)==4))]']; 
%floadx=[[0,-1,1];[0,-1,1]];
floadx=[[0,-0.5,0.5];[0,-0.5,0.5]];
floady=[[-1,-1,-1];[-1,-1,-1]]; 
%mulag=200;
lreg=0.05; creg=lreg^2;
mupe=3; mureg=mupe*4/lreg;
mulag=1;mucomp=[0.1,0.1,0.1];
compmax=[100,200,200];
pascomp=1/10000;
end;
ifixx=[];
ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);