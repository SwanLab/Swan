figure(3); clf; 
%pdeplot(p,e,t,'xydata',(phi>0),'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); 
alpha=fairealpha(phi,p,t,np,eps);
pdeplot(p,e,t,'xydata',1-alpha,'xystyle','flat','colormap','gray','xygrid','off','colorbar','off');
axis image; box on;
figure(4); clf;  
pdecont(p,t,phi,[0 0]);
hold on; pdegplot(g); hold off;
axis image; box on;