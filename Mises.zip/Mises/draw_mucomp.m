figure(5); clf;
plot([1:length(mucomp)],mucomp);