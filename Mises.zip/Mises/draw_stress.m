s=stress(u,p,t,nt,lambda,mu);

sa=s(1,:); sb=s(3,:); sc=s(2,:); 
dis=(sa-sb).^2+4*sc.^2;
s1=(sa+sb-sqrt(dis))/2;
s2=(sa+sb+sqrt(dis))/2;
sd=[s1;s2];

%sm=max(abs(sd)); % sigma max
%sm=abs(s1-s2); % Von Mises faux
sm=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2).*alpha; % Von Mises

alpha=fairealpha(phi,p,t,np,eps);
sm=sm.*alpha;
smp=pdeprtni(p,t,sm);
figure(6); clf; 
%pdecont(p,t,smp);
%sm=max(sm)-sm;
pdeplot(p,e,t,'xydata',-sm,'xystyle','flat','colormap','bone','xygrid','off','colorbar','off'); 
axis image; box on;