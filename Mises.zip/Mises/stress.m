function s=stress(u,p,t,nt,lambda,mu)
e=strain(u,p,t);
id=[1 0 1]';
s=lambda*id*(e(1,:)+e(3,:))+2*mu*e;