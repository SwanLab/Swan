function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=maillon2

load geomaillon.mat; % Load geometry

E=1; nu=1/3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation

[p1,e1,t1]=initmesh(g1,'Hmax',0.5); p1=jigglemesh(p1,e1,t1,'Opt','mean'); 
%[p1,e1,t1]=refinemesh(g1,p1,e1,t1); p1=jigglemesh(p1,e1,t1,'Opt','mean');
%[p1,e1,t1]=refinemesh(g1,p1,e1,t1); p1=jigglemesh(p1,e1,t1,'Opt','mean');
prec=100; p1=round(prec*p1)/prec;
%b1=b; g1=g;
p2=p1; e2=e1; t2=t1; %b2=b1;
p2(2,:)=-p1(2,:); p2=round(prec*p2)/prec;
t2t=t2;
t2(1,:)=t2t(3,:); t2(3,:)=t2t(1,:);
[b,p,e,t]=raccommode(b1,p1,e1,t1,b2,p2,e2,t2);
g2=g1;
for i=1:size(g1,2)
    if g1(1,i)==2
        g2(4,i)=-g1(4,i); g2(5,i)=-g1(5,i);
    elseif g1(1,i)==4
        g2(4,i)=-g1(4,i); g2(5,i)=-g1(5,i);
        g2(9,i)=-g1(9,i); g2(10,i)=-g1(10,i);
    end;
end;
g=[g1,g2];

ip0=find(p(2,:)==0);
ie1=ismember(e(1,:),ip0);
ie2=ismember(e(2,:),ip0);
ie0=ie1.*ie2;
ie0=find(ie0==0);
e=e(:,ie0);

btemp=b(:,25); b(:,25)=b(:,26); b(:,26)=btemp;

%figure(2); clf; pdemesh(p,e,t); pause;

[p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
[p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
%[p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
%[p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
%for i=1:10; p=jigglemesh(p,e,t,'Opt','mean'); end;
figure(2); clf; pdemesh(p,e,t);
np0=size(p,2); nraf=0;
t(4,:)=1;

% Load

nload=1; iload=[1]; floadx=[0]; floady=[0]; iappli=[];
%[floadx,floady,nappl,iappli,iload]=fairefload(p,nload);

ip=find((p(1,:)>14));
%ip=union(ipc,iph); %ip=union(ip,ipc);
%ip=ipc;
it1=ismember(t(1,:),ip);
it2=ismember(t(2,:),ip);
it3=ismember(t(3,:),ip);
it=it1.*it2.*it3;
t(4,:)=t(4,:)+it;

lreg=0.2; creg=lreg^2;
mupe=0; mureg=mupe*4/lreg;

mulag=1;

%mucomp=5e-3*ones(1,nload);
%mucomp=1e-1*ones(1,nload);
compmax=25; %6;%5e-6;
pascomp=2e-3;%5e-4;%e9;
baug=2e-3;%2e-4;

gamma=500; gmax=5; gamma=0;
gmax=gmax*sqrt(2);

%mucomp=mucomp/nload; pascomp=pascomp/nload; baug=baug/nload;
mucomp=0.2; mucomp=0.25;

%ifixx=find(abs(p(1,:))==2&p(2,:)==1);
%ifixy=find(abs(p(1,:))==2&p(2,:)==1);
ifixx=[]; ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);