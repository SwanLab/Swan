function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=ponth

load ponth.mat; % Load geometry

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation
%[p,e,t]=poimesh(g,20,10);
[p,e,t]=poimesh(g,40,20);
[p,e,t]=refinemesh(g,p,e,t,'longest');
np0=size(p,2); nraf=0;

% Load

supp=0.2;

 iloadi=find(p(2,:)==1 & abs(p(1,:))<=1); 

 nload=length(iloadi);


iappli=find(p(2,:)==1); 
iload=(ones(nload,1)*iappli)';
nappl=length(iappli);
floadx=zeros(nappl,nload);
floady=zeros(nappl,nload);
for i=1:nload
floady(:,i)=max(supp-abs(p(1,iloadi(i))-p(1,iappli)),0);
%floady(:,i)=-floady(:,i)/sum(floady(:,i));
floady(:,i)=-floady(:,i)/supp;
end;

%mulag=200;
lreg=0.2; creg=lreg^2;
mupe=0.05; mureg=mupe*4/lreg;
mulag=1;
%mucomp=5e-3*ones(1,nload);
mucomp=1e-2*ones(1,nload);
compmax=100; %6;%5e-6;
pascomp=1e-4;%5e-4;%5e-4;%e9;
baug=1e-4;%5e-4;%2e-4;

mucomp=mucomp/nload; pascomp=pascomp/nload; baug=baug/nload;

%ifixx=find(abs(p(1,:))==1&p(2,:)==0);
%ifixy=find(abs(p(1,:))==1&p(2,:)==0);
ifixx=find(abs(p(1,:))>=0.8&p(2,:)==0);
ifixy=find(abs(p(1,:))>=0.8&p(2,:)==0);
%ifixx=[]; ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);
%phi0=-ones(np0,1)+2*(p(1,:).^2+(p(2,:)-0.5).^2<0.25.^2)';
%phi0=-ones(np0,1)+2*((p(1,:)+1).^2+(p(2,:)-0.5).^2<0.25.^2)'+2*((p(1,:)-1).^2+(p(2,:)-0.5).^2<0.25.^2)';