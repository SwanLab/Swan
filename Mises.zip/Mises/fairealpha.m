function alpha=fairealpha(phi,p,t,np,eps)
ipos=find(phi>=0); ineg=find(phi<0);
alphap=zeros(np,1);
alphap(ipos)=eps; alphap(ineg)=1;
alpha=pdeintrp(p,t,alphap);