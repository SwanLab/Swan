function vpsi=psi(N,p)
y=[0:1/N:1-1/N];
x=-log(1-y)/log(4/3);
vpsi=[];
for i=1:N
vpsi(i)=V1(x(i),p);
end;