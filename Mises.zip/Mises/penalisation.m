function pen=penalisation(t)
p=3;
tm=max(t,1);
pen=(tm.^(1/p)-1).^p;