function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=bridge2()

load geobridge2.mat; % Load geometry

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.0; csn=lfil^2; % coefficient of the semi-norm H1
loadcase=1;

% Mesh Generation
%[p,e,t]=poimesh(g,48,29);
%[p,e,t]=poimesh(g,40,24);
%[p,e,t]=poimesh(g,32,25);
%[p,e,t]=poimesh(g,32,20);
%[p,e,t]=poimesh(g,28,17);
%[p,e,t]=poimesh(g,16,10);
%[p,e,t]=refinemesh(g,p,e,t,'longest');
[p,e,t]=initmesh(g);
[p,e,t]=refinemesh(g,p,e,t);
%[p,e,t]=refinemesh(g,p,e,t);
np0=size(p,2);
nraf=1; % Mesh refinement for the computation

if (loadcase==1)
% Single load
 mulag=15; % Lagrange multiplier for the weight
 iload=find((p(1,:)==0) & (p(2,:)==0)); % Location of the load
 floadx=[0];
 floady=[0]; % Intensity of the load
%iload=[];

 ifixx=[];
 ifixy=find((abs(p(1,:))>0.9) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=1; mureg=mupe*4/lreg;
elseif (loadcase==2)
% Multiple load
mulag=120;
iload=[find((p(1,:)==0) & (p(2,:)==0)),find((p(1,:)==-0.5) & (p(2,:)==0)),find((p(1,:)==0.5) & (p(2,:)==0))];
floadx=[0,0,0];
floady=[-1,-1,-1]; % Intensity of the load
ifixx=[];
ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=3; mureg=mupe*4/lreg;
end;

% Initialization of the level-set function
phi0=-ones(np0,1);
%phi0=ones(np0,1)-2*(p(2,:)<0.6)';
%phi0=ones(np0,1)-2*(p(2,:)<1)';
%phi0=-ones(np0,1)+2*((p(2,:)>1)+(p(1,:).^2+(p(2,:)-0.5).^2<0.4^2))';