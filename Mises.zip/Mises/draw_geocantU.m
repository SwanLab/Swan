figure(3); clf; 
pdeplot(p,e,t,'xydata',(phi>0),'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); 
hold on;
X=[-0.5 2.5 2.5 1.5 1.5 1.3 1.3 1.5 1.5 0.5 0.5 0.7 0.7 0.5 0.5 -0.5 -0.5];
Y=[0    0   2.5 2.5 2.2 2.2 2   2   1   1   2   2   2.2 2.2 2.5 2.5  0];
plot(X,Y,'k-');
hold off;
axis image; axis off;

% figure(4); clf; 
% pdecont(p,t,phi,[0 0]);
% hold on;
% plot(X,Y,'k--');
% hold off;
% axis image; axis off;