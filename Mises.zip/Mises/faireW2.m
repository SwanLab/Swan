function W=faireW2(p,e,t,p0,e0,t0)
np=size(p,2); np0=size(p0,2);
W=sparse(zeros(np0,np));
for i=1:np0
    [is,it]=find(t(1:3,:)==i);
    in=[t(1,it),t(2,it),t(3,it)];
    in=in(find(in>np0));
    W(i,in)=0.5;
end;
W(1:np0,1:np0)=eye(np0);