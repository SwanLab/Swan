function gt=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg)
alpha=(phi<0);
u=(creg*K1+M1)\(M1*alpha);
v=-2*(creg*K1+M1)\(M1*(u-alpha));
gt=v+2*u-1;