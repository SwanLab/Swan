function J=reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg)
alpha=(phi<0);
alphareg=(creg*K1+M1)\(M1*alpha);
d=alpha-alphareg;
J=dot(M1*d,d);