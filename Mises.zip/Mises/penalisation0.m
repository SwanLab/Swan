function pen=penalisation0(t,p)
pen=(1+t.^p).^(1/p)-1;
if (p>100)
    i0=find(t>1.5);
    pen(i0)=t(i0)-1;
end;
pen=real(pen);
