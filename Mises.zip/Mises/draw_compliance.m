figure(6); clf;
plot([1:length(compliance)],compliance);