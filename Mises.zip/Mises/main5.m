% Generic program for compliance minimization

clear all;
tinit=cputime;
% load data
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=mast();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever2();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=bridge();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=bridge3();
[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=beamL();
eps=1e-4; % density of the weak material
fpause=100; % breaks frequency
frad=0.05; % fraction of triangles refined
mad=1; % M for adaption
mal=1; % alpha.^mal for sm2
malx=0; % alpha.^(mal*malx) for smax2
tolJ1=1e-4; tolJ2=1e-3; % tolerance

% Data initialization
p0=p; e0=e; t0=t;
np0=size(p0,2);
a0=zeros(4,1); c0=fairecref(lambda,mu); f0=zeros(2,1);
nt=size(t,2); np=size(p,2);
nload=size(iload,2);
[K1,M1,F1]=assema(p,t,1,1,1);
[Ar,A1,A2,A3]=pdetrg(p,t); Ma=sparse(diag(Ar));
[Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy);

Mps=M1+csn*K1;
phi=phi0;
phi=Mps\(M1*phi);
phi=phi./sqrt(dot(Mps*phi,phi));
k=1;
niter=0;
penalisation=0;
nbraf=0;
wmp=wini; wmpoldp=wmp; phiold=phi;
wm=pdeintrp(p,t,wmp)';
J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wm,Ma,mucomp,mal,malx);
%J=J+mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
Jold=J;
Jminold=-1e99; 
pasm=pasini;
histoJ=[];  histotheta=[]; histoJc=[];
[S11,S12,S22]=faireS(p,e,t,lambda,mu);
[Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
%Ml=real((speye(np)+colimis*(M1\K1)));
Ml=M1+colimis*K1;

% Main loop
while 1<2
    if (J>=Jminold&abs(J-Jold)<tolJ1*abs(Jold)|abs(Jminold-Jold)<tolJ2*abs(Jold))&niter>1
        disp(['J= ',num2str(J),', Jold= ',num2str(Jold),', Jminold= ',num2str(Jminold)]);
        disp(['Number of nodes : ',num2str(np)]);
        disp(['Number of iterations : ',num2str(niter)]);

        %if abs(Jminold-Jold)<tolJ2*Jold
            choix=input('Type s to stop, r to refine: ','s');
        %else
        %    choix='u';
        %end;
        if (choix=='s')
            tcpu=cputime-tinit;
            disp(['CPU time elapsed : ',num2str(tcpu)]);
            break;
        elseif (choix=='r')
            
            alpha=fairealpha(phi,p,t,np,eps);
            [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
            F=F0*ones(1,nload)+Fload;
            K(lfix,:)=Kfix;
            F(lfix,:)=zeros(nfix,nload);
            u=K\F;
            compliance=sum(dot(F,u));
            aire=dot(F1,(phi<0));
            %Jc=compliance+mulag*aire;
            
s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 

sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises

%smaxi=smax*(alpha.^(malx*mal))';
%Jc=mucomp*compliance+mulag*aire+dot(Ma*(sm2'-smaxi),wm);
            
            %J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            
            %sm2r=sm2./smax;

            df=dfstress(sm2,smax);

            %smf=sm2./sqrt(1+sm2/smax);
            %smaxi=smax/sqrt(2);
            smf=fstress(sm2,smax);
            smaxi=fstress(smax,smax);
            Jc=mucomp*compliance+mulag*aire+dot(Ma*(smf'-smaxi),wm);
    
    J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            
    wm=pdeintrp(p,t,wmp)';
            %wma=wm.*(alpha.^mal)';
            wma=wm.*(alpha.^mal)'.*df';
            Fad=mucomp*F+(2*(S11'*((S11*u).*(Ma*wma)))+2*(S22'*((S22*u).*(Ma*wma)))-(S22'*((S11*u).*(Ma*wma)))-(S11'*((S22*u).*(Ma*wma)))+6*(S12'*((S12*u).*(Ma*wma))));
    	    Fad(idir,:)=0;
            Fad(lfix,:)=zeros(nfix,nload);
    	    v=-K\Fad;
            gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx);
            gr=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            gtm=gt+mureg*penalisation*gr;
            gtr=precong(gtm,K1,M1,p,t);
            gtl=Mps\(M1*gtr);
            ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
            
                [p,e,t,phi,wmp]=refinemeshad2(g,p,e,t,phi,ddt,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gtm,wmp,u,v);

                figure(2); clf; pdemesh(p,e,t);
                [Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
                alpha=fairealpha(phi,p,t,np,eps);
                hold on; pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); hold off;
                %p0=p; e0=e; t0=t;
                %[p,e,t]=refinemesh(g,p0,e0,t0);
                np=size(p,2); nt=size(t,2); k=1;
                [K1,M1,F1]=assema(p,t,1,1,1);
		[Ar,A1,A2,A3]=pdetrg(p,t); Ma=sparse(diag(Ar));
		[S11,S12,S22]=faireS(p,e,t,lambda,mu);
                %W=faireW2(p,e,t,p0,e0,t0);
                Mps=M1+csn*K1;
                %phi=W'*phi;
                phi=phi./sqrt(dot(Mps*phi,phi));
                %k=1;
%ifixy=find((abs(p(1,:))>0.8) & (p(2,:)==0)); % FOR THE BRIDGE
                [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy);
                %J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu);
                %J=J+mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
                %[p,e,t,phioldnm,wmoldnm]=refinemeshad(g,p,e,t,phioldnm,ddt,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gtm,wmoldnm,u,v);
                %Jminold=critere(phioldnm,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wmoldnm,Ma,mucomp,mal,malx);
                wmpold=wmp; phiold=phi;
                pold=p; eold=e; told=t;
                
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    u=K\F;
    
    compliance=sum(dot(F,u));
    aire=dot(F1,(phi<0));
    
s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 

sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises

%smaxi=smax*(alpha.^(malx*mal))';
%Jc=mucomp*compliance+mulag*aire+dot(Ma*(sm2'-smaxi),wm);
%smf=sm2./sqrt(1+sm2/smax);
%smaxi=smax/sqrt(2);
smf=fstress(sm2,smax);
smaxi=fstress(smax,smax);
wm=pdeintrp(p,t,wmp)';
Jc=mucomp*compliance+mulag*aire+dot(Ma*(smf'-smaxi),wm);
    
    J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
                
                disp(['Mesh refined, J=',num2str(J)]);
                Jold=J;
                %Jminold=J-0.5*abs(J); 
                Jminold=J-5*abs(J); % !!!!!!!!!!!!!!!!
                pasm=pasini;
                %Ml=real((speye(np)+colimis*(M1\K1)));
                Ml=M1+colimis*K1;
                
        elseif (choix=='p')
            penalisation=1;
            %J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu);
            %J=J+mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
        elseif (choix=='u')
                pasm=pasm*8;
                wmpold=wmp; phiold=phi;
                pold=p; eold=e; told=t; k=1;
                Jminold=J;
                disp(['Iteration validated, J=',num2str(J)]);
%            end;
            disp(['pasm = ',num2str(pasm)]);
            s=stress(u,p,t,nt,lambda,mu);
            sa=s(1,:); sb=s(3,:); sc=s(2,:); 
            sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises

            %smaxi=smax*(alpha.^(malx*mal))';
            %ecart=sm2-smaxi';
            
            %smf=sm2./sqrt(1+sm2/smax);
            %smaxi=smax/sqrt(2);
            smf=fstress(sm2,smax);
            smaxi=fstress(smax,smax);
            ecart=smf-smaxi';
            [Kal,Mal,Fal]=assema(p,t,alpha,1,1);
            %Ml=sqrt((Mal+colimis*Kal)\Mal);
            ecart=pdeprtni(p,t,ecart); ecart=Ml\(M1*ecart); %ecart=pdeintrp(p,t,ecart);
            %ecart=pdeprtni(p,t,ecart); ecart=(Mal+colimis*Kal)\(Mal*ecart); ecart=pdeintrp(p,t,ecart);
            figure(3); clf; pdeplot(p,e,t,'xydata',ecart,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on');
            
            %wm=max(wm+pasm*ecart',0);
            %wmp=Ml\(M1*max(M1\(Ml*wmp)+pasm*ecart,0)); wm=pdeintrp(p,t,wmp)';
            wmp=max(wmp+pasm*ecart,0); wm=pdeintrp(p,t,wmp)';
        end;
    
    elseif (J<Jminold)
                    disp(['Step decreased, J=',num2str(J)]);
                pasm=pasm/2; wmp=wmpold; phi=phiold; 
                %p=pold; e=eold; t=told; np=size(p,2); nt=size(t,2);
%                J=Jminold;
%                 [Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
                 alpha=fairealpha(phi,p,t,np,eps);

                 [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
                 [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy);
                 F=F0*ones(1,nload)+Fload;
                 K(lfix,:)=Kfix;
                 F(lfix,:)=zeros(nfix,nload);
                 u=K\F;
            s=stress(u,p,t,nt,lambda,mu);
            sa=s(1,:); sb=s(3,:); sc=s(2,:); 
            
            sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises

            smf=fstress(sm2,smax);
            smaxi=fstress(smax,smax);
            ecart=smf-smaxi';
            
            [Kal,Mal,Fal]=assema(p,t,alpha,1,1);
            
            
            %Ml=sqrt((Mal+colimis*Kal)\Mal);
            ecart=pdeprtni(p,t,ecart); ecart=Ml\(M1*ecart); %ecart=pdeintrp(p,t,ecart);
            %ecart=pdeprtni(p,t,ecart); ecart=(Mal+colimis*Kal)\(Mal*ecart); ecart=pdeintrp(p,t,ecart);
            
            figure(3); clf; pdeplot(p,e,t,'xydata',ecart,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on');
            
            %wm=max(wm+pasm*ecart',0);
            %wmp=Ml\(M1*max(M1\(Ml*wmp)+pasm*ecart,0)); wm=pdeintrp(p,t,wmp)';
            wmp=max(wmp+pasm*ecart,0); wm=pdeintrp(p,t,wmp)';
            k=1;
    
    end;
    
    
    alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    u=K\F;
    
    compliance=sum(dot(F,u));
    aire=dot(F1,(phi<0));
%    Jc=compliance+mulag*aire;
    
s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
%dis=(sa-sb).^2+4*sc.^2;
%s1=(sa+sb-sqrt(dis))/2;
%s2=(sa+sb+sqrt(dis))/2;
%sd=[s1;s2];
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
sm2=sm2.*(alpha.^mal);

%sm2r=sm2./smax;
%df=0.5*(sm2r+2)./(1+sm2r).^1.5;
df=dfstress(sm2,smax);

%smaxi=smax*(alpha.^(malx*mal))';
%Jc=mucomp*compliance+mulag*aire+dot(Ma*(sm2'-smaxi),wm);
%smf=sm2./sqrt(1+sm2/smax);
%smaxi=smax/sqrt(2);
smf=fstress(sm2,smax);
smaxi=fstress(smax,smax);
wm=pdeintrp(p,t,wmp)';
Jc=mucomp*compliance+mulag*aire+dot(Ma*(smf'-smaxi),wm);
    
    J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);

    %v=-u;
    %wma=wm.*(alpha.^mal)';
    wma=wm.*(alpha.^mal)'.*df';
    %mucomp*compliance+mulag*aire+dot(Ma*(S11*u),(S11*u).*wma)+dot(Ma*(S22*u),(S22*u).*wma)-dot(Ma*(S22*u),(S11*u).*wma)+3*dot(Ma*(S12*u),(S12*u).*wma)
    %mucomp*compliance+mulag*aire+dot(Ma*wma,(S11*u).^2)+dot(Ma*wma,(S22*u).^2)-dot(Ma*wma,(S11*u).*(S22*u))+3*dot(Ma*wma,(S12*u).^2)
    %mucomp*compliance+mulag*aire+dot(Ma*wma,(S11*u).^2+(S22*u).^2-(S11*u).*(S22*u)+3*(S12*u).^2)
    %v=-K\(F+(2*(S11'*((S11*u).*(Ma*wma)))+2*(S22'*((S22*u).*(Ma*wma)))-(S22'*((S11*u).*(Ma*wma)))-(S11'*((S22*u).*(Ma*wma)))+3*(S12'*((S12*u).*(Ma*wma)))));
    %v=-K\(F+(2*(S11'*Ma*((S11*u).*(wma)))+2*(S22'*Ma*((S22*u).*(wma)))-(S22'*Ma*((S11*u).*(wma)))-(S11'*Ma*((S22*u).*(wma)))+3*(S12'*Ma*((S12*u).*(wma)))));
    %Fad=mucomp*F+(2*(S11'*((S11*u).*(Ma*wma)))+2*(S22'*((S22*u).*(Ma*wma)))-(S22'*((S11*u).*(Ma*wma)))-(S11'*((S22*u).*(Ma*wma)))+6*(S12'*((S12*u).*(Ma*wma))));
    %M1d=sparse([[M1,zeros(np,np)];[zeros(np,np),M1]]); wmpd=[wmp;wmp];
    %Fad=mucomp*F+M1d*(2*(S11'*((S11*u).*(wma)))+2*(S22'*((S22*u).*(wma)))-(S22'*((S11*u).*(wma)))-(S11'*((S22*u).*(wma)))+6*(S12'*((S12*u).*(wma))));
    Maa=sparse(diag(Ar.*wma'));
    Fad=mucomp*F+2*S11'*(Maa*((S11*u)))+2*S22'*(Maa*((S22*u)))-S22'*(Maa*((S11*u)))-S11'*(Maa*((S22*u)))+6*S12'*(Maa*((S12*u)));
    %M1d=sparse([[M1,zeros(np,np)];[zeros(np,np),M1]]); wmpd=[wmp;wmp];
    %Fad=mucomp*F+M1d*(wmpd.*(2*S11'*(S11*u)+2*S22'*(S22*u)-S22'*(S11*u)-S11'*(S22*u)+6*S12'*(S12*u)));
    
    %ifixy=find((abs(p(2,:)) >= 0.8) & (p(1,:)==0));
    %Fad(np+ifixy,:)=0;
    Fad(idir,:)=0;
    Fad(lfix,:)=zeros(nfix,nload);
    %v=-mucomp*u;
    v=-K\Fad;
    gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx);
    gr=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
    gtr=gt+mureg*penalisation*gr;
    disp(['J = ', num2str(J)]);
    histoJ=[histoJ,J]; 
    histoJc=[histoJc,Jc]; 
    %gtl=gt; %gtl=W'*(Mg\(W*(M1*gt))); % filtering
    
    gtr=precong(gtr,K1,M1,p,t); %preconditioning
    
    gtl=Mps\(M1*gtr);
    
    ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
    pscal=dot(Mps*ddt,phi); 
    theta=acos(pscal);
    histotheta=[histotheta,theta];
    sm=sqrt(sm2);
    smf=fstress(sm2,smax);
    
    figure(1); clf; 
    subplot(4,2,1); pdesurf(p,t,phi); title('Levelset function');
    subplot(4,2,2); pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); title('Current design'); axis image; axis off;
    subplot(4,2,3); pdesurf(p,t,gt); title('Topological gradient');
    %subplot(4,2,4); pdesurf(p,t,gr); title('Regularization');
    subplot(4,2,4); pdesurf(p,t,gtr); title('Regularized Topological gradient');
    %subplot(4,2,6); pdesurf(p,t,gtl); title('Filtered topological gradient');
    subplot(4,2,5); plot([0:niter], histoJ,'r-',[0:niter],histoJc,'b--'); title('Lagrange functional');
    subplot(4,2,6); plot([0:niter], histotheta*180/pi,'r-'); title('Theta');
    subplot(4,2,7); pdeplot(p,e,t,'xydata',smf,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Von Mises stress'); axis image; axis off;
    subplot(4,2,8); pdeplot(p,e,t,'xydata',wm,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Lagrange multiplier'); axis image; axis off;
    pause(0.1);
    
    Jold=J;
    [phi,J,k]=rlin6(phi,ddt,J,b,p,e,t,np,c0,a0,f0,F1,M1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,k,Mps,mureg,creg,penalisation,smax,wm,Ma,mucomp,mal,malx);
    
    niter=niter+1;
end;