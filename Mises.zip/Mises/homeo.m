function x=homeo(y)
%x=1./(1-y)-1;
alpha=1.6; x=(atanh(alpha*y+1-alpha))/atanh(alpha-1)+1;