function psi=distancing(p,t,psi0)
psi=psi0;
for i=0:500
    [psix,psiy]=pdegrad(p,t,psi);
    ngpsi=sqrt(psix.^2+psiy.^2);
    ngpsi=pdeprtni(p,t,ngpsi);
    psi=psi-0.01*sign(psi0).*(ngpsi-1);
    %figure(2); clf; pdesurf(p,t,psi); pause;
end;
