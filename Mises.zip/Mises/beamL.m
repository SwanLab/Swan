function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=beamL()

load geobeamL.mat; % Load geometry

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.0; csn=lfil^2; % coefficient of the semi-norm H1
loadcase=1;

% Mesh Generation
%[p,e,t]=poimesh(g,48,29);
%[p,e,t]=poimesh(g,40,24);
%[p,e,t]=poimesh(g,32,25);
%[p,e,t]=poimesh(g,32,20);
%[p,e,t]=poimesh(g,28,17);
%[p,e,t]=poimesh(g,16,10);
%[p,e,t]=refinemesh(g,p,e,t,'longest');
%[p,e,t]=initmesh(g);
%[p,e,t]=refinemesh(g,p,e,t);
%[p,e,t]=refinemesh(g,p,e,t);
prec=1000;
[p1,e1,t1]=poimesh(g1,4,6); p1=round(prec*p1)/prec;
[p6,e6,t6]=poimesh(g6,4,4); p6=round(prec*p6)/prec;
[p2,e2,t2]=poimesh(g2,4,4); p2=round(prec*p2)/prec;
[p3,e3,t3]=poimesh(g3,2,1); p3=round(prec*p3)/prec;
[p4,e4,t4]=poimesh(g4,2,2); p4=round(prec*p4)/prec;
[p5,e5,t5]=poimesh(g5,2,1); p5=round(prec*p5)/prec;
[b,p,e,t]=raccommode1(b1,p1,e1,t1,b6,p6,e6,t6);
[b,p,e,t]=raccommode1(b,p,e,t,b2,p2,e2,t2);
[b0,p0,e0,t0]=raccommode1(b3,p3,e3,t3,b4,p4,e4,t4);
[b0,p0,e0,t0]=raccommode1(b0,p0,e0,t0,b5,p5,e5,t5);
[b,p,e,t]=raccommode1(b,p,e,t,b0,p0,e0,t0);
g=[g1,g6,g2,g3,g4,g5];
%g=[g1,g6,g2];
[p,e,t]=refinemesh(g,p,e,t,'longest');
[p,e,t]=refinemesh(g,p,e,t);

figure(4); clf; pdemesh(p,e,t); %pause;
np0=size(p,2); nt0=size(t,2);
nraf=1; % Mesh refinement for the computation

 mulag=1; % Lagrange multiplier for the weight
 mucomp=0;%0.05; % Lagrange multiplier for the compliance
 iload=find((p(1,:)==0) & (p(2,:)==0)); % Location of the load
 floadx=[0];
 floady=[0]; % Intensity of the load
%iload=[];

 ifixx=[]; ifixy=[];
 %ifixy=find((abs(p(1,:))>0.8) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=1; mureg=mupe*4/lreg;
%wini=zeros(np0,1);
%wini=0.5*ones(np0,1);
%wini=100*max(0.5-((p(1,:)-2).^2+(p(2,:)-1).^2).^(1/4),0)'+1;
%wini=100*(sqrt((p(1,:)-2).^2+(p(2,:)-2).^2)<0.5)'+0.05;
wini=10*max(0.5-sqrt((p(1,:)-2).^2+(p(2,:)-2).^2),0)'+0.5;
%wini=(p(1,:)>2)'+0.1;
%wini=0.1*p(1,:)';

smax=1; 
smax=smax^2;
pasini=0.1;
colimis=0.0^2; % smoothing of the constraint


% Initialization of the level-set function
%phi0=-ones(np0,1);
phi0=-ones(np0,1)+2*(sqrt((p(1,:)-2).^2+(p(2,:)-2).^2)<1.5)';
%phi0=ones(np0,1)-2*(p(2,:)<1)';
%phi0=-ones(np0,1)+2*((p(2,:)>1)+(p(1,:).^2+(p(2,:)-0.5).^2<0.4^2))';