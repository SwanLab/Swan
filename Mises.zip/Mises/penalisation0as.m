function pen=penalisation0as(t)

pen=max(0,t-1);
pen=real(pen);
