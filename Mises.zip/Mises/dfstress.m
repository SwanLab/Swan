function df=dfstress(x,smax)
y=x/smax;
df=0.5*(y+2)./(y+1).^(3/2);
%df=1./(y+1);
%df=1;