function psitab=fairepsitab(cogamma,npsi,imax)
psitab=[];
for i=1:imax
    i
    pp=cogamma^(i-1);
    vpsi=calculepsiM2(npsi,pp);
    psitab=[psitab,reshape(vpsi,(npsi+1)^2,1)];
end;
disp('infinity');
vpsi=calculepsiM2as(npsi);
psitab=[psitab,reshape(vpsi,(npsi+1)^2,1)];