function f=d2phi(p,t);
f=(p-1)*(1+t.^p).^(1/p-2).*t.^(p-2);