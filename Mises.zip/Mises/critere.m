function J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp,ar)
alpha=fairealpha(phi,p,t,np,eps);
c=c0*alpha;
[K,F0]=assempde(b,p,e,t,c,a0,f0);
F=F0*ones(1,nload)+Fload;
%F=F0;
K(lfix,:)=Kfix;
F(lfix,:)=zeros(nfix,nload);

u=K\F;

%compliance=dot(mucomp,dot(F,u));
compliance=dot(F,u);
%Jcompliance=(norm(max(mucomp+baug*(compliance-compmax),0),2)^2-norm(mucomp,2)^2)/(2*baug);
%aire=dot(F1,(phi<0));
aire=sum(ar.*alpha);

s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises

%smf=fstress(sm2,smax);
%smaxi=fstress(smax,smax);
%J=Jcompliance+mulag*aire; %+dot(Ma*(smf'-smaxi),wm);

[ar,a1,a2,a3]=pdetrg(p,t);
%[ux,uy]=pdegrad(p,t,u);
%tt=0.5*(alpha.^mal).*(ux.^2+uy.^2);
%tt=0.5*(ux.^2+uy.^2);
tt=sm2;
tt=2*tt/gmax^2;
%beta=(alpha>0.99);
beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;
