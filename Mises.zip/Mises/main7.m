% Generic program for compliance minimization

clear all;
tinit=cputime;
% load data
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax]=mast;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug]=viaduc4;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug]=viaduc7;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever;
%%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever2();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax]=bridge;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=bridge3;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=beamL();
[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=pont;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=console;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=ponth;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=cantileverp;
eps=1e-4; % density of the weak material
fpause=1; % breaks frequency
frad=0.03; % fraction of triangles refined
mad=1; % M for adaption
mal=1; % alpha.^mal for sm2
malx=0; % alpha.^(mal*malx) for smax2
tolJ1=1e-4; tolJ2=1e-5; % tolerance
thetaraf=5*pi/180; toltheta=(1e-3)*pi/180;
tolcomp=0.1;

% Data initialization
p0=p; e0=e; t0=t;
np0=size(p0,2);
a0=zeros(4,1); c0=fairecref(lambda,mu); f0=zeros(2,1);
nt=size(t,2); np=size(p,2);
nload=size(iload,2);
[K1,M1,F1]=assema(p,t,1,1,1);
[Ar,A1,A2,A3]=pdetrg(p,t); Ma=sparse(diag(Ar));
[Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli);

wm=0; smax=0;
%mucomp=1;mulag=0;
%mulag=1;mucomp=1/100;
pasini=1;
colimis=0;
%airemax=0.5;
%paslag=50;
%compmax=80;
%pascomp=1/10000;

Mps=M1+csn*K1;
phi=phi0;
phi=Mps\(M1*phi);
phi=phi./sqrt(dot(Mps*phi,phi));
k=1;
niter=0;
penalisation=0;
nbraf=0;
%wmp=wini; wmpoldp=wmp; phiold=phi;
%wm=pdeintrp(p,t,wmp)';
J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wm,Ma,mucomp,mal,malx,baug,compmax);
J=J+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
Jold=J;
Jminold=-1e99; 
pasm=pasini;
histoJ=[];  histotheta=[]; histoJc=[]; histoaire=[]; histomulag=[]; histocomp=[];
%[S11,S12,S22]=faireS(p,e,t,lambda,mu);
[Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
%Ml=real((speye(np)+colimis*(M1\K1)));
Ml=M1+colimis*K1;
thetaold=0; theta=0;
nup=5; nupq=10;

% Main loop
while 1<2
    %if (J>=Jminold&abs(J-Jold)<tolJ1*abs(Jold)|abs(Jminold-Jold)<tolJ2*abs(Jold))&niter>1
    %if (abs(J-Jold)<tolJ2*abs(Jold))&niter>1
    if (abs(J-Jold)<tolJ2*abs(Jold))&(niter>1)&(abs(theta-thetaold)<toltheta)
        if (theta>thetaraf)&(np<6000)
            choix='r'; disp(['Refining']);
            disp(['Number of nodes : ',num2str(np)]);
        %elseif (norm(max(compliance-compmax,0),2)/norm(compmax,2)>tolcomp)|(niter~=floor(niter/10))
        elseif (nup/nupq~=floor(nup/nupq))   
            choix='u'; disp(['Updating']);
        else
        
        disp(['J= ',num2str(J),', Jold= ',num2str(Jold),', Jminold= ',num2str(Jminold)]);
        
        disp(['Number of nodes : ',num2str(np)]);
        disp(['Number of iterations : ',num2str(niter)]);

        %if abs(Jminold-Jold)<tolJ2*Jold
            choix=input('Type s to stop, r to refine, u to update: ','s');
        %else
        %    choix='u';
        %end;
        end;
        if (choix=='s')
            tcpu=cputime-tinit;
            disp(['CPU time elapsed : ',num2str(tcpu)]);
            break;
        elseif (choix=='r')
            
            alpha=fairealpha(phi,p,t,np,eps);
            [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
            F=F0*ones(1,nload)+Fload;
            K(lfix,:)=Kfix;
            F(lfix,:)=zeros(nfix,nload);
            u=K\F;
            %compliance=sum(dot(F,u));
            compliance=dot(F,u);
            aire=dot(F1,(phi<0));
            %Jc=compliance+mulag*aire;
            
% s=stress(u,p,t,nt,lambda,mu);
% sa=s(1,:); sb=s(3,:); sc=s(2,:); 
% 
% sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises
% 
% 
%             df=dfstress(sm2,smax);
% 
%             smf=fstress(sm2,smax);
%             smaxi=fstress(smax,smax);
            %Jc=mucomp*compliance+mulag*aire; %+dot(Ma*(smf'-smaxi),wm);
            Jc=(norm(max(mucomp+baug*(compliance-compmax),0),2)^2-norm(mucomp,2)^2)/(2*baug)+mulag*aire;
    
    J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            
%     wm=pdeintrp(p,t,wmp)';
%             
%             wma=wm.*(alpha.^mal)'.*df';
%             Fad=mucomp*F+(2*(S11'*((S11*u).*(Ma*wma)))+2*(S22'*((S22*u).*(Ma*wma)))-(S22'*((S11*u).*(Ma*wma)))-(S11'*((S22*u).*(Ma*wma)))+6*(S12'*((S12*u).*(Ma*wma))));
%     	    Fad(idir,:)=0;
%             Fad(lfix,:)=zeros(nfix,nload);
%     	    v=-K\Fad;
            %v=-u; 
            v=-u*diag(max(mucomp+baug*(compliance-compmax),0));
            wmp=0;
            gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx);
            gr=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            gtm=gt+mureg*penalisation*gr;
            gtr=precong(gtm,K1,M1,p,t);
            gtl=Mps\(M1*gtr);
            ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
            
                [p,e,t,phi,wmp]=refinemeshad2(g,p,e,t,phi,ddt,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gtm,wmp,u,v);
                

                figure(2); clf; pdemesh(p,e,t);
                [Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
                alpha=fairealpha(phi,p,t,np,eps);
                hold on; pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); hold off;
                %p0=p; e0=e; t0=t;
                %[p,e,t]=refinemesh(g,p0,e0,t0);
                np=size(p,2); nt=size(t,2); k=1;
                [K1,M1,F1]=assema(p,t,1,1,1);
		[Ar,A1,A2,A3]=pdetrg(p,t); Ma=sparse(diag(Ar));
		%[S11,S12,S22]=faireS(p,e,t,lambda,mu);
                %W=faireW2(p,e,t,p0,e0,t0);
                Mps=M1+csn*K1;
                %phi=W'*phi;
                phi=phi./sqrt(dot(Mps*phi,phi));
                %k=1;
%ifixy=find((abs(p(1,:))>0.8) & (p(2,:)==0)); % FOR THE BRIDGE
                %[floadx,floady,nappl,iappli,iload]=fairefload(p,nload);
                [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli);
                
                %J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu);
                %J=J+mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
                %[p,e,t,phioldnm,wmoldnm]=refinemeshad(g,p,e,t,phioldnm,ddt,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gtm,wmoldnm,u,v);
                %Jminold=critere(phioldnm,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wmoldnm,Ma,mucomp,mal,malx);
                wmpold=wmp; phiold=phi;
                pold=p; eold=e; told=t;
                
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    u=K\F;
    
    compliance=dot(F,u);
    aire=dot(F1,(phi<0));
%     
% s=stress(u,p,t,nt,lambda,mu);
% sa=s(1,:); sb=s(3,:); sc=s(2,:); 
% 
% sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises
% 
% smf=fstress(sm2,smax);
% smaxi=fstress(smax,smax);
% wm=pdeintrp(p,t,wmp)';
%Jc=dot(mucomp,compliance)+mulag*aire;%+dot(Ma*(smf'-smaxi),wm);
Jc=(norm(max(mucomp+baug*(compliance-compmax),0),2)^2-norm(mucomp,2)^2)/(2*baug)+mulag*aire;
    
    J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
                
                disp(['Mesh refined, J=',num2str(J)]);
                Jold=J;
                %Jminold=J-0.5*abs(J); 
                Jminold=J-5*abs(J); % !!!!!!!!!!!!!!!!
                pasm=pasini;
                
                Ml=M1+colimis*K1;
                
        elseif (choix=='p')
            penalisation=1;
            
        elseif (choix=='u')
            nup=nup+1;
                aire=dot(F1,(phi<0));
            %mulag=max(0,mulag+paslag*(aire-airemax));
            %mucomp=max([zeros(1,length(mucomp));mucomp+pascomp*(compliance-compmax)]);
            
            ddmu=(max(mucomp+baug*(compliance-compmax),0)-mucomp)/baug;
            mucomp=max([zeros(1,length(mucomp));mucomp+pascomp*(ddmu)]);
            %mucomp=mucomp+pascomp*(ddmu);
            
%             phi=phi0;
%             phi=Mps\(M1*phi);
%             phi=phi./sqrt(dot(Mps*phi,phi));
%             k=1;
            
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    u=K\F;
    
    compliance=dot(F,u);
    aire=dot(F1,(phi<0));
    %Jold=dot(mucomp,compliance)+mulag*aire;
    Jold=(norm(max(mucomp+baug*(compliance-compmax),0),2)^2-norm(mucomp,2)^2)/(2*baug)+mulag*aire;
    Jold=Jold+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);

%                 pasm=pasm*8;
%                 wmpold=wmp; phiold=phi;
%                 pold=p; eold=e; told=t; k=1;
%                 Jminold=J;
%                 disp(['Iteration validated, J=',num2str(J)]);
% 
%             disp(['pasm = ',num2str(pasm)]);
%             s=stress(u,p,t,nt,lambda,mu);
%             sa=s(1,:); sb=s(3,:); sc=s(2,:); 
%             sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises
% 
%             smf=fstress(sm2,smax);
%             smaxi=fstress(smax,smax);
%             ecart=smf-smaxi';
%             [Kal,Mal,Fal]=assema(p,t,alpha,1,1);
%         
%             ecart=pdeprtni(p,t,ecart); ecart=Ml\(M1*ecart); 
%             figure(3); clf; pdeplot(p,e,t,'xydata',ecart,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on');
%             
%             wmp=max(wmp+pasm*ecart,0); wm=pdeintrp(p,t,wmp)';
        k=1;
        end;
    
    elseif (J<Jminold)
                    disp(['Step decreased, J=',num2str(J)]);
                pasm=pasm/2; wmp=wmpold; phi=phiold; 
                
                 alpha=fairealpha(phi,p,t,np,eps);

                 [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
                 [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy);
                 F=F0*ones(1,nload)+Fload;
                 K(lfix,:)=Kfix;
                 F(lfix,:)=zeros(nfix,nload);
                 u=K\F;
            s=stress(u,p,t,nt,lambda,mu);
            sa=s(1,:); sb=s(3,:); sc=s(2,:); 
            
            sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2).*(alpha.^mal); % Von Mises

            smf=fstress(sm2,smax);
            smaxi=fstress(smax,smax);
            ecart=smf-smaxi';
            
            [Kal,Mal,Fal]=assema(p,t,alpha,1,1);
            
            
          
            ecart=pdeprtni(p,t,ecart); ecart=Ml\(M1*ecart); 
            
            figure(3); clf; pdeplot(p,e,t,'xydata',ecart,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on');
            
            wmp=max(wmp+pasm*ecart,0); wm=pdeintrp(p,t,wmp)';
            k=1;
    
    end;
    
    
    alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    u=K\F;
    
    compliance=dot(F,u);
    
    aire=dot(F1,(phi<0));
    
    %J=dot(mucomp,compliance)+mulag*aire;
    J=(norm(max(mucomp+baug*(compliance-compmax),0),2)^2-norm(mucomp,2)^2)/(2*baug)+mulag*aire;
    J=J+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
    
% s=stress(u,p,t,nt,lambda,mu);
% sa=s(1,:); sb=s(3,:); sc=s(2,:); 
% 
% sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
% sm2=sm2.*(alpha.^mal);
% 
% df=dfstress(sm2,smax);
% 
% smf=fstress(sm2,smax);
% smaxi=fstress(smax,smax);
% %wm=pdeintrp(p,t,wmp)';
% Jc=mucomp*compliance+mulag*aire; %+dot(Ma*(smf'-smaxi),wm);
%     
%     J=Jc+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);

    %v=-u;
    %v=-u*diag(mucomp);
    v=-u*diag(max(mucomp+baug*(compliance-compmax),0));
%     
%     wma=wm.*(alpha.^mal)'.*df';
%     
%     Maa=sparse(diag(Ar.*wma'));
%     Fad=mucomp*F;%+2*S11'*(Maa*((S11*u)))+2*S22'*(Maa*((S22*u)))-S22'*(Maa*((S11*u)))-S11'*(Maa*((S22*u)))+6*S12'*(Maa*((S12*u)));
%     
%     Fad(idir,:)=0;
%     Fad(lfix,:)=zeros(nfix,nload);
%     %v=-mucomp*u;
%     v=-K\Fad;
    gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx);
    gr=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
    gtr=gt+mureg*penalisation*gr;
    disp(['J = ', num2str(J)]);
    histoJ=[histoJ,J]; 
    %histoJc=[histoJc,Jc]; 
    %gtl=gt; %gtl=W'*(Mg\(W*(M1*gt))); % filtering
    
    gtr=precong(gtr,K1,M1,p,t); %preconditioning
    
    gtl=Mps\(M1*gtr);
    
    ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
    pscal=dot(Mps*ddt,phi);
    thetaold=theta;
    theta=real(acos(pscal));
    histotheta=[histotheta,theta];
    histoaire=[histoaire,aire];
    %histomulag=[histomulag,mulag];
    histomulag=[histomulag,mucomp'];
    histocomp=[histocomp,compliance'];
disp(['Volume : ',num2str(aire)]);
disp(['Compliance : ',num2str(compliance)]);
    
    figure(1); clf; 
    subplot(4,2,1); pdesurf(p,t,phi); title('Levelset function');
    subplot(4,2,2); pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); title('Current design'); axis image; axis off;
    subplot(4,2,3); pdesurf(p,t,gt); title('Topological gradient');
    %subplot(4,2,4); pdesurf(p,t,gr); title('Regularization');
    subplot(4,2,4); pdesurf(p,t,gtr); title('Regularized Topological gradient');
    %subplot(4,2,6); pdesurf(p,t,gtl); title('Filtered topological gradient');
    %subplot(4,2,5); plot([0:niter], histoJ,'r-'); title('Lagrange functional');
    subplot(4,2,5); plot([0:niter], histocomp,'r-',[0:niter], compmax'*ones(1,niter+1),'b--'); title('Compliance');
    subplot(4,2,6); plot([0:niter], histotheta*180/pi,'r-'); title('Theta');
    %subplot(4,2,7); pdeplot(p,e,t,'xydata',smf,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Von Mises stress'); axis image; axis off;
    %subplot(4,2,8); pdeplot(p,e,t,'xydata',wm,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Lagrange multiplier'); axis image; axis off;
    subplot(4,2,7); plot([0:niter], histoaire,'r-'); title('Volume'); 
    subplot(4,2,8); plot([0:niter], histomulag,'r-'); title('Lagrange multiplier'); 
    pause(0.1);
    
    Jold=J;
    [phi,J,k]=rlin6(phi,ddt,J,b,p,e,t,np,c0,a0,f0,F1,M1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,k,Mps,mureg,creg,penalisation,smax,wm,Ma,mucomp,mal,malx,baug,compmax);
    
    niter=niter+1;
    if (niter>2000)
        break;
    end;
end;