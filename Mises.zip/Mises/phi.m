function f=phi(p,t);
f=(1+t.^p).^(1/p)-1;