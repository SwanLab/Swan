function [p,e,t,phi,wm]=refinemeshad(g,p0,e0,t0,phi,dd,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gt,wm,U,V)
methode=4;

% pscal=dot(Mps*dd,phi);
% veres=dd-pscal*phi;
% veres2=(Mps*veres).*veres;
% %veres2=veres.*veres;
% figure(5); clf; pdesurf(p0,t0,veres2);
% verest=pdeintrp(p0,t0,veres2);
% [verests,is]=sort(verest,'descend');
% thr=verests(ceil(nt*frad));
% irp=find(verest>thr)';
% %irp=is(1:ceil(nt*frad));

alpha=fairealpha(phi,p0,t0,np,eps);
% [K,F0]=assempde(b,p0,e0,t0,c0*alpha,a0,f0); 
% F=F0*ones(1,nload)+Fload;
% K(lfix,:)=Kfix;
% F(lfix,:)=zeros(nfix,nload);
% U=K\F;

%ce=alpha.*pdeintrp(p0,t0,veres./(1+abs(gt)));
%[Ke,Me,Fe]=assema(p0,t0,ce,a0,f0);
%V=Ke*u;
%w=K\V;

if (methode==1) % residual error estimate
erffcc=zeros(1,nt);
for iload=1:nload
u=U(:,iload);
w=-u;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	%wi=w((i-1)*np+1:i*np);
	%[wx,wy]=pdegrad(p0,t0,wi);
	%wx=pdeprtni(p0,t0,wx); wy=pdeprtni(p0,t0,wy);
	%[wxx,wyx]=pdegrad(p0,t0,wx); [wxy,wyy]=pdegrad(p0,t0,wy);
	%w2=wxx.^2+wxy.^2+wyx.^2+wyy.^2;
    	%erffc=erffc+w2.*erffci;

	%wi=w((i-1)*np+1:i*np); 
	%wi=pdeintrp(p0,t0,wi); wi=pdeprtni(p0,t0,wi); 
	%[wx,wy]=pdegrad(p0,t0,wi);
	%w2=wx.^2+wy.^2;
	%erffc=erffc+w2.*erffci;

	erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erff=sqrt(erffcc);

elseif (methode==2) % goal-oriented error estimate on theta
ce=alpha.*pdeintrp(p0,t0,phi./(1+abs(gt)));
[Ke,Me,Fe]=assema(p0,t0,ce,a0,f0);
V=Ke*u;
w=K\V;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,mad);
    end;
	wi=w((i-1)*np+1:i*np);
	[wx,wy]=pdegrad(p0,t0,wi);
	wx=pdeprtni(p0,t0,wx); wy=pdeprtni(p0,t0,wy);
	[wxx,wyx]=pdegrad(p0,t0,wx); [wxy,wyy]=pdegrad(p0,t0,wy);
	w2=wxx.^2+wxy.^2+wyx.^2+wyy.^2;

    erffc=erffc+w2.*(erffci.^2);
end;
erff=sqrt(erffci);

elseif (methode==3) % goal-oriented error estimate on J
erffcc=zeros(1,nt);
for iload=1:nload
u=U(:,iload);
v=V(:,iload);
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	wi=v((i-1)*np+1:i*np);
	[wx,wy]=pdegrad(p0,t0,wi);
	wx=pdeprtni(p0,t0,wx); wy=pdeprtni(p0,t0,wy);
	[wxx,wyx]=pdegrad(p0,t0,wx); [wxy,wyy]=pdegrad(p0,t0,wy);
	w2=wxx.^2+wxy.^2+wyx.^2+wyy.^2;
    	erffc=erffc+w2.*erffci;

% 	wi=v((i-1)*np+1:i*np); 
% 	wi=pdeintrp(p0,t0,wi); wi=pdeprtni(p0,t0,wi); 
% 	[wx,wy]=pdegrad(p0,t0,wi);
% 	w2=wx.^2+wy.^2;
% 	erffc=erffc+w2.*erffci;

	%erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erff=sqrt(erffcc);

elseif (methode==4) % residual error estimate for u and v
% direct
erffcc=zeros(1,nt);
for iload=1:nload
u=U(:,iload);
w=-u;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	
	erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erffccd=erffcc;
% adjoint
erffcc=zeros(1,nt);
for iload=1:nload
u=V(:,iload);
w=-u;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	
	erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erffcca=erffcc;

erff=sqrt(erffccd+erffcca);


end;

%figure(3); clf; pdesurf(p0,t0,erffc);


% figure(3); clf; pdesurf(p0,t0,erffc(1,:));
% figure(4); clf; pdesurf(p0,t0,erffc(2,:));
% erffc=sqrt(erffc(1,:).^2+erffc(2,:).^2);

% alphar=(phi<0);
% alphareg=(creg*K1+M1)\(M1*alphar);
% erffp=pdejmps(p0,t0,creg,1,alphar,alphareg,0,1,mad);
% erff=erffc.^2+penalisation*mureg.^2*erffp.^2;


%erff=erffc.*alpha;
%erff=erffc;
%figure(6); clf; pdesurf(p0,t0,erff);
[erffs,is]=sort(erff','descend');
thr=erffs(ceil(nt*frad));
ir=find(erff>thr*0.99)';
%ir=is(1:ceil(nt*frad));
%ir=is(1:ceil(nt*frad/2)*2);

%iraf=union(irp,ir);
%iraf=irp;
iraf=ir;
%figure(3); clf; pdeplot(p0,e0,t0,'xydata',alpha,'xystyle','flat','colorbar','off');
%figure(4); clf; pdesurf(p0,t0,alpha);
%iraf=find(alpha>eps)';

wmp=pdeprtni(p0,t0,wm');
phiwm=[phi,wmp];
[p,e,t,phiwm]=refinemesh(g,p0,e0,t0,phiwm,iraf,'regular');
phi=phiwm(:,1); wmp=phiwm(:,2); wm=pdeintrp(p,t,wmp)';
