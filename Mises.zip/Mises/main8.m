% Generic program for compliance minimization

clear all;
tinit=cputime;
% load data
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax]=mast;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug]=viaduc4;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug]=viaduc7;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever;
%%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever2();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax]=bridge;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=bridge3;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,wini,smax,pasini,mucomp,colimis]=beamL();
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=pont;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=console;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=ponth;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=cantileverp;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe1;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe3;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe4;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe5; % L
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe6; % U
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe7;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe8;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe9; % S
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe10; % alpha
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe12; % X
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=cantileverM; 
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=tableM2; 
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=LM;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=UM;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=bridgeM6;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beamM;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=michell;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=crack;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=crack2;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beam2;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=lego;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=mastM; % Mast
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=mastM1;
[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=LM2; % L Mises
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=bridgeM7;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beamI; % I
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beamplus;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=maillon; % Sarco

eps=1e-3; % density of the weak material
fpause=1; % breaks frequency
frad=0.02; % fraction of triangles refined
mad=1; % M for adaption
mal=100; % alpha.^mal for sm2
malx=0; % alpha.^(mal*malx) for smax2
tolJ1=1e-4; tolJ2=1e-5; % tolerance
thetaraf=5*pi/180; toltheta=(1e-3)*pi/180;
tolcomp=0.1;
pp=1; %pp=gamma; 
%cogamma=1.25; npsi=200; load psitab200-2.mat;
%cogamma=2; npsi=400; load psitab400-2.mat;
%cogamma=1.5; npsi=100; load psitab100-1.mat;
cogamma=1.5; npsi=200; load psitab200-3.mat;

% Data initialization
p0=p; e0=e; t0=t;
pini=p; eini=e; tini=t;
np0=size(p0,2);
a0=zeros(4,1); c0=fairecref(lambda,mu); f0=zeros(2,1);
bm=fairebref(lambda,mu);
%a0=0; c0=1; f0=0;
nt=size(t,2); np=size(p,2);
nload=size(iload,2);
[K1,M1,F1]=assema(p,t,1,1,1);
[ar,A1,A2,A3]=pdetrg(p,t); Ma=0;%Ma=sparse(diag(ar));
[Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli);
Mg=M1; W=speye(np,np);

wm=0; smax=0;
%mucomp=1;mulag=0;
%mulag=1;mucomp=1/100;
pasini=1;
colimis=0;
%airemax=0.5;
%paslag=50;
%compmax=80;
%pascomp=1/10000;

Mps=M1+csn*K1; Mpsini=Mps;
phi=phi0;
%phi=Mps\(M1*phi);
phi=phi./sqrt(dot(Mps*phi,phi));
k=1;
niter=0;
penalisation=0;
nbraf=0;
%wmp=wini; wmpoldp=wmp; phiold=phi;
%wm=pdeintrp(p,t,wmp)';
J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp,ar);
%pause;
%J=J+penalisation*mureg*reg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
Jold=J;
Jminold=-1e99; 
pasm=pasini;
histoJ=[];  histotheta=[]; histoJc=[]; histoaire=[]; histomulag=[]; histocomp=[];
%[S11,S12,S22]=faireS(p,e,t,lambda,mu);
[Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
%Ml=real((speye(np)+colimis*(M1\K1)));
Ml=M1+colimis*K1;
thetaold=0; theta=0;
nup=10; nupq=1;
%vpsi=calculepsiM(npsi,pp);
%psitab=fairepsitab(npsi);
gamma0=gamma;

vpsi=reshape(psitab(:,1),npsi+1,npsi+1);

% Main loop
while 1<2
    %if (J>=Jminold&abs(J-Jold)<tolJ1*abs(Jold)|abs(Jminold-Jold)<tolJ2*abs(Jold))&niter>1
    %if (abs(J-Jold)<tolJ2*abs(Jold))&niter>1
    if (abs(J-Jold)<tolJ2*abs(Jold))&(niter>=0)&(abs(theta-thetaold)<toltheta)
        if (theta>thetaraf) %&(np<6000)
            choix='r'; disp(['Refining']);
            disp(['Number of nodes : ',num2str(np)]);
        %elseif (norm(max(compliance-compmax,0),2)/norm(compmax,2)>tolcomp)|(niter~=floor(niter/10))
        elseif (nup/nupq~=floor(nup/nupq))   
            choix='u'; disp(['Updating']);
        else
        figure(3); clf;
alpha=fairealpha(phi,p,t,np,eps);
pdeplot(p,e,t,'xydata',1-alpha,'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); axis image; box on;
        disp(['J= ',num2str(J),', Jold= ',num2str(Jold),', Jminold= ',num2str(Jminold)]);
        
        disp(['Number of nodes : ',num2str(np)]);
        disp(['Number of iterations : ',num2str(niter)]);

        %if abs(Jminold-Jold)<tolJ2*Jold
            choix=input('Type s to stop, r to refine, u to update: ','s');
        %else
        %    choix='u';
        %end;
        end;
        if (choix=='s')
            tcpu=cputime-tinit;
            disp(['CPU time elapsed : ',num2str(tcpu)]);
            break;
        elseif (choix=='r')
            
            alpha=fairealpha(phi,p,t,np,eps);
            [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
            F=F0*ones(1,nload)+Fload;
            K(lfix,:)=Kfix;
            F(lfix,:)=zeros(nfix,nload);
            %F=F0;
            u=K\F;
            %compliance=sum(dot(F,u));
            compliance=dot(F,u);
            
            %Jc=compliance+mulag*aire;
            
    [ar,a1,a2,a3]=pdetrg(p,t);
    %aire=dot(F1,(phi<0));
aire=sum(ar.*alpha);

s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;

%            [ux,uy]=pdegrad(p,t,u); [vx,vy]=pdegrad(p,t,v);
%tt=0.5*(ux.^2+uy.^2);
tt=2*tt/gmax^2;
k1=gamma*(2/gmax^2)*penalisation1(tt,pp);
%beta=(alpha>0.99);
beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;
%k1p=pdeprtni(p,t,k1);
%Fad=F+[k1p;k1p].*(K*u);
[Ka,Ma,Fa]=assema(p,t,bm*(beta.*k1),a0,f0); 
Fad=Ka*u;
%   Maa=sparse(diag(ar.*(alpha.^mal).*k1));
%    Fad=2*S11'*(Maa*((S11*u)))+2*S22'*(Maa*((S22*u)))-S22'*(Maa*((S11*u)))-S11'*(Maa*((S22*u)))+6*S12'*(Maa*((S12*u)));
v=-K\Fad;

            wmp=0;
            gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx,gmax,gamma,pp,npsi,vpsi,nu,E);
            gr=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            gtm=gt+mureg*penalisation*gr;
            gtr=precong(gtm,K1,M1,p,t);
            gtl=Mps\(M1*gtr);
            ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
            
            p0=p; e0=e; t0=t;
            
                [p,e,t,phi,wmp]=refinemeshad2(g,p,e,t,phi,ddt,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gtm,wmp,u,v);
                

                figure(2); clf; pdemesh(p,e,t);
                [Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
                alpha=fairealpha(phi,p,t,np,eps);
                hold on; pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); hold off;
                %p0=p; e0=e; t0=t;
                %[p,e,t]=refinemesh(g,p0,e0,t0);
                np=size(p,2); nt=size(t,2); k=1;
                [K1,M1,F1]=assema(p,t,1,1,1);
		%[Ar,A1,A2,A3]=pdetrg(p,t); Ma=sparse(diag(Ar));
		%[S11,S12,S22]=faireS(p,e,t,lambda,mu);
                %W2=faireW2(p,e,t,p0,e0,t0); W=W*W2;
                Mps=M1+csn*K1;
                %phi=W'*phi;
                phi=phi./sqrt(dot(Mps*phi,phi));
                %k=1;
%ifixy=find((abs(p(1,:))>0.8) & (p(2,:)==0)); % FOR THE BRIDGE
                %[floadx,floady,nappl,iappli,iload]=fairefload(p,nload);
                [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli);
                
         
                wmpold=wmp; phiold=phi;
                pold=p; eold=e; told=t;
                
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    %F=F0;
    u=K\F;
    
    compliance=dot(F,u);

    [ar,a1,a2,a3]=pdetrg(p,t);
    %aire=dot(F1,(phi<0));
    aire=sum(ar.*alpha);
    s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;
%[ux,uy]=pdegrad(p,t,u);
%tt=0.5*(ux.^2+uy.^2);
tt=2*tt/gmax^2;
%beta=(alpha>0.99);
beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;

                
                disp(['Mesh refined, J=',num2str(J)]);
                Jold=J;
                %Jminold=J-0.5*abs(J); 
                Jminold=J-5*abs(J); % !!!!!!!!!!!!!!!!
                pasm=pasini;
                
                Ml=M1+colimis*K1;
                %[S11,S12,S22]=faireS(p,e,t,lambda,mu);
                
        elseif (choix=='p')
            penalisation=1;
            
        elseif (choix=='u')
            pp=cogamma^nup; nup=nup+1;
            %gamma=gamma0/penalisation0(1,pp);
                aire=dot(F1,(phi<0));
            
%            ddmu=(max(mucomp+baug*(compliance-compmax),0)-mucomp)/baug;
%            mucomp=max([zeros(1,length(mucomp));mucomp+pascomp*(ddmu)]);
% gamma=gamma+1;
% pp=pp+1;
            %vpsi=calculepsiM2(npsi,pp);
            ncp=size(psitab,2); ncol=min(nup,ncp);
            vpsi=reshape(psitab(:,ncol),npsi+1,npsi+1);
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
 
    %F=F0;
    u=K\F;
    
    compliance=dot(F,u);
    [ar,a1,a2,a3]=pdetrg(p,t);
    aire=dot(F1,(phi<0));
    aire=sum(ar.*alpha);
    s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;
%[ux,uy]=pdegrad(p,t,u);
%tt=0.5*(ux.^2+uy.^2);
tt=2*tt/gmax^2;
%beta=(alpha>0.99);
beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
Jold=mucomp*compliance+mulag*aire+gamma*pen;

    
    %Jold=compliance+mulag*aire;

        k=1;
        end;
    

    end;
    
    
    alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    %F=F0;
    u=K\F;
    
    compliance=dot(F,u);
    
    %J=dot(mucomp,compliance)+mulag*aire;
    
    [ux,uy]=pdegrad(p,t,u); 
    
    s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;
%tt=0.5*(ux.^2+uy.^2);
tt=2*tt/gmax^2;
%figure(3); clf; pdeplot(p,e,t,'xydata',tt,'xystyle','flat','colorbar','off');
%tt1=(tt>1); figure(4); clf; pdeplot(p,e,t,'xydata',tt1,'xystyle','flat','colorbar','off');
[ar,a1,a2,a3]=pdetrg(p,t);
%aire=dot(F1,(phi<0));
aire=sum(ar.*alpha);
%[ux,uy]=pdegrad(p,t,u);
%tt=0.5*alpha.*(ux.^2+uy.^2);
%tt=2*tt/gmax^2;
%figure(5); clf; pdeplot(p,e,t,'xydata',penalisation0(tt),'xystyle','flat','colorbar','off');
%beta=(alpha>0.99);
beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;

%k1=gamma*(2/gmax^2).*penalisation1(tt,pp);
k1=(2/gmax^2).*penalisation1(tt,pp);
%k1p=pdeprtni(p,t,k1);
%[Ka,Fa]=assempde(b,p,e,t,beta.*c0.*k1,a0,f0); 
[Ka,Ma,Fa]=assema(p,t,bm*(beta.*k1),a0,f0); 
%[Ka,Ma,Fa]=assema(p,t,bm*(alpha.*chi.*k1),a0,f0); 
%Fad=mucomp*F+Ka*u;
%v=-K\Fad;
%vs=K\(Ka*u);
    %Maa=sparse(diag(ar.*(alpha.^mal).*k1));
    %Fad=2*S11'*(Maa*((S11*u)))+2*S22'*(Maa*((S22*u)))-S22'*(Maa*((S11*u)))-S11'*(Maa*((S22*u)))+6*S12'*(Maa*((S12*u)));
    %beta=alpha.^mal;
    %chi=(t(4,:)==1); beta=beta.*chi;
%    co=(ar.*beta.*k1)';
%    Fad=2*S11'*(co.*(S11*u))+2*S22'*(co.*(S22*u))-S22'*(co.*(S11*u))-S11'*(co.*(S22*u))+6*S12'*(co.*(S12*u));
Fad=Ka*u;
%%Fad=pdeintrp(p,t,Fad); Fad=pdeprtni(p,t,beta.*Fad);
vs=K\Fad;
    %figure(4); clf; pdesurf(p,t,Fad(np+1:2*np)); pause;


v=-(mucomp*u+gamma*vs);

    gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx,gmax,gamma,pp,npsi,vpsi,nu,E);
  
    disp(['J = ', num2str(J)]);
    histoJ=[histoJ,J]; 
    %histoJc=[histoJc,Jc]; 
    %gtf=W'*(Mpsini\(W*(Mps*gt))); % filtering
    gtf=gt;
    gtr=precong(gtf,K1,M1,p,t); %preconditioning
    
    %gtl=Mps\(M1*gtr);
    gtl=gtr;
    
    ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
    pscal=dot(Mps*ddt,phi);
    thetaold=theta;
    theta=real(acos(pscal));
    histotheta=[histotheta,theta];
    histoaire=[histoaire,aire];
    %histomulag=[histomulag,mulag];
    %histomulag=[histomulag,mucomp'];
    histomulag=[histomulag,pp];
    histocomp=[histocomp,compliance'];
disp(['Volume : ',num2str(aire)]);
disp(['Compliance : ',num2str(compliance)]);
disp(['Maxi stress : ', num2str(sqrt(max(beta.*tt)))]);
Q=dot(ar,sheav(beta.*tt))/aire;
disp(['Q : ',num2str(Q)]);
    
    figure(1); clf; 
    subplot(4,2,1); pdesurf(p,t,phi); title('Levelset function');
    subplot(4,2,2); pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); title('Current design'); axis image; axis off;
    subplot(4,2,3); pdesurf(p,t,gt); title('Topological gradient');
    %subplot(4,2,4); pdesurf(p,t,gr); title('Regularization');
    subplot(4,2,4); pdesurf(p,t,gtr); title('Regularized Topological gradient');
    %subplot(4,2,6); pdesurf(p,t,gtl); title('Filtered topological gradient');
    subplot(4,2,5); plot([0:niter], histoJ,'r-'); title('Lagrange functional');
    %subplot(4,2,5); plot([0:niter], histocomp,'r-',[0:niter], compmax'*ones(1,niter+1),'b--'); title('Compliance');
    subplot(4,2,6); plot([0:niter], histotheta*180/pi,'r-'); title('Theta');
    %subplot(4,2,7); pdeplot(p,e,t,'xydata',smf,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Von Mises stress'); axis image; axis off;
    %subplot(4,2,8); pdeplot(p,e,t,'xydata',wm,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Lagrange multiplier'); axis image; axis off;
    subplot(4,2,7); %plot([0:niter], histoaire,'r-'); title('Volume'); 
    pdeplot(p,e,t,'xydata',alpha.^2.*sm2,'xystyle','flat','colorbar','off'); title('Von Mises stress'); axis image; axis off;
    subplot(4,2,8); plot([0:niter], histomulag,'r-'); title('p'); %title('Lagrange multiplier'); 
    pause(0.1); %pause;
    
    Jold=J;
    [phi,J,k]=rlin6(phi,ddt,J,b,p,e,t,np,c0,a0,f0,F1,M1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,k,Mps,mureg,creg,penalisation,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp);
    
    niter=niter+1;
    if (niter>2000)
        break;
    end;
end;