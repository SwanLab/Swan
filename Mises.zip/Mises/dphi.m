function f=dphi(p,t);
f=(1+t.^p).^(1/p-1).*t.^(p-1);