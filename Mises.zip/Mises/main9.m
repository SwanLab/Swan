% Generic program for compliance minimization

clear all;
tinit=cputime;

%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=mastM1; % Mast
[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=LM3; % L Mises
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=bridgeM7;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beamI2; % I
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beamplus;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=michell2;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=maillon2; % Sarco
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=UM2;
%[mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=fraise;

eps=1e-3; % density of the weak material
fpause=1; % breaks frequency
frad=0.02; % fraction of triangles refined
mad=1; % M for adaption
mal=100; % alpha.^mal for sm2
malx=0; % alpha.^(mal*malx) for smax2
tolJ1=1e-4; tolJ2=1e-5; % tolerance
thetaraf=10*pi/180; toltheta=(1e-3)*pi/180;
tolcomp=0.1;
pp=1; %pp=gamma; 
%cogamma=1.5; npsi=200; load psitab200-3.mat;
cogamma=2; npsi=200; load psitab200-4.mat;

% Data initialization
p0=p; e0=e; t0=t;
pini=p; eini=e; tini=t;
np0=size(p0,2);
a0=zeros(4,1); c0=fairecref(lambda,mu); f0=zeros(2,1);
bm=fairebref(lambda,mu);
%a0=0; c0=1; f0=0;
nt=size(t,2); np=size(p,2);
nload=size(iload,2);
[K1,M1,F1]=assema(p,t,1,1,1);
[ar,A1,A2,A3]=pdetrg(p,t); Ma=0;%Ma=sparse(diag(ar));
[Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli);
Mg=M1; W=speye(np,np);

wm=0; smax=0;

pasini=1;
colimis=0;

Mps=M1+csn*K1; Mpsini=Mps;
phi=phi0;
%phi=Mps\(M1*phi);
phi=phi./sqrt(dot(Mps*phi,phi));
k=1;
niter=0;
penalisation=0;
nbraf=0;

J=critere(phi,b,p,e,t,np,c0,a0,f0,F1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,M1,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp,ar);

Jold=J;
Jminold=-1e99; 
pasm=pasini;
histoJ=[];  histotheta=[]; histoJc=[]; histoaire=[]; histomulag=[]; histocomp=[]; histoav=[];

[Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';

Ml=M1+colimis*K1;
thetaold=0; theta=0;
nup=5; nupq=1;

gamma0=gamma;

vpsi=reshape(psitab(:,1),npsi+1,npsi+1);

% Main loop
while 1<2
    
    if (abs(J-Jold)<tolJ2*abs(Jold))&(niter>=0)&(abs(theta-thetaold)<toltheta)
        if (theta>thetaraf) %&(np<6000)
            choix='r'; disp(['Refining']);
            disp(['Number of nodes : ',num2str(np)]);
        %elseif (norm(max(compliance-compmax,0),2)/norm(compmax,2)>tolcomp)|(niter~=floor(niter/10))
        elseif (nup/nupq~=floor(nup/nupq))   
            choix='u'; disp(['Updating']);
        else
        figure(3); clf;
alpha=fairealpha(phi,p,t,np,eps);
pdeplot(p,e,t,'xydata',1-alpha,'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); axis image; box on;
        disp(['J= ',num2str(J),', Jold= ',num2str(Jold),', Jminold= ',num2str(Jminold)]);
        
        disp(['Number of nodes : ',num2str(np)]);
        disp(['Number of iterations : ',num2str(niter)]);

        %if abs(Jminold-Jold)<tolJ2*Jold
            choix=input('Type s to stop, r to refine, u to update: ','s');
        %else
        %    choix='u';
        %end;
        end;
        if (choix=='s')
            tcpu=cputime-tinit;
            disp(['CPU time elapsed : ',num2str(tcpu)]);
            break;
        elseif (choix=='r')
            
            alpha=fairealpha(phi,p,t,np,eps);
            [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
            F=F0*ones(1,nload)+Fload;
            K(lfix,:)=Kfix;
            F(lfix,:)=zeros(nfix,nload);
            %F=F0;
            u=K\F;
            %compliance=sum(dot(F,u));
            compliance=dot(F,u);
            
            %Jc=compliance+mulag*aire;
            
    [ar,a1,a2,a3]=pdetrg(p,t);
    %aire=dot(F1,(phi<0));
aire=sum(ar.*alpha);

s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;


tt=2*tt/gmax^2;
k1=gamma*(2/gmax^2)*penalisation1(tt,pp);

beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;

[Ka,Ma,Fa]=assema(p,t,bm*(beta.*k1),a0,f0); 
Fad=Ka*u;

v=-K\Fad;

            wmp=0;
            gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx,gmax,gamma,pp,npsi,vpsi,nu,E);
            gr=greg(phi,b,p,e,t,np,F1,K1,M1,eps,nt,creg);
            gtm=gt+mureg*penalisation*gr;
            gtr=precong(gtm,K1,M1,p,t);
            gtl=Mps\(M1*gtr);
            ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
            
            p0=p; e0=e; t0=t;
            
                [p,e,t,phi,wmp]=refinemeshad2(g,p,e,t,phi,ddt,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gtm,wmp,u,v);
                

                figure(2); clf; pdemesh(p,e,t);
                [Q,G,H,R]=assemb(b,p,e); Hs=sum(abs(H),1); idir=find(Hs>0)';
                alpha=fairealpha(phi,p,t,np,eps);
                hold on; pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); hold off;
                
                np=size(p,2); nt=size(t,2); k=1;
                [K1,M1,F1]=assema(p,t,1,1,1);
		
                Mps=M1+csn*K1;
                
                phi=phi./sqrt(dot(Mps*phi,phi));
                
                [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli);
                
         
                wmpold=wmp; phiold=phi;
                pold=p; eold=e; told=t;
                
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    
    u=K\F;
    
    compliance=dot(F,u);

    [ar,a1,a2,a3]=pdetrg(p,t);
    
    aire=sum(ar.*alpha);
    s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;

tt=2*tt/gmax^2;

beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;

                
                disp(['Mesh refined, J=',num2str(J)]);
                Jold=J;
                
                Jminold=J-5*abs(J); % !!!!!!!!!!!!!!!!
                pasm=pasini;
                
                Ml=M1+colimis*K1;
                
                
        elseif (choix=='p')
            penalisation=1;
            
        elseif (choix=='u')
            pp=cogamma^nup; nup=nup+1;
            %gamma=gamma0/penalisation0(1,pp);
                aire=dot(F1,(phi<0));
            

            ncp=size(psitab,2); ncol=min(nup,ncp);
            vpsi=reshape(psitab(:,ncol),npsi+1,npsi+1);
                alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
 
    
    u=K\F;
    
    compliance=dot(F,u);
    [ar,a1,a2,a3]=pdetrg(p,t);
    aire=dot(F1,(phi<0));
    aire=sum(ar.*alpha);
    s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;
tt=2*tt/gmax^2;

beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
Jold=mucomp*compliance+mulag*aire+gamma*pen;

    

        k=1;
        end;
    

    end;
    
    
    alpha=fairealpha(phi,p,t,np,eps);
    [K,F0]=assempde(b,p,e,t,c0*alpha,a0,f0); 
    F=F0*ones(1,nload)+Fload;
    K(lfix,:)=Kfix;
    F(lfix,:)=zeros(nfix,nload);
    u=K\F;
    
    compliance=dot(F,u);
    
    
    [ux,uy]=pdegrad(p,t,u); 
    
    s=stress(u,p,t,nt,lambda,mu);
sa=s(1,:); sb=s(3,:); sc=s(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;

tt=2*tt/gmax^2;

[ar,a1,a2,a3]=pdetrg(p,t);

aire=sum(ar.*alpha);

beta=alpha.^mal;
chi=(t(4,:)==1); beta=beta.*chi;
pen=dot(ar,beta.*penalisation0(tt,pp));
J=mucomp*compliance+mulag*aire+gamma*pen;

k1=(2/gmax^2).*penalisation1(tt,pp);

[Ka,Ma,Fa]=assema(p,t,bm*(beta.*k1),a0,f0); 

Fad=Ka*u;

vs=K\Fad;
    


v=-(mucomp*u+gamma*vs);

    gt=gratopo(u,v,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx,gmax,gamma,pp,npsi,vpsi,nu,E);
  
    disp(['J = ', num2str(J)]);
    histoJ=[histoJ,J]; 
    
    gtf=gt;
    gtr=precong(gtf,K1,M1,p,t); %preconditioning
    
    %gtl=Mps\(M1*gtr);
    gtl=gtr;
    
    ddt=-gtl./sqrt(dot(Mps*gtl,gtl));
    pscal=dot(Mps*ddt,phi);
    thetaold=theta;
    theta=real(acos(pscal));
    histotheta=[histotheta,theta];
    histoaire=[histoaire,aire];
    
    histomulag=[histomulag,pp];
    histocomp=[histocomp,compliance'];
    iv=find(beta.*tt>1); av=sum(ar(iv));
    histoav=[histoav,av];
disp(['Volume : ',num2str(aire)]);
disp(['Compliance : ',num2str(compliance)]);
disp(['Maxi stress : ', num2str(sqrt(max(beta.*tt)))]);
Q=dot(ar,sheav(beta.*tt))/aire;
disp(['Q : ',num2str(Q)]);
    
    figure(1); clf; 
    subplot(4,2,1); pdesurf(p,t,phi); title('Levelset function');
    subplot(4,2,2); pdeplot(p,e,t,'xydata',alpha,'xystyle','flat','colorbar','off'); title('Current design'); axis image; axis off;
    subplot(4,2,3); pdesurf(p,t,gt); title('Topological gradient');
    %subplot(4,2,4); pdesurf(p,t,gr); title('Regularization');
    subplot(4,2,4); pdesurf(p,t,gtr); title('Regularized Topological gradient');
    %subplot(4,2,6); pdesurf(p,t,gtl); title('Filtered topological gradient');
    subplot(4,2,5); plot([0:niter], histoJ,'r-'); title('Lagrange functional');
    %subplot(4,2,5); plot([0:niter], histocomp,'r-',[0:niter], compmax'*ones(1,niter+1),'b--'); title('Compliance');
    subplot(4,2,6); plot([0:niter], histotheta*180/pi,'r-'); title('Theta');
    %subplot(4,2,7); pdeplot(p,e,t,'xydata',smf,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Von Mises stress'); axis image; axis off;
    %subplot(4,2,8); pdeplot(p,e,t,'xydata',wm,'xystyle','flat','colormap','pink','xygrid','off','colorbar','on'); title('Lagrange multiplier'); axis image; axis off;
    subplot(4,2,7); %plot([0:niter], histoaire,'r-'); title('Volume'); 
    pdeplot(p,e,t,'xydata',alpha.^2.*sm2,'xystyle','flat','colorbar','off'); title('Von Mises stress'); axis image; axis off;
    subplot(4,2,8); plot([0:niter], histomulag,'r-'); title('p'); %title('Lagrange multiplier'); 
    pause(0.1); %pause;
    
    Jold=J;
    [phi,J,k]=rlin6(phi,ddt,J,b,p,e,t,np,c0,a0,f0,F1,M1,K1,mulag,eps,nload,Fload,Kfix,lfix,nfix,nt,lambda,mu,k,Mps,mureg,creg,penalisation,smax,wm,Ma,mucomp,mal,malx,baug,compmax,gamma,gmax,pp);
    
    niter=niter+1;
    if (niter>2000)
        break;
    end;
end;