function gtr=precond(gtr)
    gtr=sign(gtr).*log(1+abs(gtr));