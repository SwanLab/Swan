figure(3); clf; 
pdeplot(p,e,t,'xydata',(phi>0),'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); 
hold on;
X=[-0.8,-0.3,-0.3,+0.3,+0.3,+0.8,+0.8,+0.3,+0.3,-0.3,-0.3,-0.8];
Y=[+0.2,+0.2,+1.0,+1.0,+0.2,+0.2,-0.2,-0.2,-1.0,-1.0,-0.2,-0.2];
plot(X,Y,'k-');
hold off;
axis image; axis off;
