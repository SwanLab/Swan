function Sm=faireSm2(p,e,t,lambda,mu)
[ar,g1x,g1y,g2x,g2y,g3x,g3y]=pdetrg(p,t);
nt=size(t,2); np=size(p,2);
Smx=zeros(nt,np); Smy=zeros(nt,np);
id=[1 0 1]';

% x

e1=[g1x;(g1x+g1y)/2;zeros(1,nt)];
s1=lambda*id*(e1(1,:)+e1(3,:))+2*mu*e1;
sa=s1(1,:); sb=s1(3,:); sc=s1(2,:); 
sm1=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2);
sm1d=diag(sm1);
%sm1p=pdeprtni(p,t,sm1d);
t1=t(1,:);
Smx(:,t1)=sm1d;
%Smx(:,t1)=Smx(:,t1)+sm1p;

e2=[g2x;(g2x+g2y)/2;zeros(1,nt)];
s2=lambda*id*(e2(1,:)+e2(3,:))+2*mu*e2;
sa=s2(1,:); sb=s2(3,:); sc=s2(2,:); 
sm2=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2);
sm2d=diag(sm2);
%sm2p=pdeprtni(p,t,sm2d);
t2=t(2,:);
Smx(:,t2)=sm2d;
%Smx(:,t2)=Smx(:,t2)+sm2p;

e3=[g3x;(g3x+g3y)/2;zeros(1,nt)];
s3=lambda*id*(e3(1,:)+e3(3,:))+2*mu*e3;
sa=s3(1,:); sb=s3(3,:); sc=s3(2,:); 
sm3=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2);
sm3d=diag(sm3);
%sm3p=pdeprtni(p,t,sm3d);
t3=t(3,:);
Smx(:,t3)=sm3d;
%Smx(:,t3)=Smx(:,t3)+sm3p;

Smx=pdeprtni(p,t,Smx')';

% y

e1=[zeros(1,nt);(g1x+g1y)/2;g1y];
s1=lambda*id*(e1(1,:)+e1(3,:))+2*mu*e1;
sa=s1(1,:); sb=s1(3,:); sc=s1(2,:); 
sm1=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2);
sm1d=diag(sm1);
%sm1p=pdeprtni(p,t,sm1d);
t1=t(1,:);
Smy(:,t1)=sm1d;
%Smy(:,t1)=Smy(:,t1)+sm1p;

e2=[zeros(1,nt);(g2x+g2y)/2;g2y];
s2=lambda*id*(e2(1,:)+e2(3,:))+2*mu*e2;
sa=s2(1,:); sb=s2(3,:); sc=s2(2,:); 
sm2=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2);
sm2d=diag(sm2);
%sm2p=pdeprtni(p,t,sm2d);
t2=t(2,:);
Smy(:,t2)=sm2d;
%Smy(:,t2)=Smy(:,t2)+sm2p;

e3=[zeros(1,nt);(g3x+g3y)/2;g3y];
s3=lambda*id*(e3(1,:)+e3(3,:))+2*mu*e3;
sa=s3(1,:); sb=s3(3,:); sc=s3(2,:); 
sm3=sqrt(sa.^2+sb.^2-sa.*sb+3*sc.^2);
sm3d=diag(sm3);
%sm3p=pdeprtni(p,t,sm3d);
t3=t(3,:);
Smy(:,t3)=sm3d;
%Smy(:,t3)=Smy(:,t3)+sm3p;

Smy=pdeprtni(p,t,Smy')';

% assembling

Sm=[Smx Smy];