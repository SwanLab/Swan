function e=strain(u,p,t)
[ux,uy]=pdegrad(p,t,u);
e=[ux(1,:);(ux(2,:)+uy(1,:))/2;uy(2,:)];