function [floadx,floady,nappl,iappli,iload]=fairefload(p,nload)

iappli=find(p(2,:)==0 & abs(p(1,:))<0.99); 
iload=(ones(nload,1)*iappli)';
nappl=length(iappli);
floadx=zeros(nappl,nload);
% floady=zeros(nappl,nload);
% for i=1:nload
% floady(:,i)=max(0.2-abs(p(1,iappli(i))-p(1,iappli)),0);
% floady(:,i)=-floady(:,i)/sum(floady(:,i));
% end;
floady=-eye(nload);