function [Fload,Kfix,nfix,lfix]=faireBC(np,nload,iload,floadx,floady,ifixx,ifixy,iappli)
Fload=zeros(2*np,nload);
for i=1:nload
    Fload(iload(:,i),i)=floadx(:,i);
    Fload(np*ones(size(iload,1),1)+iload(:,i),i)=floady(:,i);
    %Fload(iappli(i),i)=floadx(:,i);
    %Fload(np+iappli(i),i)=floady(:,i);
end;
nfix=length(ifixx)+length(ifixy);
lfix=zeros(nfix,1);
Kfix=zeros(nfix,2*np);
for j=1:length(ifixx)
    jfix=ifixx(j);
    Kfix(j,jfix)=1; lfix(j)=jfix;
end;
for j=1:length(ifixy)
    jfiy=np+ifixy(j);
    Kfix(length(ifixx)+j,jfiy)=1; lfix(length(ifixx)+j)=jfiy;
end;