function sh=sheav(s);
a=1.5;
sh=(s-1)/(a-1);
sh=max(sh,0);
sh=min(sh,1);