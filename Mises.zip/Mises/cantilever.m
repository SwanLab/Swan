function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg]=cantilever()

load geocant.mat; % Load geometry
mulag=100; % Lagrange multiplier for the weight
E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1
%mureg=500; creg=0.05^2;
%mureg=0; creg=0.1^2;
lreg=0.05; creg=lreg^2;
mupe=1; mureg=mupe*4/lreg;

% Mesh Generation
%[p,e,t]=poimesh(g,32,16);
[p,e,t]=poimesh(g,16,8);
%[p,e,t]=poimesh(g,8,4);
[p,e,t]=refinemesh(g,p,e,t,'longest');
%[p,e,t]=refinemesh(g,p,e,t);
%[p,e,t]=refinemesh(g,p,e,t);
np0=size(p,2);
nraf=1; % Mesh refinement for the computation

% Load
% iload=[find((p(1,:)==0) & (p(2,:)==0)),find((p(1,:)==-0.5) & (p(2,:)==0)),find((p(1,:)==0.5) & (p(2,:)==0))];
% floadx=[0,0,0];
% floady=[-1,-1,-1]; % Intensity of the load
% ifixx=[];
% ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));

iload=[find((p(1,:)==2) & (p(2,:)==0))]; % Location of the load
floadx=[[0]];
floady=[[-1]]; % Intensity of the load
ifixx=[];
ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);
%phi0=-(((p(1,:)-1).^2-1^2).*(p(2,:).^2-0.5^2))';
%phi0=ones(np0,1)-2*(abs(p(2,:))<0.25)';
%phi0=ones(np0,1)-2*(abs(p(2,:))<0.1)';