function gt=gratopo(U,V,p,t,np,nt,lambda,mu,mulag,eps,phi,wm,smax,mucomp,mal,malx,gmax,gamma,pp,npsi,vpsi,nu,E)
k=(lambda+3*mu)/(lambda+mu);
alpha=fairealpha(phi,p,t,np,eps);

u=U; v=V;
%[ux,uy]=pdegrad(p,t,u); [vx,vy]=pdegrad(p,t,v);
%gu2=ux.^2+uy.^2;

ev=strain(v,p,t);
su=stress(u,p,t,nt,lambda,mu); 
suev=ev(1,:).*su(1,:)+2*ev(2,:).*su(2,:)+ev(3,:).*su(3,:);
trev=ev(1,:)+ev(3,:);
trsu=su(1,:)+su(3,:);

gt0=-((k+1)/2)*(2*suev.*alpha-((k-2)/(k-1))*trsu.*trev.*alpha);
gtinf=((1/k)*(k+1)/2)*(2*suev.*alpha+((k-2)/2)*trsu.*trev.*alpha);
gt=alpha.*gt0-(1-alpha).*gtinf;

%figure(3); clf; pdesurf(p,t,gt);

sa=su(1,:); sb=su(3,:); sc=su(2,:); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises
tt=sm2;

%alpha0=alpha; beta0=alpha0.^mal;
%alpha1=(alpha<0.5); beta1=alpha1.^mal;
% r=(alpha1-alpha0)./(alpha1+alpha0);
% 
% tt=0.5*(ux.^2+uy.^2);
beta=alpha.^mal;
%gt=gt.*beta;

chi=(t(4,:)==1); beta=beta.*chi;
tt=2*tt/gmax^2;
k1=(2/gmax^2)*penalisation1(tt,pp);
xi=(1+nu)/(1-nu); eta=(3-nu)/(1+nu);
eu=strain(u,p,t);
sueu=eu(1,:).*su(1,:)+2*eu(2,:).*su(2,:)+eu(3,:).*su(3,:);
treu=eu(1,:)+eu(3,:);
gt=gt-gamma*beta.*k1.*(3*eta/(1+nu)*sueu+(eta*(2*nu-1)/(1-nu^2)+(xi-eta)/(2*(1-nu)))*trsu.*treu);
%gt=gt-gamma*alpha.^mal.*4.*k1.*sm2;

detsu=su(1,:).*su(3,:)-su(2,:).^2;
u1=abs(trsu)*sqrt(2)/gmax;
u2=sqrt(trsu.^2-4*detsu)*sqrt(2)/gmax;
l1=length(u1); l2=length(u2);
%y1=1-1./log(4*u1+exp(1));
%y2=1-1./log(4*u2+exp(1));
y1=homeoinv(u1); y1=min(y1,0.999);
y2=homeoinv(u2); y2=min(y2,0.999);
ny1=npsi*y1; ny1f=floor(ny1);
ny2=npsi*y2; ny2f=floor(ny2);
a1=ny1-ny1f;
a2=ny2-ny2f;
n1=floor(npsi*y1)+1;
n2=floor(npsi*y2)+1;
%A1=a1'*ones(1,l2);
%A2=ones(l1,1)*a2;

ll=size(vpsi,1);
%vvpsi=vpsi(n1,n2)+A1.*(vpsi(n1+1,n2)-vpsi(n1,n2))+A2.*(vpsi(n1,n2+1)-vpsi(n1,n2));
vvpsi=vpsi(n1+(n2-1)*ll)+a1.*(vpsi(n1+1+(n2-1)*ll)-vpsi(n1+(n2-1)*ll))+a2.*(vpsi(n1+n2*ll)-vpsi(n1+(n2-1)*ll));
gt=gt+gamma*beta.*(vvpsi/pi);
%figure(4); clf; pdesurf(p,t,min(100,pdeprtni(p,t,gamma*beta.*(vvpsi/pi)))); %pause;

susu=su(1,:).^2+2*su(2,:).^2+su(3,:).^2;
gt=gt+0.25*gamma*beta.*k1.*(10*susu-2*trsu.^2);
gt=gt-gamma*beta.*penalisation0(tt,pp);

% 
% tts=npsi*(1-1./log(exp(1)+4*tt));
% nvpsi=floor(tts);
% vvpsi=(1-(tts-nvpsi)).*vpsi(nvpsi+1)+(tts-nvpsi).*vpsi(nvpsi+2);
% 
% beta0=alpha.^mal;
% 
% gt=-2*alpha0.*(ux.*vx+uy.*vy);
% gt=gt-gamma*0.5*beta0.*k1.*gu2;
% gt=gt+gamma*beta0.*(vvpsi/pi);
% gt=gt-gamma*beta0.*penalisation0(tt,pp);

[ar,a1,a2,a3]=pdetrg(p,t);
%i4=find(t(4,:)~=1); gt(i4)=sqrt(dot(ar,gt.^2));

gt=pdeprtni(p,t,gt);

gt=gt-mulag;