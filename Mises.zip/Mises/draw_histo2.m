figure(5); clf; plot([0:niter-1], histoJ,'r-');
figure(6); clf; plot([0:niter-1], histotheta*180/pi,'r-');