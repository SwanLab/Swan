function [p,e,t,phi,wmp]=refinemeshad2(g,p0,e0,t0,phi,dd,frad,Mps,np,nt,c0,a0,f0,eps,b,nload,Fload,lfix,Kfix,nfix,K1,M1,creg,mureg,lambda,mu,mad,penalisation,mulag,gt,wmp,U,V)
methode=4;


alpha=fairealpha(phi,p0,t0,np,eps);


if (methode==1) % residual error estimate
erffcc=zeros(1,nt);
for iload=1:nload
u=U(:,iload);
w=-u;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	

	erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erff=sqrt(erffcc);

elseif (methode==2) % goal-oriented error estimate on theta
ce=alpha.*pdeintrp(p0,t0,phi./(1+abs(gt)));
[Ke,Me,Fe]=assema(p0,t0,ce,a0,f0);
V=Ke*u;
w=K\V;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,mad);
    end;
	wi=w((i-1)*np+1:i*np);
	[wx,wy]=pdegrad(p0,t0,wi);
	wx=pdeprtni(p0,t0,wx); wy=pdeprtni(p0,t0,wy);
	[wxx,wyx]=pdegrad(p0,t0,wx); [wxy,wyy]=pdegrad(p0,t0,wy);
	w2=wxx.^2+wxy.^2+wyx.^2+wyy.^2;

    erffc=erffc+w2.*(erffci.^2);
end;
erff=sqrt(erffci);

elseif (methode==3) % goal-oriented error estimate on J
erffcc=zeros(1,nt);
for iload=1:nload
u=U(:,iload);
v=V(:,iload);
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	wi=v((i-1)*np+1:i*np);
	[wx,wy]=pdegrad(p0,t0,wi);
	wx=pdeprtni(p0,t0,wx); wy=pdeprtni(p0,t0,wy);
	[wxx,wyx]=pdegrad(p0,t0,wx); [wxy,wyy]=pdegrad(p0,t0,wy);
	w2=wxx.^2+wxy.^2+wyx.^2+wyy.^2;
    	erffc=erffc+w2.*erffci;


end;
erffcc=erffcc+erffc;
end;
erff=sqrt(erffcc);

elseif (methode==4) % residual error estimate for u and v
% direct
erffcc=zeros(1,nt);
for iload=1:nload
u=U(:,iload);
w=-u;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	
	erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erffccd=erffcc;
% adjoint
erffcc=zeros(1,nt);
for iload=1:nload
u=V(:,iload);
w=-u;
erffc=zeros(1,nt);
for i=1:2
    erffci=zeros(1,nt);
    for q=1:2
        Aiq=zeros(4,1);
        for j=1:2
            for p=1:2
                aijpq=lambda*(p==q)*(i==j)+mu*((i==p)*(j==q)+(j==p)*(i==q));
                Aiq(j+2*(p-1))=aijpq;
            end;
        end;
        erffci=erffci+pdejmps(p0,t0,Aiq*alpha,0,0,u((q-1)*np+1:q*np),0,1,2).^2;
    end;
	
	erffc=erffc+erffci;
end;
erffcc=erffcc+erffc;
end;
erffcca=erffcc;

erff=sqrt(erffccd+erffcca);

[ar,a1,a2,a3]=pdetrg(p0,t0); %erff=erff.*ar.^0.5;
end;


[erffs,is]=sort(erff'); erffs=flipud(erffs); is=flipud(is);
thr=erffs(ceil(nt*frad));
ir=find(erff>thr*0.99)';

iraf=ir;

[p,e,t,phi]=refinemesh(g,p0,e0,t0,phi,iraf,'regular');
