v=[0:0.01:3];
figure(1); clf; hold on;
y=[];
for p=1:2:30;
for i=1:length(v)
    y(i,p)=V1(v(i),p);
end;
plot(v,y);
end;
hold off;

% npsi=100;
% figure(2); clf; hold on;
% z=[];
% for p=1:10;
%     vpsi=calculepsi(npsi,p);
%     tt=v;
%     tts=npsi*(1-1./log(exp(1)+4*tt));
% nvpsi=floor(tts);
% vvpsi=(1-(tts-nvpsi)).*vpsi(nvpsi+1)+(tts-nvpsi).*vpsi(nvpsi+2);
% plot(v,vvpsi);
% end;
% hold off;