function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax,nu,E]=beamM

load geobeam.mat; % Load geometry

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation

prec=1000;
[p1,e1,t1]=poimesh(g1,10,5); p1=round(prec*p1)/prec;
[p2,e2,t2]=poimesh(g2,10,5); p2=round(prec*p2)/prec;
[p3,e3,t3]=poimesh(g3,5,5); p3=round(prec*p3)/prec;

[b,p,e,t]=raccommode(b1,p1,e1,t1,b2,p2,e2,t2);
[b,p,e,t]=raccommode(b,p,e,t,b3,p3,e3,t3);

g=[g1,g2,g3];
[p,e,t]=refinemesh(g,p,e,t,'longest');
[p,e,t]=refinemesh(g,p,e,t);
[p,e,t]=refinemesh(g,p,e,t);

np0=size(p,2); nraf=0;

%yl=0.1;
%i0=find(p(2,t(1,:))<yl & p(2,t(2,:))<yl & p(2,t(3,:))<yl);
%t(4,i0)=2;

% Load

nload=1; iload=[1]; floadx=[0]; floady=[0]; iappli=[];
[floadx,floady,nappl,iappli,iload]=fairefload(p,nload);
lreg=0.2; creg=lreg^2;
mupe=0; mureg=mupe*4/lreg;

mulag=1;

%mucomp=5e-3*ones(1,nload);
%mucomp=1e-1*ones(1,nload);
compmax=25; %6;%5e-6;
pascomp=2e-3;%5e-4;%e9;
baug=2e-3;%2e-4;

gamma=100; gmax=50;

%mucomp=mucomp/nload; pascomp=pascomp/nload; baug=baug/nload;
mucomp=0.01;

%ifixx=find(abs(p(1,:))==2&p(2,:)==1);
%ifixy=find(abs(p(1,:))==2&p(2,:)==1);
ifixx=[]; ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);