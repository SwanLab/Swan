figure(3); clf; 
pdeplot(p,e,t,'xydata',(phi>0),'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); 
hold on;
X=[-0.1 2 2   -0.1 -0.1 0   0    -0.1 -0.1];
Y=[-0.5 -0.5 0.5 0.5  0.2  0.2 -0.2 -0.2 -0.5];
plot(X,Y,'k-');
hold off;
axis image; axis off;

% figure(4); clf; 
% pdecont(p,t,phi,[0 0]);
% hold on;
% plot(X,Y,'k--');
% hold off;
% axis image; axis off;