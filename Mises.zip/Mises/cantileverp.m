function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli]=cantileverp

load geocantm.mat; % Load geometry
%mulag=100; % Lagrange multiplier for the weight
E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1
%mureg=500; creg=0.05^2;
%mureg=0; creg=0.1^2;
%lreg=0.05; creg=lreg^2;
%mupe=1; mureg=mupe*4/lreg;

% Mesh Generation
%[p,e,t]=poimesh(g,32,16);
%[p,e,t]=poimesh(g,16,8);
%[p,e,t]=poimesh(g,8,4);
%[p,e,t]=poimesh(g,16,16);
%[p,e,t]=poimesh(g,20,20);
[p,e,t]=poimesh(g,32,32);
%[p,e,t]=poimesh(g,40,40);

[p,e,t]=refinemesh(g,p,e,t,'longest');
np0=size(p,2);
nraf=1; % Mesh refinement for the computation


% Load

m=0.3;
%xim=5*pi/180;
%n=40;

% iloadi=find(p(2,:)==1 & abs(p(1,:))<=1); 

nload=64;
%nload=2*n+1;
iload=find((p(1,:)==1) & (p(2,:)==0))*ones(1,nload);

iappli=find((p(1,:)==1) & (p(2,:)==0)); 
%iload=(ones(nload,1)*iappli)';
nappl=length(iappli);
floadx=zeros(nappl,nload);
floady=zeros(nappl,nload);
% for i=-n:n
% floadx(n+i+1)=-1+m*cos(2*i*pi/nload);
% floady(n+i+1)=m*sin(2*i*pi/nload);
% % nf=norm([floadx(i),floady(i)]);
% % floadx(i)=floadx(i)/nf;
% % floady(i)=floady(i)/nf;
% %floadx(n+i+1)=-cos(xim*i/n);
% %floady(n+i+1)=sin(xim*i/n);
% end;
for i=0:nload-1
floadx(i+1)=-1+m*cos(2*i*pi/(nload-1));
floady(i+1)=m*sin(2*i*pi/(nload-1));
end;

% iload=[find((p(1,:)==2) & (p(2,:)==0))]; % Location of the load
% nload=1; iappli=iload;
% floadx=[[0]];
% floady=[[-1]]; % Intensity of the load

%mulag=200;
lreg=0.2; creg=lreg^2;
mupe=0.05; mureg=mupe*4/lreg;
mulag=1;
%mucomp=5e-3*ones(1,nload);
%mucomp=405e-3*ones(1,nload);
mucomp=0.2*ones(1,nload);
compmax=10; %6;%5e-6;
pascomp=10e-3;%81e-4;%5e-4;%5e-4;%e9;
baug=10e-3;%81e-4;%5e-4;%2e-4;
%baug=1e-6;

mucomp=mucomp/nload; pascomp=pascomp/nload; baug=baug/nload;

ifixx=[]; ifixy=[];

% Initialization of the level-set function
phi0=-ones(np0,1);