function y=homeoinv(x)
%y=1-1./(x+1);
alpha=1.6; y=(tanh((x-1)*atanh(alpha-1))+alpha-1)/alpha;