function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug,iappli,gamma,gmax]=pipe5

load geopipe5bis.mat; % Load geometry

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation
prec=1000;
[p1,e1,t1]=poimesh(g1,5,10); p1=round(prec*p1)/prec;
[p2,e2,t2]=poimesh(g2,5,2); p2=round(prec*p2)/prec;
[p3,e3,t3]=poimesh(g3,2,5); p2=round(prec*p2)/prec;

[b0,p0,e0,t0]=raccommode(b1,p1,e1,t1,b2,p2,e2,t2);
[b,p,e,t]=raccommode(b0,p0,e0,t0,b3,p3,e3,t3);
g=[g1,g2,g3];
[p,e,t]=refinemesh(g,p,e,t,'longest');
[p,e,t]=refinemesh(g,p,e,t);
[p,e,t]=refinemesh(g,p,e,t);
np0=size(p,2); nraf=0;

% Load

nload=1; iload=[1]; floadx=[0]; floady=[0]; iappli=[];
%[floadx,floady,nappl,iappli,iload]=fairefload(p,nload);
%mulag=200;
lreg=0.2; creg=lreg^2;
mupe=0; mureg=mupe*4/lreg;

mulag=1;

%mucomp=5e-3*ones(1,nload);
%mucomp=1e-1*ones(1,nload);
compmax=25; %6;%5e-6;
pascomp=2e-3;%5e-4;%e9;
baug=2e-3;%2e-4;

gamma=2000; gmax=2;

%mucomp=mucomp/nload; pascomp=pascomp/nload; baug=baug/nload;
mucomp=1;

%mucomp=2; gamma=0;

%ifixx=find(abs(p(1,:))==2&p(2,:)==1);
%ifixy=find(abs(p(1,:))==2&p(2,:)==1);
ifixx=[]; ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));

% Initialization of the level-set function
phi0=-ones(np0,1);