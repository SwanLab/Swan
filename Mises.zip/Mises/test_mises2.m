% Plots the topological derivative of the Von Mises penalty functional
% for the infinite plate problem

% User-defined data
gmax=1; % Von Mises stress threshold 
nup=6; % Penalty parameter (p=2^nup)

% Fixed data
E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
k=(lambda+3*mu)/(lambda+mu);
xi=(1+nu)/(1-nu); eta=(3-nu)/(1+nu);
gmax=gmax*sqrt(2);
npsi=200; load psitab200-4.mat;

pp=2^nup;
ncp=size(psitab,2); ncol=min(nup,ncp);
vpsi=reshape(psitab(:,ncol),npsi+1,npsi+1);
eid=[1;0;1];

% Loops for the computation of the topological derivative
Exx=[]; Eyy=[]; Sxx=[]; Syy=[]; G=[];
ix=0;
for sxx=0:0.05:2
ix=ix+1; iy=0;
for syy=0:0.05:2
iy=iy+1;
Sxx(ix,iy)=sxx; Syy(ix,iy)=syy;
su=[sxx;0;syy];
trsu=su(1)+su(3);
eu=(1/(2*mu))*su-lambda/(4*mu*(lambda+mu))*trsu*eid;
treu=eu(1)+eu(3);
sueu=eu(1).*su(1)+2*eu(2).*su(2)+eu(3).*su(3);
sa=su(1); sb=su(3); sc=su(2); 
sm2=(sa.^2+sb.^2-sa.*sb+3*sc.^2); % Von Mises stess
tt=2*sm2/gmax^2;
k1=(2/gmax^2)*penalisation1(tt,pp);
ev=-k1*(3*su-trsu*eid); % adjoint strain
trev=ev(1)+ev(3);
sv=-k1*(6*mu*su+(lambda-2*mu)*trsu*eid);
suev=ev(1).*su(1)+2*ev(2).*su(2)+ev(3).*su(3);
gt=-((k+1)/2)*(2*suev-((k-2)/(k-1))*trsu.*trev);

gt=gt-k1.*(3*eta/(1+nu)*sueu+(eta*(2*nu-1)/(1-nu^2)+(xi-eta)/(2*(1-nu)))*trsu.*treu);

detsu=su(1).*su(3)-su(2).^2;
u1=abs(trsu)*sqrt(2)/gmax;
u2=sqrt(trsu.^2-4*detsu)*sqrt(2)/gmax;
l1=length(u1); l2=length(u2);
y1=homeoinv(u1); y1=min(y1,0.999);
y2=homeoinv(u2); y2=min(y2,0.999);
ny1=npsi*y1; ny1f=floor(ny1);
ny2=npsi*y2; ny2f=floor(ny2);
a1=ny1-ny1f;
a2=ny2-ny2f;
n1=floor(npsi*y1)+1;
n2=floor(npsi*y2)+1;
ll=size(vpsi,1);
vvpsi=vpsi(n1+(n2-1)*ll)+a1.*(vpsi(n1+1+(n2-1)*ll)-vpsi(n1+(n2-1)*ll))+a2.*(vpsi(n1+n2*ll)-vpsi(n1+(n2-1)*ll));
gt=gt+(vvpsi/pi);

susu=su(1).^2+2*su(2).^2+su(3).^2;
gt=gt+0.25*k1.*(10*susu-2*trsu.^2);
gt=gt-penalisation0(tt,pp);

G(ix,iy)=gt;
end;
end;

% Plot
figure(1); clf; surf(Sxx,Syy,G); title(['Topological gradient, p=',num2str(pp)]);
