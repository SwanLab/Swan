function vpsi=calculepsiM2(N,p)
y1=[0:1/N:1-1/N];
y2=[0:1/N:1-1/N];
%x1=(exp(1./(1-y1))-exp(1))/4;
%x2=(exp(1./(1-y2))-exp(1))/4;
x1=homeo(y1);
x2=homeo(y2);
vpsi=[];
for i=1:N
    for j=1:N
        s1=(x1(i)+x2(j))/2;
        s2=(x1(i)-x2(j))/2;
    vpsi(i,j)=psiM2(s1,s2,p);
    end;
end;
vpsi=[vpsi,zeros(size(vpsi,1),1)]; vpsi=[vpsi;zeros(1,size(vpsi,2))];