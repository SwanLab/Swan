function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax,baug]=viaduc5

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.; csn=lfil^2; % coefficient of the semi-norm H1

% Mesh Generation
% load geoT.mat; % Load geometry
% [p,e,t]=initmesh(g,'Hmax',0.32,'Hgrad',1.9);
% [p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
% %[p,e,t]=refinemesh(g,p,e,t); p=jigglemesh(p,e,t,'Opt','mean');
% np0=size(p,2);
% nraf=0; % Mesh refinement for the computation

% Construction of a regular mesh

load viaduc8.mat;%viaduc4.mat; % Load geometry
%[p,e,t]=poimesh(g,20,5);
%[p,e,t]=poimesh(g,40,10);
%[p,e,t]=poimesh(g,60,15);
%[p,e,t]=poimesh(g,80,20);
[p,e,t]=poimesh(g,100,25);
[p,e,t]=refinemesh(g,p,e,t,'longest');

np0=size(p,2); nraf=0;
%figure(3); clf; pdemesh(p,e,t); pause;

% Load

iloadi=find(p(2,:)==1 & abs(p(1,:))<1.99); 
%floadx=[[0,-1,1];[0,-1,1]];
nload=length(iloadi);
iload=(ones(nload,1)*iloadi)';
floadx=zeros(nload,nload);
%[K1,M1,F1]=assema(p,t,1,1,1);
%floady=-diag(F1(iloadi));
%floady=-eye(nload); 
floady=zeros(nload);
for i=1:nload
%j=find(abs(p(1,iloadi(i))-p(1,iloadi))<0.11);
%nj=length(j);
%floady(j,i)=-1/nj;
floady(:,i)=max(0.2-abs(p(1,iloadi(i))-p(1,iloadi)),0);
floady(:,i)=floady(:,i)/sum(floady(:,i));
end;
%mulag=200;
lreg=0.2; creg=lreg^2;
mupe=0.05; mureg=mupe*4/lreg;
mulag=1;
%mucomp=5e-3*ones(1,nload);
mucomp=50e-4*ones(1,nload);
compmax=6; %6;%5e-6;
pascomp=10e-4;%5e-4;%e9;
baug=10e-4;%2e-4;

%ifixx=find(abs(p(1,:))==2&p(2,:)==1);
%ifixy=find(abs(p(1,:))==2&p(2,:)==1);
ifixx=[]; ifixy=[];

% Initialization of the level-set function
%phi0=-ones(np0,1);
%phi0=-ones(np0,1)+2*(p(1,:).^2+(p(2,:)-0.5).^2<0.25.^2)';
phi0=-ones(np0,1)+2*((p(1,:)+1).^2+(p(2,:)-0.5).^2<0.25.^2)'+2*((p(1,:)-1).^2+(p(2,:)-0.5).^2<0.25.^2)';