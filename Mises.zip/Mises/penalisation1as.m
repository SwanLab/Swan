function pen=penalisation1as(t)

pen=(t>1);