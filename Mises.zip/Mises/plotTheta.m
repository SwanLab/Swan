figure(5); clf; hold on;
t=[0:0.01:2];
for k=1:7
    pp=cogamma^(k-1);
    %y=penalisation0(t,pp)./penalisation0(1,pp);
    y=penalisation0(t,pp);
    plot(t,y);
end;
hold off