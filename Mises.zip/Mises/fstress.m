function f=fstress(x,smax)
f=x./sqrt(1+x/smax);
%f=smax*log(x/smax+1);
%f=x;