function [mulag,lambda,mu,g,b,p,e,t,nraf,iload,floadx,floady,ifixx,ifixy,phi0,csn,mureg,creg,mucomp,pascomp,compmax]=bridge()

load geobridge.mat; % Load geometry

E=1; nu=0.3; % Young's modulus and Poisson's coefficient 
lambda=nu*E/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu)); % Lame's coefficients
lambda=2*mu*lambda/(lambda+2*mu); % plane stress
lfil=0.0; csn=lfil^2; % coefficient of the semi-norm H1
loadcase=4;

% Mesh Generation
%[p,e,t]=poimesh(g,48,29);
%[p,e,t]=poimesh(g,40,24);
%[p,e,t]=poimesh(g,32,25);
%[p,e,t]=poimesh(g,32,20);
%[p,e,t]=poimesh(g,28,17);
[p,e,t]=poimesh(g,16,10);
[p,e,t]=refinemesh(g,p,e,t,'longest');
%[p,e,t]=refinemesh(g,p,e,t);
%[p,e,t]=refinemesh(g,p,e,t);
np0=size(p,2);
nraf=1; % Mesh refinement for the computation

if (loadcase==1)
% Single load
 %mulag=30; % Lagrange multiplier for the weight
 iload=find((p(1,:)==0) & (p(2,:)==0)); % Location of the load
 floadx=[0];
 floady=[-1]; % Intensity of the load
 ifixx=[];
 ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=1; mureg=mupe*4/lreg;
mulag=1;mucomp=1/100;
compmax=30;
pascomp=1/10000;




elseif (loadcase==2)
% 3 loads
%mulag=120;
iload=[find((p(1,:)==0) & (p(2,:)==0)),find((p(1,:)==-0.5) & (p(2,:)==0)),find((p(1,:)==0.5) & (p(2,:)==0))];
floadx=[0,0,0];
floady=[-1,-1,-1]; % Intensity of the load
ifixx=[];
ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=3; mureg=mupe*4/lreg;
mulag=1;mucomp=[0.01,0.01,0.01];
compmax=30;
pascomp=1/10000;

elseif (loadcase==3)
% 7 loads
iload=[find((p(1,:)==0) & (p(2,:)==0)),find((p(1,:)==-0.5) & (p(2,:)==0)),find((p(1,:)==0.5) & (p(2,:)==0)),find((p(1,:)==0.25) & (p(2,:)==0)),find((p(1,:)==0.75) & (p(2,:)==0)),find((p(1,:)==-0.25) & (p(2,:)==0)),find((p(1,:)==-0.75) & (p(2,:)==0))];
floadx=[0,0,0,0,0,0,0];
floady=[-1,-1,-1,-1,-1,-1,-1]; % Intensity of the load
ifixx=[];
ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=3; mureg=mupe*4/lreg;
mulag=1;mucomp=0.01*ones(1,7);
compmax=30;
pascomp=1/10000;

elseif (loadcase==4)
% 11 loads
iload=[find((p(1,:)==0) & (p(2,:)==0)),find((p(1,:)==-0.5) & (p(2,:)==0)),find((p(1,:)==0.5) & (p(2,:)==0)),find((p(1,:)==0.25) & (p(2,:)==0)),find((p(1,:)==0.75) & (p(2,:)==0)),find((p(1,:)==-0.25) & (p(2,:)==0)),find((p(1,:)==-0.75) & (p(2,:)==0)),find((p(1,:)==0.125) & (p(2,:)==0)),find((p(1,:)==0.375) & (p(2,:)==0)),find((p(1,:)==0.625) & (p(2,:)==0)),find((p(1,:)==0.875) & (p(2,:)==0)),find((p(1,:)==-0.125) & (p(2,:)==0)),find((p(1,:)==-0.375) & (p(2,:)==0)),find((p(1,:)==-0.625) & (p(2,:)==0)),find((p(1,:)==-0.875) & (p(2,:)==0))];
floadx=zeros(1,15);
floady=-ones(1,15); % Intensity of the load
ifixx=[];
ifixy=find((abs(p(1,:))==1) & (p(2,:)==0));
lreg=0.05; creg=lreg^2;
mupe=3; mureg=mupe*4/lreg;
mulag=1;mucomp=0.01*ones(1,15);
compmax=30;
pascomp=1/10000;

end;


% Initialization of the level-set function
phi0=-ones(np0,1);
%phi0=ones(np0,1)-2*(p(2,:)<0.6)';
%phi0=ones(np0,1)-2*(p(2,:)<1)';
%phi0=-ones(np0,1)+2*((p(2,:)>1)+(p(1,:).^2+(p(2,:)-0.5).^2<0.4^2))';