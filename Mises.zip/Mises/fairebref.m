function bref=fairebref(lambda,mu);
bref=zeros(10,1);
for i=1:2
    for j=1:2
        for k=1:2
            for l=1:2
                c_ijkl=0;
                for m=1:2;
                    for n=1:2;
                        for q=1:2;
                            for r=1:2;
                                a_qmrn=(lambda-2*mu)*(q==r)*(m==n)+6*mu*(q==m)*(r==n);
                                s_mjnl=(m==1)*(n==1)*(j==1)*(l==1)+(m==2)*(n==2)*(j==2)*(l==2)+0.5*(m~=n)*(j~=l);
                                s_qirk=(q==1)*(r==1)*(i==1)*(k==1)+(q==2)*(r==2)*(i==2)*(k==2)+0.5*(q~=r)*(i~=k);
                                c_ijkl=c_ijkl+a_qmrn*s_mjnl*s_qirk;
                            end;
                        end;
                    end;
                end;           
                bref(8*(j-1)+4*i+2*l+k-6)=c_ijkl;
            end;
        end;
    end;
end;