figure(3); clf; 
pdeplot(p,e,t,'xydata',(phi>0),'xystyle','flat','colormap','gray','xygrid','off','colorbar','off'); 
hold on;
X=[0,1,1  ,1.3,1.3,1.5,1.5,0.5,0.5,0.2,0.2,0,0];
Y=[0,0,0.5,0.5,0  ,0  ,1  ,1  ,0.5,0.5,1  ,1,0];
plot(X,Y,'k-');
hold off;
axis image; axis off;
