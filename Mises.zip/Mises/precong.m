function gtr=precong(gtr,K1,M1,p,t)
    %gtr=sign(gtr).*sqrt(abs(gtr));
    %gtr=gtr./sqrt(10*dot(M1*gtr,gtr)/dot(M1*ones(np,1),ones(np,1))+gtr.^2);
    %gtr=gtr./sqrt(1+abs(gtr));
    
    gtr=sign(gtr).*log(1+abs(gtr));
    
    %gtr=sign(gtr).*log(1+gtr.^2);
    %gtr=gtr/sqrt(dot(M1*gtr,gtr));
    %gtr=distancing(p,t,gtr);
    %gtr=(K1+0.1*M1)\(M1*gtr);
    %for i=1:1
    %gtr=pdeintrp(p,t,gtr); gtr=pdeprtni(p,t,gtr);
    %end;