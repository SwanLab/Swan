clear all;
niter=40;

load a1.mat;
histoJ1=histoJ;
histotheta1=histotheta.*180/pi;
l1=length(histoJ1)-1;

load a2.mat;
histoJ2=histoJ;
histotheta2=histotheta.*180/pi;
l2=length(histoJ2)-1;

load a3.mat;
histoJ3=histoJ;
histotheta3=histotheta.*180/pi;
l3=length(histoJ3)-1;

load a4.mat;
histoJ4=histoJ;
histotheta4=histotheta.*180/pi;
l4=length(histoJ4)-1;

load a5.mat;
histoJ5=histoJ;
histotheta5=histotheta.*180/pi;
l5=length(histoJ5)-1;

figure(2); clf;
plot([0:l1],histoJ1,'r-',[0:l2],histoJ2,'b:',[0:l3],histoJ3,'g-.',[0:l4],histoJ4,'m--');%,[0:l5],histoJ5,'c.');
figure(3); clf;
plot([0:l1],histotheta1,'r-',[0:l2],histotheta2,'b:',[0:l3],histotheta3,'g-.',[0:l4],histotheta4,'m--');%,[0:l5],histotheta5,'c.');