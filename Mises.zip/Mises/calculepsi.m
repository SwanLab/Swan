function vpsi=calculepsi(N,p)
y=[0:1/N:1-1/N];
%x=-log(1-y)/log(2);
x=(exp(1./(1-y))-exp(1))/4;
vpsi=[];
for i=1:N
vpsi(i)=V1(x(i),p);
end;
vpsi=[vpsi,0];