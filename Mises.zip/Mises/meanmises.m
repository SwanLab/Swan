imat=find(beta>0.5);
artt=ar.*sqrt(tt);
mm=sum(artt(imat))/sum(ar(imat))