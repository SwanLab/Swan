figure(6); clf;
nload=length(compliance);
pas=360/(nload-1);
X=[0:pas:360];
plot(X,compliance,'b-',X,compmax'*ones(1,nload),'r--'); xlim([0,360]);