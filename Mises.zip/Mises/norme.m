function nv=norme(v,csn,K1,M1)
nv2=dot(M1*v,v)+csn*dot(K1*v,v);
nv=sqrt(nv2);